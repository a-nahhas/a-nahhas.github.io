import json
from pathlib import Path

import httpx
import pytest
import respx

from research_agent.sources import CrossrefClient, PubMedClient, RetrievalError, SemanticScholarClient
from research_agent.sources.http import get_with_backoff
from research_agent.sources.pubmed import BASE, parse_efetch
from research_agent.sources.semantic_scholar import URL as S2_URL

FIX = Path(__file__).parent.parent / "fixtures"


# --- back-off ---------------------------------------------------------------

@respx.mock
def test_backoff_retries_retryable_status_then_succeeds():
    route = respx.get("https://x.test/a").mock(side_effect=[httpx.Response(503), httpx.Response(429),
                                                           httpx.Response(200, json={"ok": 1})])
    sleeps = []
    with httpx.Client() as c:
        r = get_with_backoff(c, "https://x.test/a", sleep=sleeps.append)
    assert r.json() == {"ok": 1} and route.call_count == 3
    # Exponential: second delay roughly double the first (jitter is +/-20%).
    assert len(sleeps) == 2 and 1.3 < sleeps[1] / sleeps[0] < 3.1


@respx.mock
def test_backoff_gives_up_after_max_attempts():
    respx.get("https://x.test/a").mock(return_value=httpx.Response(429))
    with httpx.Client() as c, pytest.raises(RetrievalError, match="after 3 attempts"):
        get_with_backoff(c, "https://x.test/a", max_attempts=3, sleep=lambda s: None)


@respx.mock
def test_backoff_does_not_retry_client_errors():
    route = respx.get("https://x.test/a").mock(return_value=httpx.Response(400))
    with httpx.Client() as c, pytest.raises(RetrievalError, match="HTTP 400"):
        get_with_backoff(c, "https://x.test/a", sleep=lambda s: None)
    assert route.call_count == 1


@respx.mock
def test_backoff_honours_retry_after_header():
    respx.get("https://x.test/a").mock(side_effect=[httpx.Response(429, headers={"Retry-After": "7"}),
                                                   httpx.Response(200)])
    sleeps = []
    with httpx.Client() as c:
        get_with_backoff(c, "https://x.test/a", sleep=sleeps.append)
    assert sleeps == [7.0]


@respx.mock
def test_backoff_retries_transport_errors():
    respx.get("https://x.test/a").mock(side_effect=[httpx.ConnectError("down"), httpx.Response(200)])
    with httpx.Client() as c:
        assert get_with_backoff(c, "https://x.test/a", sleep=lambda s: None).status_code == 200


# --- PubMed -----------------------------------------------------------------

def test_parse_efetch_real_fixture():
    recs = parse_efetch((FIX / "pubmed_efetch.xml").read_text(encoding="utf-8"), subgoal_id=2)
    assert [r.pmid for r in recs] == ["38035307", "39054514"]
    first = recs[0]
    assert first.title.startswith("Exercise intervention for patients with chronic low back pain")
    assert not first.title.endswith(".")
    # The article's own DOI, not the first DOI found in its reference list.
    assert first.doi == "10.3389/fpubh.2023.1155225"
    assert first.abstract.startswith("PURPOSE:") and "RESULTS:" in first.abstract
    assert first.year == 2023 and first.authors and first.subgoal_ids == [2]
    assert recs[1].doi == "10.1186/s12891-024-07667-9"


@respx.mock
def test_pubmed_search_chains_esearch_and_efetch():
    respx.get(f"{BASE}/esearch.fcgi").mock(return_value=httpx.Response(
        200, text=(FIX / "pubmed_esearch.json").read_text()))
    efetch = respx.get(f"{BASE}/efetch.fcgi").mock(return_value=httpx.Response(
        200, text=(FIX / "pubmed_efetch.xml").read_text(encoding="utf-8")))
    with httpx.Client() as c:
        recs = PubMedClient(c, email="me@x.org", min_interval=0).search("q", 2, subgoal_id=1)
    assert len(recs) == 2
    params = efetch.calls.last.request.url.params
    assert params["id"] == "38035307,39054514" and params["tool"] and params["email"] == "me@x.org"


@respx.mock
def test_pubmed_empty_result_skips_efetch():
    respx.get(f"{BASE}/esearch.fcgi").mock(return_value=httpx.Response(200, json={"esearchresult": {"idlist": []}}))
    efetch = respx.get(f"{BASE}/efetch.fcgi")
    with httpx.Client() as c:
        assert PubMedClient(c, min_interval=0).search("q", 5, 1) == []
    assert not efetch.called


# --- Semantic Scholar -------------------------------------------------------

@respx.mock
def test_s2_parses_and_skips_titleless_records():
    respx.get(S2_URL).mock(return_value=httpx.Response(200, text=(FIX / "s2_search.json").read_text()))
    with httpx.Client() as c:
        recs = SemanticScholarClient(c).search("q", 3, subgoal_id=4)
    assert [r.s2_id for r in recs] == ["s2-aaa", "s2-bbb"]
    assert recs[0].doi == "10.3389/fpubh.2023.1155225" and recs[0].pmid == "38035307"
    assert recs[1].pmcid == "PMC1234567" and recs[1].journal is None


# --- Crossref ---------------------------------------------------------------

def _notice(doi, kind):
    return {"message": {"items": [{"update-to": [{"DOI": doi, "type": kind}]}]}}


@pytest.mark.parametrize("payload,expected", [
    (_notice("10.1/X", "retraction"), "retracted"),
    (_notice("10.1/x", "correction"), "corrected"),
    (_notice("10.9/other", "retraction"), "active"),   # notice about a different DOI
    ({"message": {"items": []}}, "active"),
])
@respx.mock
def test_crossref_status(payload, expected):
    respx.get("https://api.crossref.org/works").mock(return_value=httpx.Response(200, json=payload))
    with httpx.Client() as c:
        assert CrossrefClient(c).status("10.1/x") == expected


@respx.mock
def test_crossref_failure_is_unknown_not_active(monkeypatch):
    monkeypatch.setattr("research_agent.sources.http.time.sleep", lambda s: None)
    respx.get("https://api.crossref.org/works").mock(return_value=httpx.Response(503))
    with httpx.Client() as c:
        assert CrossrefClient(c).status("10.1/x") == "unknown"


@respx.mock
def test_extra_retry_statuses_are_retried_only_when_requested():
    route = respx.get("https://x.test/a").mock(side_effect=[httpx.Response(400), httpx.Response(200)])
    with httpx.Client() as c:
        assert get_with_backoff(c, "https://x.test/a", extra_retry=frozenset({400}),
                                sleep=lambda s: None).status_code == 200
    assert route.call_count == 2


@respx.mock
def test_pubmed_retries_transient_400_from_efetch(monkeypatch):
    # REMEDIATION R5: NCBI returned 400 for a valid efetch that succeeded on replay.
    monkeypatch.setattr("research_agent.sources.http.time.sleep", lambda s: None)
    respx.get(f"{BASE}/esearch.fcgi").mock(return_value=httpx.Response(
        200, text=(FIX / "pubmed_esearch.json").read_text()))
    respx.get(f"{BASE}/efetch.fcgi").mock(side_effect=[
        httpx.Response(400), httpx.Response(200, text=(FIX / "pubmed_efetch.xml").read_text(encoding="utf-8"))])
    with httpx.Client() as c:
        assert len(PubMedClient(c, min_interval=0).search("q", 2, 1)) == 2


def test_patched_time_sleep_is_honoured(monkeypatch):
    # REMEDIATION R2: time.sleep was bound at import, so patching it had no effect.
    slept = []
    monkeypatch.setattr("research_agent.sources.http.time.sleep", slept.append)
    with respx.mock:
        respx.get("https://x.test/a").mock(side_effect=[httpx.Response(503), httpx.Response(200)])
        with httpx.Client() as c:
            get_with_backoff(c, "https://x.test/a")
    assert len(slept) == 1


def test_crossref_paces_consecutive_requests(monkeypatch):
    # REMEDIATION R5(b): back-to-back status checks drew HTTP 429s.
    slept = []
    monkeypatch.setattr("research_agent.sources.crossref.time.sleep", slept.append)
    with respx.mock:
        respx.get("https://api.crossref.org/works").mock(return_value=httpx.Response(200, json={"message": {"items": []}}))
        with httpx.Client() as c:
            cr = CrossrefClient(c, min_interval=1.0)
            cr.status("10.1/a")
            cr.status("10.1/b")
    assert len(slept) == 1 and 0.5 < slept[0] <= 1.0


@respx.mock
def test_malformed_pubmed_xml_is_a_retrieval_error(monkeypatch):
    # REMEDIATION R12: ET.ParseError (a SyntaxError) escaped the planner and aborted the run.
    respx.get(f"{BASE}/esearch.fcgi").mock(return_value=httpx.Response(
        200, text=(FIX / "pubmed_esearch.json").read_text()))
    respx.get(f"{BASE}/efetch.fcgi").mock(return_value=httpx.Response(200, text="<html>Service unavailable"))
    with httpx.Client() as c, pytest.raises(RetrievalError, match="malformed"):
        PubMedClient(c, min_interval=0).search("q", 2, 1)


@respx.mock
def test_pubmed_language_filter_is_appended_in_code():
    route = respx.get(f"{BASE}/esearch.fcgi").mock(return_value=httpx.Response(200, json={"esearchresult": {"idlist": []}}))
    with httpx.Client() as c:
        PubMedClient(c, min_interval=0, language="english").search("exercise[tiab]", 5, 1)
    assert route.calls.last.request.url.params["term"] == "(exercise[tiab]) AND english[lang]"


def test_semantic_scholar_key_is_sent_as_header():
    with httpx.Client() as c:
        SemanticScholarClient(c, api_key="k123")
        assert c.headers["x-api-key"] == "k123"
