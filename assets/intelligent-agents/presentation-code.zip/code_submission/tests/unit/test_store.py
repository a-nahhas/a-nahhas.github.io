import json

import pytest

from research_agent.models import Claim, EvidenceRecord, QueryLogEntry, Record, ReviewDecision, RunReport
from research_agent.store import EvidenceStore


@pytest.fixture
def store():
    s = EvidenceStore(":memory:")
    yield s
    s.close()


def _ev(key_doi):
    return EvidenceRecord(
        record=Record(source="pubmed", title=f"T {key_doi}", doi=key_doi, abstract="a"),
        decision="include", reason="r",
        claims=[Claim(text="claim", supporting_extract="a supporting extract")])


def _report():
    return RunReport(run_id="r1", question="q", n_subgoals=1, completed_subgoals=[1], failed_subgoals={},
                     coverage=1.0, n_retrieved=2, n_after_dedup=2, n_no_abstract=0, n_screened=2,
                     n_not_screened=0, n_include=2, n_uncertain=0, n_exclude=0, n_claims_rejected=0)


def test_only_approved_records_are_persisted(store):
    store.save_run(_report(), [QueryLogEntry(subgoal_id=1, source="pubmed", query="q", status="ok", n_results=2)])
    ev = [_ev("10.1/a"), _ev("10.1/b")]
    n = store.apply_review("r1", ev, [ReviewDecision(record_key="doi:10.1/a", decision="approve"),
                                      ReviewDecision(record_key="doi:10.1/b", decision="reject")])
    assert n == 1
    rows = store.evidence("r1")
    assert [r["record_key"] for r in rows] == ["doi:10.1/a"]
    assert json.loads(rows[0]["claims_json"])[0]["supporting_extract"] == "a supporting extract"
    assert len(store.query_log("r1")) == 1


def test_later_rejection_removes_earlier_approval_and_reconciles(store):
    store.save_run(_report(), [])
    ev = [_ev("10.1/a")]
    store.apply_review("r1", ev, [ReviewDecision(record_key="doi:10.1/a", decision="approve")])
    store.apply_review("r1", ev, [ReviewDecision(record_key="doi:10.1/a", decision="flag")])
    assert store.evidence("r1") == []
    assert store.reconcile("r1")["ok"]


def test_unknown_record_rolls_back_whole_review(store):
    store.save_run(_report(), [])
    with pytest.raises(KeyError):
        store.apply_review("r1", [_ev("10.1/a")], [ReviewDecision(record_key="doi:10.1/a", decision="approve"),
                                                   ReviewDecision(record_key="doi:nope", decision="approve")])
    # The valid approval must not survive a failed transaction.
    assert store.evidence("r1") == []
    assert store.reconcile("r1") == {"ok": True, "expected": 0, "stored": 0, "missing": [], "unexpected": []}


def test_reconcile_detects_tampering(store):
    store.save_run(_report(), [])
    store.apply_review("r1", [_ev("10.1/a")], [ReviewDecision(record_key="doi:10.1/a", decision="approve")])
    store._conn.execute("DELETE FROM evidence")
    result = store.reconcile("r1")
    assert not result["ok"] and result["missing"] == ["doi:10.1/a"]


def test_count_reflects_final_decision_within_a_batch(store):
    store.save_run(_report(), [])
    n = store.apply_review("r1", [_ev("10.1/a")], [ReviewDecision(record_key="doi:10.1/a", decision="approve"),
                                                 ReviewDecision(record_key="doi:10.1/a", decision="reject")])
    assert n == 0 and store.evidence("r1") == []
