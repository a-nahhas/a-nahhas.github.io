import pytest

from research_agent.models import Claim, Record
from research_agent.validation import extract_in_abstract, validate_claims

ABSTRACT = ("BACKGROUND: Chronic low back pain is common. RESULTS: Pain fell by 2.1 points (95% CI 1.4–2.8) "
            "on the NRS compared with usual care. CONCLUSION: Exercise is a modestly effective treatment.")


@pytest.mark.parametrize("extract", [
    "Pain fell by 2.1 points (95% CI 1.4–2.8) on the NRS",
    "pain fell by 2.1 points (95% ci 1.4-2.8) on the nrs",          # case + dash normalisation
    "Pain fell by 2.1 points (95% CI 1.4–2.8)   on the NRS",     # whitespace
    "RESULTS: Pain fell by 2.1 points",                                # keeps our section label
    "Exercise is a modestly effective treatment",
    "Pain fell by 2.1 points (95% CI 1.4-2.8) on the NRS, compared with usual care",  # added comma: fuzzy path
    "fell by 2.1 points (95% CI 1.4-2.8) on the NRS, compared",  # fuzzy path, numbers near the window edge
])
def test_genuine_extracts_accepted(extract):
    assert extract_in_abstract(extract, ABSTRACT)


@pytest.mark.parametrize("extract", [
    "Pain fell by 3.1 points (95% CI 1.4-2.8) on the NRS",   # changed number (REMEDIATION R6)
    "Pain fell by 2.1 points (95% CI 1.4-2.9) on the NRS, compared with usual care",  # changed CI, fuzzy path
    "Pain fell by 2.1 points (95% CI 1.4-2.8) on NRS compared with usual care",  # dropped word: beyond tolerance
    "Exercise is a highly effective treatment",                # changed wording
    "Yoga reduced disability in older adults with chronic pain",  # fabricated
])
def test_altered_or_fabricated_extracts_rejected(extract):
    assert not extract_in_abstract(extract, ABSTRACT)


def _rec(**kw):
    return Record(**({"source": "pubmed", "title": "t", "pmid": "1", "abstract": ABSTRACT} | kw))


def test_validate_claims_splits_valid_and_rejected():
    good = Claim(text="pain reduced", supporting_extract="Pain fell by 2.1 points")
    bad = Claim(text="cures pain", supporting_extract="Exercise cured all back pain")
    valid, rejected, notes = validate_claims(_rec(), [good, bad])
    assert valid == [good] and rejected == [bad] and "1 claim(s) rejected" in notes[0]


def test_record_without_identifier_rejects_all_claims():
    good = Claim(text="pain reduced", supporting_extract="Pain fell by 2.1 points")
    valid, rejected, notes = validate_claims(_rec(pmid=None), [good])
    assert valid == [] and rejected == [good] and "untraceable" in notes[0]


# --- REMEDIATION R10: misquotes that flip meaning while scoring >= 97 -------------

NEG_ABSTRACT = ("RESULTS: There was no significant difference in pain between groups at 12 weeks "
                "(p = 0.41). Disability increased slightly in the control arm over the follow-up period.")


@pytest.mark.parametrize("extract", [
    "There was a significant difference in pain between groups at 12 weeks",    # negation flipped
    "Disability decreased slightly in the control arm over the follow-up period",  # direction flipped
    "There was no significant difference in pain between groups at 12 weeks and in disability too",  # invented tail
    NEG_ABSTRACT + " Exercise cured everyone.",                                  # longer than the abstract
    "          ",                                                                # blank
    "RESULTS: pain",                                                             # label + trivial remainder
])
def test_meaning_changing_extracts_rejected(extract):
    assert not extract_in_abstract(extract, NEG_ABSTRACT)


def test_cosmetic_fuzzy_difference_still_accepted():
    # Hyphenation variant of one word, everything else verbatim.
    assert extract_in_abstract("Disability increased slightly in the control-arm over the follow-up period",
                               NEG_ABSTRACT.replace("control arm", "controlarm"))
