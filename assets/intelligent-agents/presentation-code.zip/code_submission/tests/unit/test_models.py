import pytest
from pydantic import ValidationError

from research_agent.models import Claim, ReactDecision, Record, SubgoalPlan


def _sg(i):
    return {"id": i, "description": "find RCTs", "pubmed_query": "x[tiab]", "keyword_query": "x y",
            "sources": ["pubmed"], "rationale": "primary evidence"}


def test_plan_rejects_duplicate_subgoal_ids():
    with pytest.raises(ValidationError, match="unique"):
        SubgoalPlan(subgoals=[_sg(1), _sg(1)], inclusion_criteria=["adults"])


def test_plan_requires_inclusion_criteria():
    with pytest.raises(ValidationError):
        SubgoalPlan(subgoals=[_sg(1)], inclusion_criteria=[])


def test_plan_rejects_unknown_source():
    bad = _sg(1) | {"sources": ["google"]}
    with pytest.raises(ValidationError):
        SubgoalPlan(subgoals=[bad], inclusion_criteria=["adults"])


def test_refine_action_requires_a_query():
    with pytest.raises(ValidationError, match="refined query"):
        ReactDecision(thought="too few", action="refine")
    assert ReactDecision(thought="ok", action="refine", refined_keyword_query="a b").action == "refine"


@pytest.mark.parametrize("raw", ["10.1/ABC", "https://doi.org/10.1/abc", "doi:10.1/Abc", " 10.1/abc "])
def test_doi_normalised(raw):
    assert Record(source="pubmed", title="t", doi=raw).doi == "10.1/abc"


def test_record_key_prefers_doi_then_pmid():
    assert Record(source="pubmed", title="t", doi="10.1/a", pmid="1").key == "doi:10.1/a"
    assert Record(source="pubmed", title="t", pmid="1").key == "pmid:1"
    assert Record(source="semantic_scholar", title="T", s2_id="abc").key == "s2:abc"


def test_claim_extract_must_be_substantive():
    with pytest.raises(ValidationError):
        Claim(text="works", supporting_extract="short")
