import re
from dataclasses import replace

from research_agent.curation import CurationAgent, bm25_scores
from research_agent.llm import ScriptedLLM
from research_agent.models import ResultsBuffer, SubgoalPlan
from tests.conftest import plan_json, rec


def _buffer(records):
    return ResultsBuffer(run_id="r", question="exercise for chronic low back pain",
                         plan=SubgoalPlan.model_validate(plan_json(1)), records=records)


def _indices(prompt):
    return [int(i) for i in re.findall(r"\[record_index (\d+)\]", prompt)]


def include_all(prompt):
    """Screens every record in the batch as include, quoting a real span of its abstract."""
    out = []
    for i in _indices(prompt):
        block = prompt.split(f"[record_index {i}]")[1]
        abstract = block.split("Abstract: ")[1].split("\n")[0]
        out.append({"record_index": i, "decision": "include", "relevance": 0.9, "reason": "meets criteria",
                    "claims": [{"text": "pain reduced", "supporting_extract": abstract[:40]}]})
    return {"screenings": out}


class FakeCrossref:
    def __init__(self, statuses):
        self.statuses, self.calls = statuses, []

    def status(self, doi):
        self.calls.append(doi)
        return self.statuses.get(doi, "active")


def test_bm25_prefers_documents_matching_query_terms():
    s = bm25_scores("exercise chronic back pain", ["exercise for chronic back pain", "diet and diabetes"])
    assert s[0] > s[1] == 0


def test_duplicates_merged_before_screening(settings):
    a = rec(1, doi="10.1/a")
    b = rec(1, source="semantic_scholar", doi="10.1/A")
    llm = ScriptedLLM([include_all])
    report = CurationAgent(llm, settings=settings).run(_buffer([a, b, rec(2)]))
    assert report.n_input == 3 and report.n_after_dedup == 2 and report.n_screened == 2
    assert _indices(llm.prompts[0]) == [0, 1]


def test_screening_is_batched(settings):
    s = replace(settings, screen_batch_size=2)
    llm = ScriptedLLM([include_all] * 3)
    report = CurationAgent(llm, settings=s).run(_buffer([rec(i) for i in range(5)]))
    assert len(llm.prompts) == 3 and report.n_screened == 5


def test_records_beyond_screen_limit_and_without_abstract_are_accounted_not_dropped(settings):
    s = replace(settings, screen_limit=2)
    no_abs = rec(9).model_copy(update={"abstract": None})
    report = CurationAgent(ScriptedLLM([include_all]), settings=s).run(_buffer([rec(1), rec(2), rec(3), no_abs]))
    assert report.n_screened == 2 and report.n_not_screened == 1 and report.n_no_abstract == 1
    unscreened = [e for e in report.evidence if not e.screened]
    assert len(unscreened) == 2 and all(e.decision == "uncertain" for e in unscreened)
    assert len(report.evidence) == 4


def test_fabricated_extract_rejected_and_include_downgraded(settings):
    llm = ScriptedLLM([{"screenings": [{"record_index": 0, "decision": "include", "relevance": 0.95,
                                        "reason": "r", "claims": [{"text": "cures",
                                                                   "supporting_extract": "Exercise cured all patients."}]}]}])
    e = CurationAgent(llm, settings=settings).run(_buffer([rec(1)])).evidence[0]
    assert e.decision == "uncertain" and e.claims == [] and len(e.rejected_claims) == 1
    assert any("downgraded include" in n for n in e.validation_notes)


def test_missing_screening_for_a_record_becomes_uncertain(settings):
    llm = ScriptedLLM([{"screenings": [{"record_index": 0, "decision": "exclude", "relevance": 0.1,
                                        "reason": "adolescents", "claims": []}]}])
    ev = CurationAgent(llm, settings=settings).run(_buffer([rec(1), rec(2)])).evidence
    by_decision = {e.decision: e for e in ev}
    assert set(by_decision) == {"exclude", "uncertain"}
    assert "no screening" in by_decision["uncertain"].reason


def test_llm_failure_degrades_batch_to_uncertain(settings):
    llm = ScriptedLLM(["garbage"] * 4)
    ev = CurationAgent(llm, settings=settings).run(_buffer([rec(1), rec(2)])).evidence
    assert all(e.decision == "uncertain" for e in ev)


def test_ranking_orders_include_then_uncertain_then_exclude(settings):
    def mixed(prompt):
        idx = _indices(prompt)
        dec = ["exclude", "include", "uncertain"]
        return {"screenings": [{"record_index": i, "decision": dec[i], "relevance": 0.5, "reason": "r",
                                "claims": [{"text": "c x", "supporting_extract": "Exercise reduced pain by"}]}
                               for i in idx]}
    ev = CurationAgent(ScriptedLLM([mixed]), settings=settings).run(_buffer([rec(1), rec(2), rec(3)])).evidence
    assert [e.decision for e in ev] == ["include", "uncertain", "exclude"]


def test_crossref_checked_only_for_non_excluded_with_doi_and_retraction_flagged(settings):
    cr = FakeCrossref({"10.1/b": "retracted"})
    llm = ScriptedLLM([include_all])
    ev = CurationAgent(llm, crossref=cr, settings=settings).run(
        _buffer([rec(1, doi="10.1/a"), rec(2, doi="10.1/b"), rec(3)])).evidence
    assert sorted(cr.calls) == ["10.1/a", "10.1/b"]
    retracted = next(e for e in ev if e.record.doi == "10.1/b")
    assert retracted.publication_status == "retracted"
    assert "RETRACTED" in retracted.validation_notes[-1]


def test_llm_outage_during_screening_degrades_to_uncertain(settings):
    # REMEDIATION R3: LLMUnavailable must become "uncertain", never a crash or a guess.
    from research_agent.llm import LLMUnavailable

    def down(prompt):
        raise LLMUnavailable("all models busy")
    ev = CurationAgent(ScriptedLLM([down]), settings=settings).run(_buffer([rec(1), rec(2)])).evidence
    assert [e.decision for e in ev] == ["uncertain", "uncertain"]
    assert all("missing LLM screening" in e.validation_notes for e in ev)


def test_revise_rescreens_flagged_record_with_reviewer_note(settings):
    llm = ScriptedLLM([include_all, include_all])
    agent_ = CurationAgent(llm, settings=settings)
    first = agent_.run(_buffer([rec(1)])).evidence[0]
    revised = agent_.revise("q", SubgoalPlan.model_validate(plan_json(1)), [(first, "is the population adult?")])
    assert "Reviewer note (flagged for re-screening): is the population adult?" in llm.prompts[1]
    assert revised[0].record.key == first.record.key
    assert "revised after reviewer flag: is the population adult?" in revised[0].validation_notes


def test_title_only_records_are_labelled_title_only(settings):
    no_abs = rec(9).model_copy(update={"abstract": None})
    assert type(no_abs).model_validate(no_abs.model_dump()).evidence_basis == "title-only"
