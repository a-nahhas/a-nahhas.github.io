import pytest

from research_agent.llm import ScriptedLLM, SchemaEscalation, _extract_json, generate_structured
from research_agent.models import SubgoalPlan
from tests.conftest import plan_json


def test_valid_first_reply_needs_one_call():
    llm = ScriptedLLM([plan_json()])
    plan = generate_structured(llm, "plan", SubgoalPlan)
    assert len(plan.subgoals) == 2 and len(llm.prompts) == 1
    assert "JSON Schema" in llm.prompts[0]


def test_invalid_reply_is_reprompted_with_the_validation_error():
    bad = plan_json() | {"inclusion_criteria": []}
    llm = ScriptedLLM([bad, plan_json()])
    generate_structured(llm, "plan", SubgoalPlan)
    assert len(llm.prompts) == 2
    assert "previous reply was invalid" in llm.prompts[1] and "inclusion_criteria" in llm.prompts[1]


def test_escalates_after_exactly_max_retries_plus_one_attempts():
    llm = ScriptedLLM(["not json"] * 10)
    with pytest.raises(SchemaEscalation) as exc:
        generate_structured(llm, "plan", SubgoalPlan, max_retries=3)
    assert len(exc.value.attempts) == 4 and len(llm.prompts) == 4


def test_markdown_fences_are_stripped():
    assert _extract_json('```json\n{"a": 1}\n```') == '{"a": 1}'
    assert _extract_json(' {"a": 1} ') == '{"a": 1}'


# --- Gemini failover (REMEDIATION R3) ----------------------------------------

class _FakeModels:
    """Stands in for client.models; fails with the scripted status per model name."""

    def __init__(self, failures):
        self.failures, self.calls = failures, []

    def generate_content(self, model, contents, config):
        from google.genai import errors
        self.calls.append(model)
        code = self.failures.get(model)
        if code:
            raise errors.APIError(code, {"error": {"code": code, "message": "x", "status": "X"}})
        return type("R", (), {"text": '{"ok": true}'})()


def _gemini(monkeypatch, failures, models=("primary", "fallback")):
    from research_agent.llm import GeminiLLM
    monkeypatch.setattr("research_agent.llm.time.sleep", lambda s: None)
    g = GeminiLLM("key", list(models), min_interval=0, round_pause=0)
    fake = _FakeModels(failures)
    g._client = type("C", (), {"models": fake})()
    return g, fake


def test_gemini_fails_over_to_next_model_on_sustained_503(monkeypatch):
    g, fake = _gemini(monkeypatch, {"primary": 503})
    assert g.complete("p") == '{"ok": true}'
    assert fake.calls == ["primary"] * 3 + ["fallback"]
    assert g.calls == ["fallback"] and g.model == "fallback"
    # Sticky: the next call goes straight to the working model.
    g.complete("p2")
    assert fake.calls[-1] == "fallback" and len(fake.calls) == 5


def test_gemini_raises_unavailable_after_all_rounds(monkeypatch):
    from research_agent.llm import LLMUnavailable
    g, fake = _gemini(monkeypatch, {"primary": 429, "fallback": 503})
    with pytest.raises(LLMUnavailable):
        g.complete("p")
    # 2 rounds x 2 models x 3 attempts each
    assert len(fake.calls) == 12


def test_gemini_retires_withdrawn_model_and_uses_next(monkeypatch):
    g, fake = _gemini(monkeypatch, {"primary": 404})
    assert g.complete("p") == '{"ok": true}'
    g.complete("p")
    # 404 is not retried, and the retired model is never called again.
    assert fake.calls == ["primary", "fallback", "fallback"]


def test_gemini_returns_to_earlier_model_when_it_recovers(monkeypatch):
    g, fake = _gemini(monkeypatch, {"primary": 503}, models=("primary", "fallback"))
    g.complete("p")                      # fails over to fallback
    fake.failures = {"fallback": 503}    # capacity flips
    g.complete("p")
    assert fake.calls[-1] == "primary" and g.model == "primary"


def test_gemini_treats_dropped_connection_as_transient(monkeypatch):
    # REMEDIATION R8: httpx.RemoteProtocolError escaped failover and crashed a live UI run.
    import httpx
    g, fake = _gemini(monkeypatch, {})
    real = fake.generate_content
    state = {"n": 0}

    def flaky(model, contents, config):
        state["n"] += 1
        if state["n"] == 1:
            raise httpx.RemoteProtocolError("Server disconnected without sending a response.")
        return real(model, contents, config)
    fake.generate_content = flaky
    assert g.complete("p") == '{"ok": true}' and state["n"] == 2


def test_gemini_does_not_fail_over_on_client_error(monkeypatch):
    from google.genai import errors
    g, fake = _gemini(monkeypatch, {"primary": 400})
    with pytest.raises(errors.APIError):
        g.complete("p")
    assert fake.calls == ["primary"]
