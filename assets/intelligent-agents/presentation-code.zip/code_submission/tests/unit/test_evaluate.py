"""Evaluation maths, checked offline with a scripted screener (no Gemini calls)."""

import re
from dataclasses import replace

from eval.evaluate import evaluate_once, load_gold, write_audit_sheet
from research_agent.llm import LLMUnavailable, ScriptedLLM


def _screen_all(decision):
    def screen(prompt):
        out = []
        for i in re.findall(r"\[record_index (\d+)\]", prompt):
            ab = prompt.split(f"[record_index {i}]")[1].split("Abstract: ")[1].split("\n")[0]
            out.append({"record_index": int(i), "decision": decision, "relevance": .5, "reason": "r",
                        "claims": [{"text": "a claim", "supporting_extract": ab[:60]}] if decision != "exclude" else []})
        return {"screenings": out}
    return screen


def test_metrics_for_an_include_everything_screener(settings):
    gold, recs = load_gold()
    r = evaluate_once(ScriptedLLM([_screen_all("include")] * 10), replace(settings, screen_limit=1000), gold, recs)
    assert r["recall_operative"] == r["recall_strict"] == 1.0 and r["specificity"] == 0.0
    assert r["claim_validation_pass_rate"] == 1.0 and r["store_reconciles"]
    # The default BM25 cut-off would keep some labelled includes away from the LLM.
    assert r["recall_operative_at_production_cutoff"] < 1.0 and r["includes_below_cutoff"]


def test_screening_outage_is_not_counted_as_recall(settings):
    # REMEDIATION R16: failed batches became "uncertain" and silently counted as recalled.
    def down(prompt):
        raise LLMUnavailable("down")
    gold, recs = load_gold()
    r = evaluate_once(ScriptedLLM([down] * 10), replace(settings, screen_limit=1000), gold, recs)
    assert r["n_screening_failures"] == 28
    assert r["recall_operative"] == 1.0 and r["recall_llm"] == 0.0


def test_audit_sheet_pools_runs_up_to_twenty_records(settings, tmp_path):
    gold, recs = load_gold()
    r = evaluate_once(ScriptedLLM([_screen_all("include")] * 10), replace(settings, screen_limit=1000), gold, recs)
    assert write_audit_sheet([r, r], tmp_path / "a.csv") == 20
