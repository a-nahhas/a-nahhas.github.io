from research_agent.dedup import deduplicate
from research_agent.models import Record


def R(**kw):
    base = {"source": "pubmed", "title": "Exercise therapy for chronic low back pain"}
    return Record(**(base | kw))


def test_exact_doi_duplicates_merge():
    out = deduplicate([R(doi="10.1/a", pmid="1"), R(source="semantic_scholar", doi="10.1/A", s2_id="s")])
    assert len(out) == 1
    assert out[0].pmid == "1" and out[0].s2_id == "s"


def test_fuzzy_title_match_merges_when_one_side_lacks_identifiers():
    out = deduplicate([
        R(pmid="1", abstract=None, subgoal_ids=[1]),
        R(source="semantic_scholar", title="Exercise Therapy for Chronic Low-Back Pain.", s2_id="s",
          abstract="An abstract.", subgoal_ids=[2]),
    ])
    assert len(out) == 1
    assert out[0].abstract == "An abstract."
    assert out[0].subgoal_ids == [1, 2]


def test_conflicting_identifiers_are_not_merged_despite_identical_titles():
    # e.g. an erratum shares its parent paper's title but has its own DOI.
    assert len(deduplicate([R(doi="10.1/a"), R(doi="10.1/b")])) == 2


def test_distant_years_block_title_merge():
    assert len(deduplicate([R(year=2001), R(source="semantic_scholar", year=2019)])) == 2


def test_distinct_titles_kept():
    assert len(deduplicate([R(), R(title="Yoga for chronic neck pain in office workers")])) == 2


def test_pubmed_copy_is_the_base():
    out = deduplicate([R(source="semantic_scholar", journal="S2 venue", doi="10.1/a"),
                       R(journal="BMJ", doi="10.1/a")])
    assert out[0].source == "pubmed" and out[0].journal == "BMJ"


def test_companion_papers_differing_only_in_a_number_are_not_merged():
    # REMEDIATION R15: these scored 98.6 and merged, copying one paper's DOI onto the other.
    a = R(title="Exercise for chronic low back pain: 12-month follow-up of a randomized trial", pmid="1")
    b = R(source="semantic_scholar", title="Exercise for chronic low back pain: 6-month follow-up of a randomized trial",
          s2_id="s", doi="10.1/six")
    out = deduplicate([a, b])
    assert len(out) == 2 and next(r for r in out if r.pmid == "1").doi is None
