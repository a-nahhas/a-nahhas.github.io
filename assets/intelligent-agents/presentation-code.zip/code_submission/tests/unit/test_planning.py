from dataclasses import replace

from research_agent.llm import ScriptedLLM
from research_agent.models import SubgoalPlan
from research_agent.planning import PlanningRetrievalAgent
from tests.conftest import FakeSource, plan_json, rec


def agent(llm, settings, pubmed=None, s2=None):
    return PlanningRetrievalAgent(llm, {"pubmed": pubmed or FakeSource("pubmed"),
                                        "semantic_scholar": s2 or FakeSource("semantic_scholar")}, settings)


def test_happy_path_completes_every_subgoal_without_extra_llm_calls(settings):
    pm = FakeSource("pubmed", default=[rec(1), rec(2)])
    s2 = FakeSource("semantic_scholar", default=[rec(3, "semantic_scholar")])
    llm = ScriptedLLM([plan_json(3)])
    buf = agent(llm, settings, pm, s2).run("q")
    assert buf.completed_subgoals == [1, 2, 3] and buf.failed_subgoals == {}
    assert len(buf.records) == 9 and len(buf.query_log) == 6
    # Reactive accepts: only the planning call reached the LLM.
    assert len(llm.prompts) == 1
    assert pm.calls == ["pq1", "pq2", "pq3"] and s2.calls == ["kq1", "kq2", "kq3"]
    kinds = [t.kind for t in buf.trace]
    assert kinds[0] == "plan" and kinds.count("action") == 3 and kinds.count("observation") == 3


def test_one_source_failing_is_logged_but_other_source_results_kept(settings, boom):
    pm = FakeSource("pubmed", default=[rec(1), rec(2)])
    s2 = FakeSource("semantic_scholar", default=boom)
    buf = agent(ScriptedLLM([plan_json(1)]), settings, pm, s2).run("q")
    assert buf.completed_subgoals == [1] and len(buf.records) == 2
    errs = [q for q in buf.query_log if q.status == "error"]
    assert len(errs) == 1 and errs[0].source == "semantic_scholar" and "429" in errs[0].error


def test_all_sources_failing_marks_subgoal_failed_without_consulting_llm(settings, boom):
    llm = ScriptedLLM([plan_json(2)])
    pm = FakeSource("pubmed", by_query={"pq1": boom}, default=[rec(1), rec(2)])
    s2 = FakeSource("semantic_scholar", by_query={"kq1": boom}, default=[])
    buf = agent(llm, settings, pm, s2).run("q")
    assert 1 in buf.failed_subgoals and "retrieval failed" in buf.failed_subgoals[1]
    assert buf.completed_subgoals == [2]
    assert len(llm.prompts) == 1


def test_sparse_results_trigger_llm_refinement_and_retry(settings):
    pm = FakeSource("pubmed", by_query={"pq1": [], "broader pq1": [rec(1), rec(2)]})
    llm = ScriptedLLM([plan_json(1, sources=("pubmed",)),
                       {"thought": "query too narrow", "action": "refine", "refined_pubmed_query": "broader pq1"}])
    buf = agent(llm, settings, pm).run("q")
    assert pm.calls == ["pq1", "broader pq1"]
    assert buf.completed_subgoals == [1] and len(buf.records) == 2
    assert "Observation: only 0 records" in llm.prompts[1]
    assert any("query too narrow -> refine" in t.content for t in buf.trace)
    assert [q.query for q in buf.query_log] == ["pq1", "broader pq1"]


def test_refinement_is_bounded(settings):
    pm = FakeSource("pubmed", default=[])
    llm = ScriptedLLM([plan_json(1, sources=("pubmed",)),
                       {"thought": "narrow", "action": "refine", "refined_pubmed_query": "x"}])
    buf = agent(llm, settings, pm).run("q")
    assert len(pm.calls) == 2  # original + one refinement, then give up
    assert buf.failed_subgoals == {1: "no results after refinement"}


def test_agent_can_drop_an_unproductive_subgoal(settings):
    pm = FakeSource("pubmed", by_query={"pq1": [rec(1)]}, default=[rec(2), rec(3)])
    llm = ScriptedLLM([plan_json(2, sources=("pubmed",)), {"thought": "off-topic", "action": "drop"}])
    buf = agent(llm, settings, pm).run("q")
    assert buf.failed_subgoals[1].startswith("dropped by agent") and buf.completed_subgoals == [2]


def test_invalid_plan_escalates_to_human_after_retries(settings):
    llm = ScriptedLLM(["{}"] * 4)
    buf = agent(llm, settings).run("q")
    assert buf.plan is None and buf.needs_human and len(llm.prompts) == 4
    assert buf.trace[-1].kind == "escalation" and buf.records == []


def test_plan_longer_than_budget_is_truncated(settings):
    s = replace(settings, max_subgoals=2)
    buf = agent(ScriptedLLM([plan_json(4)]), s, FakeSource("pubmed", default=[rec(1), rec(2)])).run("q")
    assert [sg.id for sg in buf.plan.subgoals] == [1, 2]


def test_step_budget_reports_unfinished_subgoals_as_failed(settings):
    s = replace(settings, max_react_steps=2)
    pm = FakeSource("pubmed", default=[rec(1), rec(2)])
    buf = agent(ScriptedLLM([plan_json(4, sources=("pubmed",))]), s, pm).run("q")
    assert buf.completed_subgoals == [1, 2]
    assert buf.failed_subgoals == {3: "step budget exhausted", 4: "step budget exhausted"}


def test_replan_includes_previous_plan_and_feedback(settings):
    prev = SubgoalPlan.model_validate(plan_json(1))
    llm = ScriptedLLM([plan_json(2)])
    buf = agent(llm, settings, FakeSource("pubmed", default=[rec(1), rec(2)])).run(
        "q", feedback="too many reviews, want RCTs", previous_plan=prev)
    assert "REVISION" in llm.prompts[0] and "want RCTs" in llm.prompts[0]
    assert buf.trace[0].kind == "replan"


def test_llm_outage_during_planning_escalates_instead_of_crashing(settings):
    from research_agent.llm import LLMUnavailable

    def down(prompt):
        raise LLMUnavailable("all models unavailable")
    buf = agent(ScriptedLLM([down]), settings).run("q")
    assert buf.plan is None and "LLM unavailable" in buf.needs_human
    assert buf.trace[-1].kind == "escalation"


def test_circuit_breaker_stops_calling_a_repeatedly_failing_source(settings, boom):
    # REMEDIATION R5: Semantic Scholar 429'd on every subgoal, costing back-off each time.
    pm = FakeSource("pubmed", default=[rec(1), rec(2)])
    s2 = FakeSource("semantic_scholar", default=boom)
    buf = agent(ScriptedLLM([plan_json(4)]), settings, pm, s2).run("q")
    assert len(s2.calls) == settings.source_failure_limit == 2
    assert buf.completed_subgoals == [1, 2, 3, 4]
    skipped = [q for q in buf.query_log if q.source == "semantic_scholar" and "circuit open" in (q.error or "")]
    assert len(skipped) == 2  # subgoals 3 and 4 are still accounted for in the log
    assert any("skipping it for the rest of this run" in t.content for t in buf.trace)


# --- branches the code review found untested --------------------------------------

def test_unconfigured_source_is_reported_not_crashed(settings):
    a = PlanningRetrievalAgent(ScriptedLLM([plan_json(1)]), {"pubmed": FakeSource("pubmed", default=[rec(1), rec(2)])},
                               settings)
    buf = a.run("q")
    assert buf.completed_subgoals == [1]
    assert [q.source for q in buf.query_log] == ["pubmed"]  # S2 had no client


def test_partial_results_kept_once_refinement_budget_is_spent(settings):
    pm = FakeSource("pubmed", by_query={"pq1": [], "broader": [rec(1)]})
    llm = ScriptedLLM([plan_json(1, sources=("pubmed",)),
                       {"thought": "narrow", "action": "refine", "refined_pubmed_query": "broader"}])
    buf = agent(llm, settings, pm).run("q")
    assert buf.completed_subgoals == [1] and len(buf.records) == 1
    assert any("keeping partial results" in t.content for t in buf.trace)


def test_llm_may_accept_sparse_but_non_empty_results(settings):
    pm = FakeSource("pubmed", default=[rec(1)])
    llm = ScriptedLLM([plan_json(1, sources=("pubmed",)), {"thought": "niche topic", "action": "accept"}])
    buf = agent(llm, settings, pm).run("q")
    assert buf.completed_subgoals == [1] and len(pm.calls) == 1


def test_zero_results_never_count_as_completed_even_if_reasoning_fails(settings):
    # REMEDIATION R14: the fallback "accept" counted an empty subgoal as covered.
    from research_agent.llm import LLMUnavailable

    def down(prompt):
        raise LLMUnavailable("down")
    pm = FakeSource("pubmed", default=[])
    buf = agent(ScriptedLLM([plan_json(1, sources=("pubmed",)), down]), settings, pm).run("q")
    assert buf.completed_subgoals == [] and buf.failed_subgoals[1].startswith("no results")


def test_llm_accepting_an_empty_result_is_a_failed_subgoal(settings):
    pm = FakeSource("pubmed", default=[])
    llm = ScriptedLLM([plan_json(1, sources=("pubmed",)), {"thought": "nothing exists", "action": "accept"}])
    buf = agent(llm, settings, pm).run("q")
    assert 1 in buf.failed_subgoals


def test_researcher_criteria_override_the_llm_and_reach_the_prompt(settings):
    llm = ScriptedLLM([plan_json(1)])
    buf = agent(llm, settings, FakeSource("pubmed", default=[rec(1), rec(2)])).run(
        "q", criteria=(["Adults over 60"], ["Surgery"]))
    assert buf.plan.inclusion_criteria == ["Adults over 60"] and buf.plan.exclusion_criteria == ["Surgery"]
    assert "fixed the eligibility criteria" in llm.prompts[0] and "Adults over 60" in llm.prompts[0]
