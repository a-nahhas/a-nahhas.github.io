"""CLI smoke test: the documented command runs end to end and reconciles the store."""

import httpx

from research_agent import __main__ as cli
from research_agent.pipeline import ResearchPipeline
from tests.functional.test_pipeline_e2e import QUESTION, RouterLLM, make_pipeline, network  # noqa: F401


def test_cli_run_with_auto_review(settings, network, monkeypatch, capsys):  # noqa: F811
    monkeypatch.setattr(cli, "Settings", lambda: settings)
    monkeypatch.setattr(ResearchPipeline, "from_settings", classmethod(lambda cls, s: make_pipeline(s, RouterLLM())))
    assert cli.main(["run", QUESTION, "--approve-includes", "--show", "2"]) == 0
    out = capsys.readouterr().out
    assert "Plan (committed intentions):" in out and "ReAct trace:" in out
    assert "Coverage: 100%" in out
    assert "Store reconciles with review log: True" in out


def test_cli_evidence_listing(settings, network, monkeypatch, capsys):  # noqa: F811
    monkeypatch.setattr(cli, "Settings", lambda: settings)
    monkeypatch.setattr(ResearchPipeline, "from_settings", classmethod(lambda cls, s: make_pipeline(s, RouterLLM())))
    cli.main(["run", QUESTION, "--approve-includes"])
    capsys.readouterr()
    cli.main(["evidence"])
    out = capsys.readouterr().out
    assert "doi:" in out or "pmid:" in out


def test_cli_survives_a_cp1252_console(settings, monkeypatch):
    # REMEDIATION R13: "≥" in a title raised UnicodeEncodeError on redirected Windows output.
    import io
    import sys

    from research_agent.models import EvidenceRecord, Record, ReviewDecision
    from research_agent.store import EvidenceStore
    from tests.unit.test_store import _report
    store = EvidenceStore(settings.db_path)
    store.save_run(_report(), [])
    ev = EvidenceRecord(record=Record(source="pubmed", title="Pain fell ≥ 2 points", pmid="9", abstract="a"),
                        decision="include", reason="r")
    store.apply_review("r1", [ev], [ReviewDecision(record_key="pmid:9", decision="approve")])
    store.close()
    raw = io.BytesIO()
    monkeypatch.setattr(sys, "stdout", io.TextIOWrapper(raw, encoding="cp1252"))
    monkeypatch.setattr(cli, "Settings", lambda: settings)
    assert cli.main(["evidence"]) == 0
    sys.stdout.flush()
    assert "≥".encode("utf-8") in raw.getvalue()


def test_cli_interactive_review_with_flag_and_rescreen(settings, network, monkeypatch, capsys):  # noqa: F811
    monkeypatch.setattr(cli, "Settings", lambda: settings)
    pipe = make_pipeline(settings, RouterLLM())
    monkeypatch.setattr(ResearchPipeline, "from_settings", classmethod(lambda cls, s: pipe))
    # approve #1, flag #2 with a note, reject #3; then approve the re-screened #2.
    answers = iter(["a", "f", "is follow-up long enough?", "r", "a"])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    assert cli.main(["run", QUESTION, "--include", "Adults with chronic low back pain"]) == 0
    out = capsys.readouterr().out
    assert "fixed by the researcher" in out
    assert "1 flagged record(s) re-screened by the Curation Agent" in out
    assert "Persisted 2 approved record(s)" in out and "Store reconciles with review log: True" in out
