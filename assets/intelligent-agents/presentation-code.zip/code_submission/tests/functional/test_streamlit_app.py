"""UI tests with Streamlit's AppTest: the real app script, a fake-LLM pipeline."""

from pathlib import Path

import pytest
import streamlit as st
from streamlit.testing.v1 import AppTest

from research_agent.pipeline import ResearchPipeline
from tests.functional.test_pipeline_e2e import RouterLLM, make_pipeline, network  # noqa: F401

APP = str(Path(__file__).resolve().parents[2] / "app" / "streamlit_app.py")


def _button(at, label):
    return next(b for b in at.button if b.label == label)


def _decisions(at):
    return [r for r in at.radio if r.label == "Decision"]


@pytest.fixture
def app(settings, network, monkeypatch):  # noqa: F811
    monkeypatch.setenv("GEMINI_API_KEY", "test-key")
    pipe = make_pipeline(settings, RouterLLM())
    monkeypatch.setattr(ResearchPipeline, "from_settings", classmethod(lambda cls, s=None: pipe))
    # st.cache_resource outlives an AppTest instance; without clearing it a test can
    # receive the previous test's pipeline and patches to ``pipe`` would not apply.
    st.cache_resource.clear()
    at = AppTest.from_file(APP, default_timeout=90)
    at.run()
    return at, pipe


def test_run_review_and_store_through_the_ui(app):
    at, pipe = app
    assert not at.exception
    _button(at, "Run agent").click().run()
    assert not at.exception
    assert any("Run `" in s.value for s in at.subheader)
    assert at.metric[0].value == "100%"  # subgoal coverage

    radios = _decisions(at)
    radios[0].set_value("approve")
    radios[1].set_value("reject")
    at.text_input[1].set_value("wrong population")
    _button(at, "Submit review decisions").click().run()
    assert not at.exception
    assert any("1 approved record(s) persisted" in s.value and "True" in s.value for s in at.success)
    assert len(pipe.store.evidence()) == 1


def test_decisions_do_not_carry_over_to_a_new_run(app):
    # REMEDIATION R9: positional widget keys made the next run's record #1 show (and
    # store) the previous run's "approve".
    at, pipe = app
    _button(at, "Run agent").click().run()
    _decisions(at)[0].set_value("approve")
    _button(at, "Submit review decisions").click().run()
    first_run = at.session_state["result"].report.run_id
    feedback = next(t for t in at.text_area if t.label == "Feedback for the planner")
    feedback.set_value("Focus on randomised trials").run()
    _button(at, "Re-plan and re-run").click().run()
    assert not at.exception
    assert at.session_state["result"].report.run_id != first_run
    assert all(r.value == "skip" for r in _decisions(at))
    _button(at, "Submit review decisions").click().run()
    assert pipe.store.evidence(at.session_state["result"].report.run_id) == []


def test_flag_returns_record_to_curation_agent(app):
    at, pipe = app
    _button(at, "Run agent").click().run()
    key = at.session_state["result"].curation.evidence[0].record.key
    _decisions(at)[0].set_value("flag")
    at.text_input[0].set_value("check the population is adult")
    _button(at, "Submit review decisions").click().run()
    assert not at.exception
    assert any("re-screened by the Curation Agent" in s.value for s in at.success)
    revised = next(e for e in at.session_state["result"].curation.evidence if e.record.key == key)
    assert any("check the population is adult" in n for n in revised.validation_notes)


def test_researcher_criteria_are_used_verbatim(app):
    at, _ = app
    next(t for t in at.text_area if t.label == "Inclusion criteria").set_value("Adults over 60\nRandomised trials")
    _button(at, "Run agent").click().run()
    plan = at.session_state["result"].buffer.plan
    assert plan.inclusion_criteria == ["Adults over 60", "Randomised trials"]
    assert at.session_state["result"].report.criteria_source == "researcher"


def test_failed_runs_show_a_message_not_a_traceback(app, monkeypatch):
    # REMEDIATION R8/R12: both the first run and a re-plan go through the error boundary.
    at, pipe = app
    _button(at, "Run agent").click().run()

    def boom(**kwargs):
        raise RuntimeError("free tier down")
    monkeypatch.setattr(pipe, "run", boom)
    _button(at, "Run agent").click().run()
    assert not at.exception and any("The run failed" in e.value for e in at.error)
    # The button enables only once the script has re-run with feedback typed in.
    next(t for t in at.text_area if t.label == "Feedback for the planner").set_value("more RCTs").run()
    _button(at, "Re-plan and re-run").click().run()
    assert not at.exception and any("The run failed" in e.value for e in at.error)


def test_missing_api_key_shows_guidance(monkeypatch):
    monkeypatch.setenv("GEMINI_API_KEY", "")
    at = AppTest.from_file(APP, default_timeout=90)
    at.run()
    assert any("GEMINI_API_KEY is not set" in e.value for e in at.error)
