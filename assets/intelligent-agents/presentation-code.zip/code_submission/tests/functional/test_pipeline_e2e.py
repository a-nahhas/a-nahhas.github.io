"""Functional tests: the whole system from question to approved evidence.

Real source clients, real dedup/validation/store and the real LangGraph loop are
exercised; only the network (respx) and the LLM (a prompt-aware fake) are replaced,
so the tests are deterministic, free, and runnable without an API key.
"""

import json
import re
from pathlib import Path

import httpx
import pytest
import respx

from research_agent.curation import CurationAgent
from research_agent.models import ReviewDecision
from research_agent.pipeline import ResearchPipeline
from research_agent.sources import CrossrefClient, PubMedClient, SemanticScholarClient
from research_agent.sources.pubmed import BASE
from research_agent.sources.semantic_scholar import URL as S2_URL
from research_agent.store import EvidenceStore

FIX = Path(__file__).parent.parent / "fixtures"
QUESTION = "Does exercise therapy reduce pain in adults with chronic low back pain?"


class RouterLLM:
    """Answers by recognising which agent step sent the prompt."""

    def __init__(self, plan_reply=None):
        self.prompts = []
        self.calls = []
        self.plan_reply = plan_reply

    def complete(self, prompt, system=None):
        self.prompts.append(prompt)
        self.calls.append("fake-model")
        if "Decompose this into" in prompt:
            return json.dumps(self.plan_reply or {
                "subgoals": [
                    {"id": 1, "description": "core PICO concepts", "pubmed_query": "exercise[tiab] AND low back pain[tiab]",
                     "keyword_query": "exercise chronic low back pain", "sources": ["pubmed", "semantic_scholar"],
                     "rationale": "baseline set"},
                    {"id": 2, "description": "randomised trials", "pubmed_query": "exercise AND back pain AND rct[pt]",
                     "keyword_query": "randomized trial exercise back pain", "sources": ["pubmed"],
                     "rationale": "highest-quality primary evidence"}],
                "inclusion_criteria": ["adults with chronic low back pain", "exercise intervention"],
                "exclusion_criteria": ["acute pain"]})
        if "For EACH record below" in prompt:
            out = []
            for i in re.findall(r"\[record_index (\d+)\]", prompt):
                abstract = prompt.split(f"[record_index {i}]")[1].split("Abstract: ")[1].split("\n")[0]
                # Quote a genuine sentence from the abstract, as the prompt demands.
                sentence = abstract[:150]
                out.append({"record_index": int(i), "decision": "include", "relevance": 0.8,
                            "reason": "adult CLBP population with an exercise arm",
                            "claims": [{"text": "exercise improved pain", "supporting_extract": sentence}]})
            return json.dumps({"screenings": out})
        raise AssertionError(f"unexpected prompt: {prompt[:80]}")


@pytest.fixture
def network():
    with respx.mock(assert_all_called=False) as mock:
        mock.get(f"{BASE}/esearch.fcgi").mock(return_value=httpx.Response(
            200, text=(FIX / "pubmed_esearch.json").read_text()))
        mock.get(f"{BASE}/efetch.fcgi").mock(return_value=httpx.Response(
            200, text=(FIX / "pubmed_efetch.xml").read_text(encoding="utf-8")))
        mock.get(S2_URL).mock(return_value=httpx.Response(200, text=(FIX / "s2_search.json").read_text()))
        mock.get("https://api.crossref.org/works").mock(return_value=httpx.Response(200, json={"message": {"items": []}}))
        yield mock


def make_pipeline(settings, llm, store=None):
    http = httpx.Client()
    return ResearchPipeline(
        llm=llm,
        sources={"pubmed": PubMedClient(http, min_interval=0), "semantic_scholar": SemanticScholarClient(http)},
        crossref=CrossrefClient(http, min_interval=0), settings=settings,
        store=store or EvidenceStore(settings.db_path))


def test_question_to_approved_evidence(settings, network):
    llm = RouterLLM()
    pipe = make_pipeline(settings, llm)
    result = pipe.run(QUESTION)

    # Planning and retrieval
    r = result.report
    assert r.n_subgoals == 2 and r.coverage == 1.0 and r.failed_subgoals == {}
    # 2 PubMed records per subgoal x 2 subgoals + 2 valid S2 records = 6, of which the
    # repeated PubMed records and the S2 copy of PMID 38035307 are duplicates.
    assert r.n_retrieved == 6 and r.n_after_dedup == 3
    assert r.models_used == {"fake-model": 2}  # 1 planning + 1 screening batch

    # The hand-off buffer is a real artefact that validates against the schema.
    for name in ("buffer.json", "curation.json", "report.json"):
        assert (result.run_dir / name).exists()
    on_disk = json.loads((result.run_dir / "buffer.json").read_text(encoding="utf-8"))
    assert on_disk["plan"]["subgoals"][0]["id"] == 1 and len(on_disk["query_log"]) == 3

    # Curation: every screened claim is traceable to an identifier and a verified extract.
    screened = [e for e in result.curation.evidence if e.screened]
    assert screened and all(e.claims for e in screened)
    for e in screened:
        assert e.record.pmid or e.record.doi or e.record.s2_id
        assert all(c.supporting_extract.lower()[:30] in e.record.abstract.lower() for c in e.claims)
        # No DOI means Crossref cannot be asked; that must read "unknown", never "active".
        assert e.publication_status == ("active" if e.record.doi else "unknown")

    # Human gate: approve one, reject one, flag one -> only the approval is stored.
    keys = [e.record.key for e in screened]
    decisions = [ReviewDecision(record_key=keys[0], decision="approve"),
                 ReviewDecision(record_key=keys[1], decision="reject", note="wrong population"),
                 ReviewDecision(record_key=keys[2], decision="flag")]
    assert pipe.review(result, decisions) == 1
    stored = pipe.store.evidence(r.run_id)
    assert [s["record_key"] for s in stored] == [keys[0]]
    assert json.loads(stored[0]["claims_json"])[0]["supporting_extract"]
    assert pipe.store.reconcile(r.run_id)["ok"]
    assert len((result.run_dir / "review_log.jsonl").read_text().splitlines()) == 3
    assert len(pipe.store.query_log(r.run_id)) == 3


def test_semantic_scholar_outage_is_reported_not_hidden(settings, network, monkeypatch):
    monkeypatch.setattr("research_agent.sources.http.time.sleep", lambda s: None)
    network.get(S2_URL).mock(return_value=httpx.Response(429))
    result = make_pipeline(settings, RouterLLM()).run(QUESTION)
    log = result.buffer.query_log
    assert any(q.source == "semantic_scholar" and q.status == "error" and "429" in q.error for q in log)
    # PubMed still delivered, so the subgoal counts as covered, with the failure on record.
    assert result.report.coverage == 1.0 and result.report.n_after_dedup == 2
    # REMEDIATION R11: subgoal coverage alone hid that S2 contributed nothing.
    assert result.report.sources_unavailable == ["semantic_scholar"]
    assert result.report.source_status["semantic_scholar"].ok == 0
    assert result.report.source_status["pubmed"].records == 4


def test_reviewer_feedback_triggers_replan(settings, network):
    llm = RouterLLM()
    pipe = make_pipeline(settings, llm)
    first = pipe.run(QUESTION)
    second = pipe.run(QUESTION, feedback="Too many reviews; focus on RCTs in older adults", previous=first.buffer)
    replan_prompt = [p for p in llm.prompts if "Decompose this into" in p][-1]
    assert "REVISION" in replan_prompt and "older adults" in replan_prompt
    assert second.buffer.trace[0].kind == "replan" and second.report.run_id != first.report.run_id


def test_unplannable_question_escalates_and_skips_curation(settings, network):
    llm = RouterLLM(plan_reply={"subgoals": []})
    result = make_pipeline(settings, llm).run(QUESTION)
    assert result.curation is None and result.report.needs_human
    assert result.report.coverage == 0.0
    assert len([p for p in llm.prompts if "Decompose" in p]) == settings.max_schema_retries + 1


def test_store_persists_across_sessions(settings, network):
    pipe = make_pipeline(settings, RouterLLM())
    result = pipe.run(QUESTION)
    key = next(e.record.key for e in result.curation.evidence if e.screened)
    pipe.review(result, [ReviewDecision(record_key=key, decision="approve")])
    pipe.store.close()
    reopened = EvidenceStore(settings.db_path)
    assert [r["record_key"] for r in reopened.evidence()] == [key]
    assert reopened.reconcile(result.report.run_id)["ok"]


def test_curation_rejects_hand_edited_buffer(settings, network):
    """The buffer is a contract: a tampered hand-off fails validation instead of propagating."""
    from pydantic import ValidationError

    from research_agent.models import ResultsBuffer
    result = make_pipeline(settings, RouterLLM()).run(QUESTION)
    path = result.run_dir / "buffer.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    data["records"][0]["source"] = "google_scholar"
    path.write_text(json.dumps(data), encoding="utf-8")
    # This is exactly how the pipeline loads the hand-off before curation.
    with pytest.raises(ValidationError, match="source"):
        CurationAgent(RouterLLM(), settings=settings).run(ResultsBuffer.model_validate_json(path.read_text("utf-8")))


def test_report_records_settings_and_criteria_source(settings, network):
    result = make_pipeline(settings, RouterLLM()).run(QUESTION, criteria=(["Adults"], []))
    rep = json.loads((result.run_dir / "report.json").read_text(encoding="utf-8"))
    assert rep["criteria_source"] == "researcher"
    assert rep["settings"]["screen_limit"] == settings.screen_limit and rep["settings"]["pubmed_sort"] == "relevance"
    assert "gemini_api_key" not in rep["settings"]


def test_flagged_records_return_to_curation_and_stay_out_of_the_store(settings, network):
    pipe = make_pipeline(settings, RouterLLM())
    result = pipe.run(QUESTION)
    key = result.curation.evidence[0].record.key
    flag = [ReviewDecision(record_key=key, decision="flag", note="check follow-up length")]
    pipe.review(result, flag)
    assert pipe.revise_flagged(result, flag) == 1
    revised = next(e for e in result.curation.evidence if e.record.key == key)
    assert "revised after reviewer flag: check follow-up length" in revised.validation_notes
    assert pipe.store.evidence(result.report.run_id) == []
    on_disk = json.loads((result.run_dir / "curation.json").read_text(encoding="utf-8"))
    assert any("check follow-up length" in n for e in on_disk["evidence"] for n in e["validation_notes"])
