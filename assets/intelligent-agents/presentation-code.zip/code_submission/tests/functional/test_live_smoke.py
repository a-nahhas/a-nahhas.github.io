"""Live smoke tests against the real services. Opt-in: ``pytest -m live``.

Kept separate because they depend on network, quota and third-party uptime; they
show the integrations work for real, while the rest of the suite stays deterministic.
"""

import pytest

from research_agent.config import Settings
from research_agent.llm import GeminiLLM, generate_structured
from research_agent.models import SubgoalPlan
from research_agent.planning import PLAN_PROMPT, PLANNER_SYSTEM
from research_agent.sources import CrossrefClient, PubMedClient, make_client

pytestmark = pytest.mark.live


def test_pubmed_live_returns_traceable_records():
    recs = PubMedClient(make_client()).search('"chronic low back pain"[tiab] AND exercise[tiab]', 3, 1)
    assert len(recs) == 3 and all(r.pmid and r.title for r in recs)


def test_crossref_live_detects_a_known_retraction():
    # Wakefield et al. (1998), retracted by The Lancet in 2010.
    assert CrossrefClient(make_client()).status("10.1016/s0140-6736(97)11096-0") == "retracted"


def test_gemini_live_produces_a_valid_plan():
    s = Settings()
    if not s.gemini_api_key:
        pytest.skip("GEMINI_API_KEY not set")
    llm = GeminiLLM(s.gemini_api_key, [s.model, *s.fallback_models], min_interval=0)
    plan = generate_structured(llm, PLAN_PROMPT.format(
        question="Does yoga reduce pain in adults with chronic neck pain?", min_n=2, max_n=4, feedback=""),
        SubgoalPlan, system=PLANNER_SYSTEM)
    assert 1 <= len(plan.subgoals) and plan.inclusion_criteria
