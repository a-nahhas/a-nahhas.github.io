"""Shared test doubles.

Fakes rather than mocks of internals: the agents only see the ``search`` interface
and the ``LLM`` protocol, so tests exercise the real agent logic end to end.
"""

from dataclasses import replace

import pytest

from research_agent.config import Settings
from research_agent.models import Record
from research_agent.sources import RetrievalError


class FakeSource:
    """Returns scripted results per query; an Exception instance is raised instead."""

    def __init__(self, name, by_query=None, default=None):
        self.name, self.by_query, self.default, self.calls = name, by_query or {}, default, []

    def search(self, query, n, subgoal_id):
        self.calls.append(query)
        out = self.by_query.get(query, self.default if self.default is not None else [])
        if isinstance(out, Exception):
            raise out
        return [r.model_copy(update={"subgoal_ids": [subgoal_id]}) for r in out][:n]


def rec(i, source="pubmed", abstract=None, **kw):
    return Record(source=source, title=f"Study number {i} on exercise and back pain outcomes {i * 7919}",
                  pmid=str(1000 + i) if source == "pubmed" else None,
                  s2_id=f"s{i}" if source == "semantic_scholar" else None,
                  abstract=abstract or f"Abstract {i}. Exercise reduced pain by {i} points versus control.", **kw)


def plan_json(n=2, sources=("pubmed", "semantic_scholar")):
    return {"subgoals": [{"id": i, "description": f"subgoal {i} description", "pubmed_query": f"pq{i}",
                          "keyword_query": f"kq{i}", "sources": list(sources), "rationale": f"because {i}"}
                         for i in range(1, n + 1)],
            "inclusion_criteria": ["adults with chronic low back pain"], "exclusion_criteria": ["surgery"]}


@pytest.fixture
def settings(tmp_path):
    return replace(Settings(), db_path=tmp_path / "e.db", runs_dir=tmp_path / "runs", llm_min_interval=0)


@pytest.fixture
def boom():
    return RetrievalError("HTTP 429 after 4 attempts")
