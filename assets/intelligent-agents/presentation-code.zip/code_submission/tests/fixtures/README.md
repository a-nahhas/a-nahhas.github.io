# Test fixtures

* `pubmed_esearch.json`, `pubmed_efetch.xml` - real NCBI E-utilities responses recorded on 2026-10-12
  for the query `exercise therapy chronic low back pain` (PMIDs 38035307, 39054514).
* `s2_search.json` - **synthetic**, written to the documented Semantic Scholar Graph API response format,
  because the unauthenticated endpoint returned HTTP 429 on every recording attempt. It deliberately includes
  a record that duplicates a PubMed record (to exercise dedup) and a malformed record with a null title.
