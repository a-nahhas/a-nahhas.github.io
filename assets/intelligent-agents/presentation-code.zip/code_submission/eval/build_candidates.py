"""Build the candidate pool for the labelled evaluation set.

The pool mixes likely includes with deliberate near-misses (wrong population,
wrong condition duration, passive-only interventions, protocols). A pool of only
obvious includes would make recall trivially high and say nothing about screening.

Usage:  python -m eval.build_candidates  ->  eval/candidates.json
This script never labels. Labels live in eval/gold_set.json"""

from __future__ import annotations

import json
from pathlib import Path

from research_agent.sources import PubMedClient, make_client

QUESTION = ("Does exercise therapy reduce pain intensity in adults with chronic non-specific low back pain?")

# (query, n): stratified so the pool is not dominated by one kind of record.
STRATA = [
    ('"chronic low back pain"[tiab] AND exercise[tiab] AND randomized controlled trial[pt]', 8),
    ('"chronic low back pain"[tiab] AND exercise[tiab] AND systematic review[pt]', 4),
    ('"acute low back pain"[tiab] AND exercise[tiab] AND randomized controlled trial[pt]', 3),
    ('"neck pain"[tiab] AND exercise[tiab] AND randomized controlled trial[pt]', 3),
    ('adolescents[tiab] AND "low back pain"[tiab] AND exercise[tiab]', 2),
    ('"low back pain"[tiab] AND (electrotherapy[tiab] OR TENS[tiab]) AND randomized controlled trial[pt]', 3),
    ('"chronic low back pain"[tiab] AND exercise[tiab] AND "study protocol"[ti]', 3),
    ('"lumbar spinal stenosis"[tiab] AND exercise[tiab] AND randomized controlled trial[pt]', 2),
]


def main() -> None:
    pm = PubMedClient(make_client())
    seen, pool = set(), []
    for i, (query, n) in enumerate(STRATA, start=1):
        for r in pm.search(query, n, subgoal_id=i):
            if r.pmid in seen or not r.abstract:
                continue
            seen.add(r.pmid)
            pool.append({"stratum": query, **r.model_dump(include={"pmid", "doi", "title", "abstract", "year",
                                                                    "journal", "authors"})})
    out = Path(__file__).with_name("candidates.json")
    out.write_text(json.dumps({"question": QUESTION, "records": pool}, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"{len(pool)} candidates -> {out}")


if __name__ == "__main__":
    main()
