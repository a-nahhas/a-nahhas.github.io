# Evaluation results

**Results file:** `eval/results/eval_20261012T161944Z.json`. Three live runs after the code-review fixes. Metrics
were recomputed from the stored per-run decisions once the labels were corrected; no new LLM calls were made.

**Earlier results:** `eval/results/eval_20261012T143306Z.json`, from before the fixes. Kept for history only.

## Method

- **The set.** 28 real PubMed records (10 includes, 18 excludes), built by `eval/build_candidates.py` from stratified
  queries. It includes deliberate near-misses: acute pain, neck pain, adolescents, passive-only therapy, protocols,
  spinal stenosis, and trials without a pain-intensity outcome.
- **Retrieval is held fixed.** Every run screens the same records against the same fixed criteria, so the numbers
  measure screening and extraction only. **The search step itself is not measured.**
- **Screening.** Every record is screened, with the production cut-off lifted. Its effect is computed separately:
  records ranked below the BM25 top 20 would never reach the LLM in a normal run.
- **Runs.** Gemini's free-tier quota for the larger models was used up on the day, so failover served all three runs
  from `gemini-3.1-flash-lite`.

## Results

| Run | Recall: sent to reviewer | Recall: strict include | Recall at default cut-off | Specificity | Precision (include) | Claims kept / proposed | Store reconciles |
|----|----|----|----|----|----|----|----|
| 1 | 1.0 | 1.0 | 0.9 | 0.833 | 0.769 | 19 / 19 | yes |
| 2 | 1.0 | 1.0 | 0.9 | 0.833 | 0.909 | 24 / 24 | yes |
| 3 | 1.0 | 1.0 | 0.9 | 0.833 | 0.909 | 20 / 21 | yes |

| Success criterion (proposal 2.2) | Status |
|---|---|
| Recall ≥ 0.80 against a hand-screened sample | Recall is **1.0** in all three runs, or **0.9** with the default screening cut-off. The reference standard is AI-checked, not hand-screened. |
| Traceability: every claim resolves to an ID and an extract | **Guaranteed by design:** the validator drops any claim that lacks an ID and a verified extract. In run 3 it rejected 1 of 21 claims. |
| Fidelity: no claim absent from its abstract (20-record audit) | Every extract was verified automatically. **18 of 19 claims faithful across 13 records.** One claim overgeneralises its extract. Only 13 distinct records kept claims, so 20 was not reachable. |
| Storage reconciles with the decision log | **Met in every run.** |

## Findings

* **No relevant record was lost.** Every labelled include was sent to the reviewer in every run.
* **The production cut-off costs recall.** One include (PMID 39054514) ranks below the BM25 top 20. In a normal run
  it would be listed as "unscreened" for the reviewer rather than screened, so recall drops to 0.9. That still meets
  the target, but a larger set could fall below it.
* **The consistent error is over-inclusion on outcome type.** In all three runs the agent included PMID 39048701,
  which measures pain *sensitisation*, not pain intensity. In run 1 it also included two trial protocols. These
  errors favour recall over precision, which suits a first-pass screen because the reviewer removes them. Even so,
  criteria about outcome type are where the screener is weakest.
* **The fidelity audit found one overgeneralisation.** The extract was genuine, but the claim generalised beyond it.
  The word-level validator cannot catch this, which is why claim and extract are always shown side by side.
* **Results vary between runs.** The three runs used the same model yet treated borderline excludes differently, and
  the pre-fix runs on other models differed again. This is why the human gate is essential.

## Deviations from the proposal

* **Size and screening.** 28 AI-checked records instead of 50 hand-screened abstracts, so one record moves recall by
  0.1.
* **Two recall measures.** Recall is reported both as "sent to reviewer" (include or uncertain) and as strict include.
* **The fidelity audit** was done by AI, not by a human auditor.
