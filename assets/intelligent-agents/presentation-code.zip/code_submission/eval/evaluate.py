"""Evaluate the Curation Agent against the labelled set (proposal, section 2.2).

Retrieval is held fixed: every run screens the same records with the same criteria,
so differences in the numbers come from the screening step itself rather than from
what the search happened to return that day. Consequence, stated plainly: this does
not measure retrieval quality, only screening and extraction.

Metrics
  * recall (operative): labelled includes the agent sends to the human (include OR
    uncertain). An 'uncertain' record is not lost - it goes to the reviewer - so this
    is the recall that matters for a screening aid. Records that are "uncertain" only
    because the LLM call failed are counted separately (``n_screening_failures``) and
    ``recall_llm`` treats them as misses, so an outage cannot inflate recall.
  * recall at the production cut-off: the run screens everything (screen_limit is
    lifted), and the effect of the default BM25 cut-off is computed separately:
    labelled includes ranked below it would never reach the LLM in a normal run.
  * claim validation pass rate: retained / proposed claims. Traceability itself is
    guaranteed by construction (the validator drops any claim without an ID and a
    verified extract), so it is reported as a property, not as a finding.
  * fidelity: paraphrase faithfulness needs a human; an audit sheet of up to 20
    records (pooled across runs) is written for the researcher to complete.
  * storage: approve every agent-included labelled include, then reconcile the store.

Usage:  python -m eval.evaluate [--runs N]
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from research_agent.config import Settings
from research_agent.curation import CurationAgent, bm25_scores
from research_agent.llm import GeminiLLM
from research_agent.models import Record, ResultsBuffer, ReviewDecision, SubgoalPlan
from research_agent.store import EvidenceStore

HERE = Path(__file__).parent


def load_gold() -> tuple[dict, list[Record]]:
    gold = json.loads((HERE / "gold_set.json").read_text(encoding="utf-8"))
    records = [Record(source="pubmed", subgoal_ids=[1], **{k: r[k] for k in
                      ("pmid", "doi", "title", "abstract", "year", "journal", "authors")}) for r in gold["records"]]
    return gold, records


def evaluate_once(llm, settings: Settings, gold: dict, records: list[Record], production_limit: int = 20) -> dict:
    plan = SubgoalPlan(
        subgoals=[{"id": 1, "description": "fixed evaluation set", "pubmed_query": "n/a", "keyword_query": "n/a",
                   "sources": ["pubmed"], "rationale": "retrieval held fixed for evaluation"}],
        inclusion_criteria=gold["criteria"]["inclusion"], exclusion_criteria=gold["criteria"]["exclusion"])
    buf = ResultsBuffer(run_id="eval-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S"),
                        question=gold["question"], plan=plan, records=records)
    report = CurationAgent(llm, crossref=None, settings=settings).run(buf)

    label = {r["pmid"]: r["gold_label"] for r in gold["records"]}
    by_pmid = {e.record.pmid: e for e in report.evidence}
    gold_inc = [p for p, lab in label.items() if lab == "include"]
    gold_exc = [p for p, lab in label.items() if lab == "exclude"]
    failed = {p for p, e in by_pmid.items() if "missing LLM screening" in e.validation_notes}
    sent = [p for p in gold_inc if by_pmid[p].decision in ("include", "uncertain")]
    sent_by_llm = [p for p in sent if p not in failed]
    strict = [p for p in gold_inc if by_pmid[p].decision == "include"]
    # Effect of the production cut-off (only the top-N BM25 records reach the LLM).
    query = " ".join([gold["question"], *gold["criteria"]["inclusion"]])
    scores = bm25_scores(query, [f"{r.title} {r.abstract}" for r in records])
    ranked = [r.pmid for r, _ in sorted(zip(records, scores), key=lambda x: x[1], reverse=True)]
    within = set(ranked[:production_limit])
    excl_ok = [p for p in gold_exc if by_pmid[p].decision == "exclude"]
    agent_inc = [p for p, e in by_pmid.items() if e.decision == "include"]

    claims = [(e, c) for e in report.evidence for c in e.claims]
    proposed = len(claims) + report.n_claims_rejected

    store = EvidenceStore(":memory:")
    from research_agent.pipeline import build_report
    store.save_run(build_report(buf, report), [])
    decisions = [ReviewDecision(record_key=by_pmid[p].record.key, decision="approve", reviewer="eval")
                 for p in gold_inc if p in agent_inc]
    decisions += [ReviewDecision(record_key=by_pmid[p].record.key, decision="reject", reviewer="eval")
                  for p in agent_inc if p not in gold_inc]
    store.apply_review(buf.run_id, report.evidence, decisions)
    recon = store.reconcile(buf.run_id)

    return {
        "run_id": buf.run_id,
        "models_used": dict(__import__("collections").Counter(getattr(llm, "calls", []))),
        "n_records": len(records), "n_gold_include": len(gold_inc), "n_gold_exclude": len(gold_exc),
        "recall_operative": round(len(sent) / len(gold_inc), 3),
        "recall_strict": round(len(strict) / len(gold_inc), 3),
        "recall_llm": round(len(sent_by_llm) / len(gold_inc), 3),
        "n_screening_failures": len(failed),
        "production_limit": production_limit,
        "recall_operative_at_production_cutoff": round(len([p for p in sent if p in within]) / len(gold_inc), 3),
        "includes_below_cutoff": [p for p in gold_inc if p not in within],
        "specificity": round(len(excl_ok) / len(gold_exc), 3),
        "precision_strict": round(len([p for p in agent_inc if label[p] == "include"]) / len(agent_inc), 3)
        if agent_inc else None,
        "missed_includes": [{"pmid": p, "agent": by_pmid[p].decision, "reason": by_pmid[p].reason} for p in gold_inc
                            if p not in sent],
        "false_includes": [{"pmid": p, "reason": by_pmid[p].reason, "gold_reason": next(
            r["label_reason"] for r in gold["records"] if r["pmid"] == p)} for p in agent_inc if label[p] == "exclude"],
        "claims_retained": len(claims), "claims_proposed": proposed,
        "claim_validation_pass_rate": round(len(claims) / proposed, 3) if proposed else None,
        "traceability_note": "100% by construction: claims without an ID and a verified extract are dropped",
        "store_reconciles": recon["ok"], "store_counts": {"expected": recon["expected"], "stored": recon["stored"]},
        "decisions": {p: by_pmid[p].decision for p in label},
        "_evidence": report.evidence,
    }


def write_audit_sheet(results: list[dict], path: Path, n: int = 20) -> int:
    """Human fidelity audit: does each claim say only what its extract says?

    Pooled across runs because a single run may retain claims for fewer than ``n``
    records (only included/uncertain records carry claims). Returns records covered.
    """
    rows, pmids = [], []
    for res in results:
        for e in res["_evidence"]:
            if not e.claims or e.record.pmid in pmids or len(pmids) >= n:
                continue
            pmids.append(e.record.pmid)
            rows += [(res["run_id"], e.record.pmid, e.record.title, c.text, c.supporting_extract) for c in e.claims]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["run_id", "pmid", "title", "claim", "supporting_extract",
                    "claim_faithful_to_extract (Y/N)", "auditor_note"])
        w.writerows([*r, "", ""] for r in rows)
    return len(pmids)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=1, help="repeat to measure run-to-run variability")
    args = ap.parse_args()
    s = Settings()
    # Screen everything in the set; the screening cut-off is a production economy,
    # not something we want to confound the measurement with.
    production_limit = s.screen_limit
    s = replace(s, screen_limit=1000)
    gold, records = load_gold()
    out_dir = HERE / "results"
    out_dir.mkdir(exist_ok=True)
    results = []
    for i in range(args.runs):
        llm = GeminiLLM(s.gemini_api_key, [s.model, *s.fallback_models], s.llm_min_interval)
        r = evaluate_once(llm, s, gold, records, production_limit)
        results.append(r)
        print(f"run {i + 1}: recall(operative)={r['recall_operative']} recall(strict)={r['recall_strict']} "
              f"recall(llm)={r['recall_llm']} at-cutoff={r['recall_operative_at_production_cutoff']} "
              f"specificity={r['specificity']} claims kept={r['claims_retained']}/{r['claims_proposed']} "
              f"screening failures={r['n_screening_failures']} store_ok={r['store_reconciles']} "
              f"models={r['models_used']}")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    n_audit = write_audit_sheet(results, out_dir / f"fidelity_audit_{stamp}.csv")
    print(f"fidelity audit sheet covers {n_audit} record(s)")
    summary = {
        "label_status": gold["label_status"], "verified_by": gold["verified_by"], "runs": len(results),
        "recall_operative_mean": round(statistics.mean(r["recall_operative"] for r in results), 3),
        "recall_strict_mean": round(statistics.mean(r["recall_strict"] for r in results), 3),
        "specificity_mean": round(statistics.mean(r["specificity"] for r in results), 3),
        "fidelity_audit_records": n_audit,
        "per_run": [{k: v for k, v in r.items() if not k.startswith("_")} for r in results],
    }
    path = out_dir / f"eval_{stamp}.json"
    path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"results -> {path}")


if __name__ == "__main__":
    main()
