"""Streamlit interface: question in, plan and trace visible, human review gate, store.

Streamlit was chosen for the prototype UI because it is free, pure Python and fast
to build, so effort goes into the agents rather than front-end code. Its rerun-on-
interaction model is handled by keeping the pipeline in ``st.cache_resource`` and
the current run in ``st.session_state``.

Run with:  streamlit run app/streamlit_app.py
"""

from __future__ import annotations

import hashlib
import sys
from dataclasses import replace
from pathlib import Path

import pandas as pd
import streamlit as st

# Make the package importable when launched via `streamlit run` from the repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from research_agent.config import Settings  # noqa: E402
from research_agent.models import ReviewDecision  # noqa: E402
from research_agent.pipeline import ResearchPipeline, RunResult  # noqa: E402

st.set_page_config(page_title="Research Planning Agent", layout="wide")

BADGE = {"include": "🟢 include", "uncertain": "🟡 uncertain", "exclude": "🔴 exclude"}
STATUS = {"active": "active", "retracted": "⚠️ RETRACTED", "corrected": "corrected", "unknown": "status unknown"}
RUN_HINT = "free-tier rate limits make this take 2-5 minutes"


def _lines(text: str) -> list[str]:
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


def run_safely(pipe: ResearchPipeline, label: str, **kwargs) -> None:
    """Every agent run goes through here so no button can surface a raw traceback."""
    with st.spinner(f"{label}… ({RUN_HINT})"):
        try:
            st.session_state.result = pipe.run(**kwargs)
            st.session_state.review_round = 0
            st.session_state.flash = None
        except Exception as exc:  # noqa: BLE001 - any failure is shown as a message, the app keeps running
            st.error(f"The run failed: {type(exc).__name__}: {exc}. Free-tier services are intermittently "
                     "unavailable; please try again in a minute.")


@st.cache_resource(show_spinner=False)
def get_pipeline(max_subgoals: int, per_subgoal: int, screen_limit: int) -> ResearchPipeline:
    s = replace(Settings(), max_subgoals=max_subgoals, results_per_subgoal=per_subgoal, screen_limit=screen_limit)
    return ResearchPipeline.from_settings(s)


def sidebar() -> tuple[int, int, int]:
    s = Settings()
    st.sidebar.header("Configuration")
    st.sidebar.write(f"**LLM:** `{s.model}` (fallbacks: {', '.join(s.fallback_models)})")
    st.sidebar.write("**API key:** " + ("set ✅" if s.gemini_api_key else "missing ❌ (see README)"))
    st.sidebar.caption("Sources: PubMed (E-utilities), Semantic Scholar, Crossref (status).")
    max_sg = st.sidebar.slider("Max subgoals", 2, 6, s.max_subgoals)
    per_sg = st.sidebar.slider("Results per subgoal per source", 3, 15, s.results_per_subgoal)
    limit = st.sidebar.slider("Records sent to LLM screening", 5, 40, s.screen_limit)
    st.sidebar.caption("Lower values use less of the free-tier quota.")
    return max_sg, per_sg, limit


def show_plan(r: RunResult) -> None:
    if not r.buffer.plan:
        st.error(r.report.needs_human or "No plan produced.")
        return
    plan = r.buffer.plan
    st.dataframe(pd.DataFrame([{"#": s.id, "Subgoal": s.description, "PubMed query": s.pubmed_query,
                                "Keyword query": s.keyword_query, "Sources": ", ".join(s.sources),
                                "Rationale": s.rationale} for s in plan.subgoals]),
                 hide_index=True, use_container_width=True)
    c1, c2 = st.columns(2)
    c1.markdown("**Inclusion criteria**\n" + "\n".join(f"- {c}" for c in plan.inclusion_criteria))
    c2.markdown("**Exclusion criteria**\n" + "\n".join(f"- {c}" for c in plan.exclusion_criteria or ["none"]))


def show_trace(r: RunResult) -> None:
    icon = {"plan": "🧭", "replan": "🔁", "thought": "💭", "action": "⚙️", "observation": "👁️", "escalation": "🚨"}
    for t in r.buffer.trace:
        sg = f"`sg {t.subgoal_id}` " if t.subgoal_id else ""
        st.markdown(f"{icon.get(t.kind, '')} **{t.kind}** {sg}{t.content}")
    with st.expander("Query log (reproducibility record)"):
        st.dataframe(pd.DataFrame([q.model_dump() for q in r.buffer.query_log]), hide_index=True,
                     use_container_width=True)


def show_report(r: RunResult) -> None:
    rep = r.report
    if rep.needs_human:
        # Figure 2's "flag for human review" branch: shown up front, not only in the Plan tab.
        st.error(f"Needs human attention: {rep.needs_human}")
    for name in rep.sources_unavailable:
        st.warning(f"{name} returned no results for the whole run (every call failed or was skipped); "
                   "the evidence below comes from the other source(s) only.")
    c = st.columns(5)
    c[0].metric("Subgoal coverage", f"{rep.coverage:.0%}")
    c[1].metric("Retrieved → unique", f"{rep.n_retrieved} → {rep.n_after_dedup}")
    c[2].metric("Screened", rep.n_screened)
    c[3].metric("Include / uncertain / exclude", f"{rep.n_include} / {rep.n_uncertain} / {rep.n_exclude}")
    c[4].metric("Claims rejected", rep.n_claims_rejected)
    for sg, why in rep.failed_subgoals.items():
        st.warning(f"Subgoal {sg} failed: {why}")
    if rep.n_not_screened or rep.n_no_abstract:
        st.info(f"{rep.n_not_screened} record(s) below the screening cut-off and {rep.n_no_abstract} without an "
                "abstract were not screened; they are listed at the end of the review tab.")
    src = {"researcher": "fixed by the researcher", "llm": "proposed by the LLM"}.get(rep.criteria_source, "n/a")
    st.caption(f"Eligibility criteria: {src} · LLM calls by model: {rep.models_used or '-'}")


def review_tab(pipe: ResearchPipeline, r: RunResult) -> None:
    if not r.curation:
        return
    show_ex = st.checkbox("Show records screened as exclude", value=False)
    show_un = st.checkbox("Show unscreened records", value=False)
    items = [e for e in r.curation.evidence
             if (e.screened or show_un) and (e.decision != "exclude" or show_ex)]
    st.caption("Every claim shows its verbatim supporting extract. Only records you approve enter the evidence "
               "table; flagging a record sends it back to the Curation Agent with your note.")
    if st.session_state.get("flash"):
        st.success(st.session_state.flash)
    # Widget keys are tied to the run, the review round and the record, never to list
    # position: positional keys carried one run's decisions onto a different record in
    # the next run (REMEDIATION R9). clear_on_submit stops an accidental re-submit.
    round_ = st.session_state.get("review_round", 0)
    with st.form(f"review_{r.report.run_id}_{round_}", clear_on_submit=True):
        choices = {}
        for i, e in enumerate(items):
            rec = e.record
            wk = hashlib.sha1(f"{r.report.run_id}|{round_}|{rec.key}".encode()).hexdigest()[:12]
            links = []
            if rec.pmid:
                links.append(f"[PMID {rec.pmid}](https://pubmed.ncbi.nlm.nih.gov/{rec.pmid}/)")
            if rec.doi:
                links.append(f"[doi:{rec.doi}](https://doi.org/{rec.doi})")
            st.markdown(f"#### {i + 1}. {rec.title}")
            st.markdown(f"{BADGE[e.decision]} · relevance {e.relevance:.2f} · {rec.year or 'n.d.'} · "
                        f"{rec.journal or ''} · {' · '.join(links)} · {STATUS[e.publication_status]} · "
                        f"_{rec.evidence_basis}_")
            st.markdown(f"**Screening reason:** {e.reason}")
            for c in e.claims:
                st.markdown(f"- {c.text}\n\n  > {c.supporting_extract}")
            for c in e.rejected_claims:
                st.markdown(f"- ~~{c.text}~~ — rejected, extract not found in abstract: _{c.supporting_extract}_")
            for n in e.validation_notes:
                st.warning(n)
            with st.expander("Abstract"):
                st.write(rec.abstract or "No abstract available.")
            cols = st.columns([2, 3])
            choices[rec.key] = (
                cols[0].radio("Decision", ["skip", "approve", "flag", "reject"], horizontal=True, key=f"d_{wk}",
                              index=0),
                cols[1].text_input("Note (sent to the Curation Agent if flagged)", key=f"n_{wk}"),
            )
            st.divider()
        submitted = st.form_submit_button("Submit review decisions", type="primary")
    if submitted:
        decisions = [ReviewDecision(record_key=k, decision=d, note=n) for k, (d, n) in choices.items() if d != "skip"]
        n = pipe.review(r, decisions)
        rec = pipe.store.reconcile(r.report.run_id)
        msg = (f"Logged {len(decisions)} decision(s); {n} approved record(s) persisted. "
               f"Store reconciles with review log: {rec['ok']} ({rec['stored']} stored).")
        if any(d.decision == "flag" for d in decisions):
            # Figure 2: Flag -> return to the Curation Agent for revision, then decide again.
            with st.spinner("Returning flagged records to the Curation Agent…"):
                try:
                    k = pipe.revise_flagged(r, decisions)
                    msg += f" {k} flagged record(s) were re-screened by the Curation Agent; review them again below."
                except Exception as exc:  # noqa: BLE001
                    msg += f" Re-screening failed ({type(exc).__name__}); the flags are logged."
            st.session_state.review_round = round_ + 1
            st.session_state.flash = msg
            st.rerun()
        st.success(msg)


def main() -> None:
    st.title("LLM-powered academic research planning agent")
    st.caption("Planning & Retrieval Agent → JSON buffer → Curation Agent → human review → evidence store")
    cfg = sidebar()
    if not Settings().gemini_api_key:
        st.error("GEMINI_API_KEY is not set. Copy .env.example to .env and add a free-tier key.")
        return
    pipe = get_pipeline(*cfg)

    question = st.text_area("Health-sciences research question",
                            "Does exercise therapy reduce pain intensity in adults with chronic non-specific "
                            "low back pain?", height=80)
    with st.expander("Eligibility criteria (optional; recommended for a systematic review protocol)"):
        st.caption("If given, these are used exactly as written and the LLM may not change them. "
                   "Leave blank to let the planner propose criteria. One criterion per line.")
        inc = st.text_area("Inclusion criteria", key="inc_criteria")
        exc_ = st.text_area("Exclusion criteria", key="exc_criteria")
    criteria = (_lines(inc), _lines(exc_)) if _lines(inc) else None
    if st.button("Run agent", type="primary", disabled=not question.strip()):
        run_safely(pipe, "Planning, retrieving and curating", question=question.strip(), criteria=criteria)

    r: RunResult | None = st.session_state.get("result")
    if not r:
        return
    st.subheader(f"Run `{r.report.run_id}`")
    show_report(r)
    tabs = st.tabs(["Review evidence", "Plan", "ReAct trace", "Revise subgoals", "Evidence store"])
    with tabs[0]:
        review_tab(pipe, r)
    with tabs[1]:
        show_plan(r)
    with tabs[2]:
        show_trace(r)
    with tabs[3]:
        st.write("If the results miss the mark, tell the planner what to change. It re-plans with your feedback "
                 "and the previous plan, then runs again (Figure 2, 'revise the subgoals').")
        fb = st.text_area("Feedback for the planner", placeholder="e.g. Focus on randomised trials in older adults")
        if st.button("Re-plan and re-run", disabled=not fb.strip()):
            run_safely(pipe, "Re-planning", question=r.report.question, feedback=fb.strip(), previous=r.buffer)
            if st.session_state.result is not r:
                st.rerun()
    with tabs[4]:
        rows = pipe.store.evidence()
        if rows:
            st.dataframe(pd.DataFrame(rows).drop(columns=["claims_json"]), hide_index=True, use_container_width=True)
        else:
            st.info("No approved evidence yet.")


main()
