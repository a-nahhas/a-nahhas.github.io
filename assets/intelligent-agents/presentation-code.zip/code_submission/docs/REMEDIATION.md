# Remediation log

Defects found by testing, by live runs and by a structured code review, with the root cause, the fix and
the test that now guards against regression. Evidence files are under `evidence/`.

Two honesty notes:

- R1–R7 were fixed in the same working session in which the affected code was written. The fix was
  committed together with the code it fixed, so git history does not show the pre-fix version. The test
  output and logs cited below are the evidence. R8 onwards each have their own commit.
- The R8 crash traceback was in a Streamlit log that a later restart overwrote. The fix was confirmed live
  later: the same `RemoteProtocolError` was retried and recovered in run `460590287b`
  (`evidence/live_runs/460590287b_cli_output.txt`).

## Found by unit tests and live runs (R1–R8)

| ID | Found by | Symptom | Root cause | Fix | Regression test |
|----|----------|---------|------------|-----|-----------------|
| R1 | Unit test | PubMed and Semantic Scholar copies of one study were not merged when one title had "Low-Back" and the other "low back" (similarity 89 < 93). | `_norm_title` deleted punctuation, fusing "low-back" into "lowback". | Punctuation becomes a space before comparison (`dedup.py`); the pair now scores 100. | `test_dedup.py::test_fuzzy_title_match_merges_when_one_side_lacks_identifiers` |
| R2 | Test-suite timing (34 tests took 5.2 s) | Patching `time.sleep` did not stop real back-off sleeps. | `get_with_backoff` bound `time.sleep` as a default argument at import time. | Resolve `sleep` at call time (`sources/http.py`). | `test_sources.py::test_patched_time_sleep_is_honoured` |
| R3 | First live run, 16:44 (`evidence/logs/agent.log`) | Uncaught `ServerError: 503 UNAVAILABLE ... high demand` crashed the run after ~2.5 min of back-off on `gemini-3.6-flash`. | (a) Free-tier capacity shortage on one model, which back-off cannot fix; (b) LLM errors were outside the agents' failure handling. | `GeminiLLM` fails over to other models (list later revised in R4). Total unavailability raises `LLMUnavailable`: the Planning Agent turns it into a human escalation, the Curation Agent into "uncertain" records. | `test_llm.py::test_gemini_fails_over_to_next_model_on_sustained_503`, `test_planning.py::test_llm_outage_during_planning_escalates_instead_of_crashing`, `test_curation.py::test_llm_outage_during_screening_degrades_to_uncertain` |
| R4 | Second live run, 16:48 (`evidence/live_runs/failed_run_R4_cli_output.txt`) | Failover reached `gemini-2.5-flash`, which returned `404 ... no longer available to new users` and crashed the run. Capacity was flipping between models minute to minute. | Strictly forward failover; 404 treated as a bug; default list named a withdrawn model. | Failover cycles the pool for up to two rounds from the last working model and retires a model on 404. Defaults are now models checked as available on 2026-10-12 (`gemini-3.5-flash`, `gemini-3.8-flash`, `gemini-3.1-flash-lite`). | `test_llm.py::test_gemini_retires_withdrawn_model_and_uses_next`, `..._returns_to_earlier_model_when_it_recovers`, `..._raises_unavailable_after_all_rounds` |
| R5 | Third live run, 16:51 (`evidence/live_runs/cdc5729696_cli_output.txt`) | (a) PubMed efetch returned HTTP 400 for a valid request (succeeded on replay); (b) Crossref 429s on consecutive checks; (c) Semantic Scholar 429 on every subgoal, ~15 s back-off each; (d) model used not recorded. | (a) Every 400 was treated as permanent; (b) no pacing; (c) no memory of source failures; (d) provenance not captured. | (a) PubMed retries 400; (b) 1 req/s Crossref pacing; (c) circuit breaker after 2 failures per source; (d) `RunReport.models_used`. | `test_sources.py::test_pubmed_retries_transient_400_from_efetch`, `::test_crossref_paces_consecutive_requests`, `test_planning.py::test_circuit_breaker_stops_calling_a_repeatedly_failing_source`, `test_pipeline_e2e.py::test_question_to_approved_evidence` (models_used) |
| R6 | Unit test | The fidelity check accepted an extract whose effect size was changed from 2.1 to 3.1 points. | Character-level fuzzy match scores a one-digit change at ~98. | Numbers must match exactly (superseded by the word-level check in R10). | `test_validation.py::test_altered_or_fabricated_extracts_rejected` |
| R7 | First UI test run | `AppTest script run timed out after 30(s)`; passed in ~1 s on three reruns. | Not an application defect: cold-start import time on Windows exceeded AppTest's 30 s budget. | `default_timeout` raised to 90 s. | Suite runs (`evidence/test_output/pytest_verbose.txt`) |
| R8 | Live UI run, ~17:10 (log overwritten, see note above) | `httpx.RemoteProtocolError: Server disconnected` crashed planning; the UI showed a raw traceback. | `GeminiLLM` caught only API status errors, not transport errors; no UI error boundary. | Transport errors are retried and failed over like 503s; UI runs go through an error boundary (extended to re-plan in R12). | `test_llm.py::test_gemini_treats_dropped_connection_as_transient`, `test_streamlit_app.py::test_failed_runs_show_a_message_not_a_traceback` |

## Found by the structured code review (R9–R17)

A review with four independent read-only reviewers covered code correctness, compliance with the brief,
traceability against the Unit 6 proposal, and the accuracy of documented claims. Every reviewer finding
was reproduced before being fixed.

| ID | Symptom | Root cause | Fix | Regression test |
|----|---------|------------|-----|-----------------|
| R9 | After a re-plan, record #1 of the new run still showed the previous run's "approve"; submitting stored an approval the reviewer never made. | Review widgets keyed by list position (`d0`, `d1`, ...), so Streamlit carried values across runs. | Keys combine run id, review round and record key; the form clears on submit. | `test_streamlit_app.py::test_decisions_do_not_carry_over_to_a_new_run` |
| R10 | Extracts that flipped meaning were accepted as verbatim: "no significant" → "a significant", "increased" → "decreased", invented trailing words, an extract longer than the abstract, a blank extract, "RESULTS: pain". | Character similarity ≥ 97 tolerated small but meaning-changing edits; there was no minimum length or length guard. | The fuzzy path now only locates a span. Acceptance is word by word: no added or dropped words, and no change to numbers, negations or direction words. A minimum length applies, and extracts longer than the abstract are rejected. | `test_validation.py::test_meaning_changing_extracts_rejected` (6 cases), `::test_cosmetic_fuzzy_difference_still_accepted` |
| R11 | Live run `66eccfeea5`: Semantic Scholar failed on every call, yet the report showed 100% coverage and no failures. | Coverage is per subgoal, and PubMed satisfied every subgoal; the run report had no per-source field. | `RunReport.source_status` and `sources_unavailable`; warnings in the CLI and UI. Live confirmation: run `460590287b`. | `test_pipeline_e2e.py::test_semantic_scholar_outage_is_reported_not_hidden` |
| R12 | Malformed PubMed XML (HTML error page with HTTP 200) aborted the whole run; "Re-plan and re-run" had no error handling. | `ET.ParseError` is a `SyntaxError`, which the per-source handler did not catch. | Re-raised as `RetrievalError`; every UI run goes through one error boundary (`run_safely`). | `test_sources.py::test_malformed_pubmed_xml_is_a_retrieval_error`, `test_streamlit_app.py::test_failed_runs_show_a_message_not_a_traceback` |
| R13 | CLI crashed with `UnicodeEncodeError` on "≥" when output was redirected on Windows, after the run's LLM quota was spent. | Redirected stdout defaults to cp1252. | stdout/stderr reconfigured to UTF-8 at start-up. | `test_cli.py::test_cli_survives_a_cp1252_console` |
| R14 | A subgoal with zero results counted as completed when the LLM reasoning step failed. | The fallback decision was "accept" regardless of result count. | Accepting an empty result marks the subgoal failed. | `test_planning.py::test_zero_results_never_count_as_completed_even_if_reasoning_fails`, `::test_llm_accepting_an_empty_result_is_a_failed_subgoal` |
| R15 | Companion papers of one trial ("6-month" vs "12-month follow-up") merged at similarity 98.6, and the merged record took the other paper's DOI. | Title-only matches compared characters only. | Title-only matches also require identical numbers in both titles. | `test_dedup.py::test_companion_papers_differing_only_in_a_number_are_not_merged` |
| R16 | The evaluation's "traceability 100%" could never be lower; batches that failed with an LLM outage counted as recalled. | The metric re-checked claims the validator had already filtered; "uncertain" from a failed call was treated like a real screening decision. | Traceability is reported as a property guaranteed by construction. The evaluation reports the claim validation pass rate, `n_screening_failures` and `recall_llm`, plus recall at the production cut-off. | `test_evaluate.py::test_screening_outage_is_not_counted_as_recall` |
| R17 | UI tests could receive a previous test's pipeline, so patches in a test had no effect (found while writing the R12 test). | `st.cache_resource` outlives an `AppTest` instance. | The UI fixture clears the resource cache. | All `test_streamlit_app.py` tests now patch the instance they render |

## Design gaps closed (traceability review against the Unit 6 proposal)

| Proposal element | Gap | Now |
|---|---|---|
| Figure 2: Flag → "Return to Curation Agent for revision" | Flag and reject behaved identically. | Flagged records are re-screened with the reviewer's note (`CurationAgent.revise`, `pipeline.revise_flagged`, UI and CLI); reject is final. |
| FR3: ranking against **predefined** criteria | The LLM always wrote the criteria. | Optional researcher criteria (UI fields, CLI `--include`/`--exclude`) are enforced in code; the report records `criteria_source`. |
| FR4: log queries, **filters**, timestamps | Settings were not recorded. | `RunReport.settings` snapshot (search limits, sort, screening limits, model pool, language filter) is saved with every run. |
| Scope: English-language literature | Not enforced. | PubMed queries get `AND english[lang]` in code. Semantic Scholar's API has no language filter (documented). |
| "Every record labelled abstract-derived" | Title-only records were labelled "abstract". | `evidence_basis` is derived: `abstract` or `title-only`. |
| Figure 2: "Flag for human review if retries exhausted" | Escalation appeared only in the Plan tab. | Shown as an error banner at the top of the run in the UI. |
| Semantic Scholar as a working second source | README said a key would help, but no setting existed. | `S2_API_KEY` setting, sent as the `x-api-key` header. |
