# LLM-Powered Academic Research Planning Agent

Intelligent Agents, Unit 11 (individual submission)

This project implements the two-agent design from the Unit 6 group proposal (Group B, 2026). The agent takes a
health-sciences research question and plans a literature search. It retrieves records from PubMed and Semantic
Scholar, then screens and summarises them with extractive claims that are checked against the source. Only records a
human reviewer approves enter the evidence table.

> The design comes from the group proposal. The code, tests, evaluation and documentation are individual work,

---

## 1. Purpose

Systematic reviewers screen large numbers of abstracts before synthesis can begin. This prototype automates search,
retrieval and **first-pass** screening, and leaves every inclusion decision to a researcher. It supports screening and
does not replace it:

* it never gives clinical recommendations;
* it does not handle patient-identifiable data;
* it reasons over abstracts only, and labels every record `abstract` or `title-only`.

## 2. How it works

```
 question ─► Planning & Retrieval Agent ──(validated JSON buffer)──► Curation Agent ─► Human review ─► evidence table
 (+ optional │  LLM: decompose into subgoals        buffer.json          │ dedup (RapidFuzz)           approve → store
  fixed      │  ReAct loop per subgoal                                   │ BM25 pre-rank               reject  → final
  criteria)  │  PubMed · Semantic Scholar                                │ LLM screen + extract        flag ──┐
             │  back-off · circuit breaker                               │ verify extract in abstract         │
             └─ coverage, per-source status, settings                    │ Crossref retraction status  ◄──────┘
                        ▲                                                                       (re-screen with note)
                        └──────────── reviewer feedback: "revise the subgoals" (re-plan) ◄─────────────┘
```

| Proposal element (Figures 1–2, section 2) | Where it is implemented |
|---|---|
| Hybrid architecture: deliberate at decomposition, react at retrieval | `research_agent/planning.py` (`_plan`, `_act`, `_react`) |
| BDI-inspired state: beliefs, desires, intentions | `AgentState` in `planning.py` (`records`/`query_log`, `question`, `queue`) |
| ReAct execution loop | LangGraph graph `plan → select → act → observe → …` in `planning.py` |
| Subgoal schema validation, max 3 re-prompts, then escalate to the human | `generate_structured` in `llm.py`; `SchemaEscalation` → `needs_human` (error banner in the UI) |
| Exponential back-off; report failed subgoals and coverage | `sources/http.py`; `RunReport` (`failed_subgoals`, `source_status`, `sources_unavailable`) |
| Log queries, filters and timestamps | `QueryLogEntry`; `RunReport.settings`; SQLite `runs` and `query_log` tables |
| Ranking against predefined criteria | Optional researcher criteria (UI fields, CLI `--include`/`--exclude`), enforced in `planning._plan` |
| Schema-validated JSON buffer (not KQML) | `ResultsBuffer` in `models.py`; written to `runs/<id>/buffer.json` and re-validated on read |
| Curation Agent: filter, rank, summarise extractively with attribution | `research_agent/curation.py`, `validation.py` |
| Deduplication, validation and storage kept outside the LLM | `dedup.py`, `validation.py`, `store.py` |
| Human gate: Approve / Flag / Reject; Flag → return to Curation Agent | `pipeline.review`, `pipeline.revise_flagged`, `CurationAgent.revise`; Streamlit review tab; CLI prompt |
| Evidence store that reconciles with the decision log | `store.py` (`evidence`, `review_log`, `reconcile`) |
| Publication status (retractions) via Crossref | `sources/crossref.py` |
| English-language scope | `AND english[lang]` added to every PubMed query in code (`sources/pubmed.py`) |

### Key design and implementation decisions

The source code comments explain each decision where it is made. The main ones are:

* **The LLM is used only where language understanding is needed.** That covers decomposition, reasoning about an
  anomalous search result, and screening and extraction. Deduplication, ranking, validation and storage are
  deterministic, which limits variability and keeps them testable.
* **The ReAct "thought" is rule-based when a search behaves as expected.** The LLM is consulted only when a search
  returns fewer than two results. This applies the hybrid design inside the loop: react cheaply by default, deliberate
  when something surprising happens, and spend the free-tier quota where it matters. The trade-off is that the planner
  never decides to re-plan on its own; re-planning is triggered by the reviewer.
* **Extractive claims are verified in code.** Every claim must quote a span of the abstract, and `validation.py`
  checks that span word by word. Exact matches pass. A near match may differ only cosmetically, never in a number, a
  negation or a direction word ("increased"/"decreased"). An "include" with no verifiable extract is downgraded to
  "uncertain".
* **Partial failures are surfaced, not hidden.** The run report states:
  * failed subgoals;
  * per-source status, including any source that was unavailable for the whole run;
  * unscreened records and records without abstracts.

  PRISMA 2020 asks reviews to report how automation was used (Page et al., 2021); this report is what makes that
  possible.
* **The LLM is replaceable.** The agents depend on a one-method `LLM` protocol. `GeminiLLM` fails over between
  free-tier models, and `ScriptedLLM` makes agent behaviour testable offline.

## 3. Installation

Requirements: Python 3.12 and internet access. The only required key is a free Gemini API key from
<https://aistudio.google.com/apikey>.

```bash
git clone <this repository>
cd <repository>
python -m venv .venv
# Windows:  .venv\Scripts\activate        macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # then edit .env and set GEMINI_API_KEY=...
```

Optional settings in `.env`:

* `S2_API_KEY`: a free Semantic Scholar key. Without it the shared unauthenticated pool usually rate-limits the agent,
  and that source is reported as unavailable.
* `NCBI_EMAIL` / `NCBI_API_KEY`: identify the tool to NCBI and raise PubMed's limit from 3 to 10 requests per second.
* `RA_MODEL` / `RA_FALLBACK_MODELS`: the primary Gemini model and the failover pool.
* `RA_LLM_MIN_INTERVAL`: pacing between LLM calls.
* `RA_PUBMED_LANGUAGE`: the PubMed language filter (default `english`; leave empty to disable).

## 4. Running

**Web interface (recommended for the demonstration):**

```bash
streamlit run app/streamlit_app.py
```

Enter a question. Optionally, fix the eligibility criteria under *Eligibility criteria*. Then click **Run agent**. A run
takes 2–5 minutes on the free tier (longer when Gemini is overloaded). The results are organised in tabs:

* **Review evidence**: approve, flag or reject each record. Each claim is shown next to its verbatim extract. Flagged
  records go back to the Curation Agent with your note, and you then review them again.
* **Plan**: the subgoals and the eligibility criteria, with their source (researcher or LLM).
* **ReAct trace**: every thought, action and observation, plus the query log.
* **Revise subgoals**: give the planner feedback; it re-plans and runs again.
* **Evidence store**: the approved records.

**Command line:**

```bash
python -m research_agent run "Does exercise therapy reduce pain intensity in adults with chronic non-specific low back pain?"
#   --include "Adults with chronic LBP" --exclude "Acute pain"   fix the eligibility criteria (repeatable)
#   --revise "Focus on RCTs in older adults"                     re-plan once with reviewer feedback
#   --no-review                                                  skip the review step
#                        It bypasses the human gate and must not be used for a real review.
python -m research_agent evidence           # list approved evidence
```

Each run writes these files to `runs/<run_id>/`:

* `buffer.json`: the hand-off between the agents;
* `curation.json`;
* `report.json`, which includes the settings snapshot;
* `review_log.jsonl`.

Logs go to `runs/agent.log`; approved evidence goes to `data/evidence.db`.

**Submitting:** package with `git archive -o submission.zip HEAD`. Do not zip the working folder: it contains `.env`
(your API key), `.venv` and the local database.

## 5. Testing

```bash
pytest                       # 125 deterministic unit + functional tests, no network or API key needed
pytest --cov=research_agent  # with coverage
pytest -m live               # 3 opt-in smoke tests against the real PubMed, Crossref and Gemini services
```

* **Unit tests** (`tests/unit`) cover:
  * schemas, deduplication and the store;
  * back-off and source parsing (recorded real PubMed responses; a synthetic Semantic Scholar response, see
    `tests/fixtures/README.md`);
  * Crossref status, the structured-generation retry loop and Gemini failover;
  * the planning agent's branches: refine, accept, drop, escalate, zero results, step budget, circuit breaker,
    researcher criteria and re-plan;
  * curation, re-screening of flagged records, extract validation and the evaluation maths.
* **Functional tests** (`tests/functional`) run the whole system from question to approved evidence. They use the
  real source clients, the LangGraph loop and the SQLite store; only the network (`respx`) and the LLM are replaced.
  They also cover the CLI, and the Streamlit UI through Streamlit's `AppTest`, including the review form, flag
  re-screening, fixed criteria and error handling.
* **Remediation:** `docs/REMEDIATION.md` records 17 defects with symptom, root cause, fix and the test that guards
  each one:
  * R1–R8, found by tests and live runs;
  * R9–R17, found by a structured four-reviewer code review.

  It also records the design gaps closed against the proposal.
* **Saved outputs:** `evidence/test_output/` holds the verbose pytest log with the coverage table, the JUnit XML, and
  the live smoke-test log.

## 6. Evidence of execution and evaluation

* `evidence/screenshots/`: the UI after a live run, a review card with verified extracts, and the ReAct trace showing
  the circuit breaker opening on Semantic Scholar.
* `evidence/live_runs/`: complete artefacts and CLI output from three live runs:
  * `cdc5729696`, which led to fix R5;
  * `66eccfeea5`, the UI run;
  * `460590287b`, after the review fixes. It shows the per-source report flagging Semantic Scholar as unavailable, and
    failover recovering from a dropped connection.

  The folder also holds the output of the run that crashed and led to fix R4. `evidence/logs/agent.log` is the agent
  log for all CLI runs.
* `eval/RESULTS.md`: evaluation against the proposal's success criteria on a stratified set of 28 real PubMed
  records, run three times.
   Results:
  * recall of records passed to the reviewer was 1.0 in every run (target ≥ 0.80), or 0.9 with the default
    screening cut-off;
  * specificity was 0.833, and the consistent error is over-including a trial that measures pain sensitisation
    rather than pain intensity;
  * the store reconciled every time, and traceability is guaranteed by design;

### Development history

| Date | Stage | Evidence |
|---|---|---|
| Unit 6 (submitted August 2026) | Group design proposal: requirements, success criteria, architecture, Figures 1–3 | Group B (2026) |
| 12 Oct 2026 | Implementation in phases: scaffold → sources → planner → curator → tests → UI → evaluation → documentation | `git log` |
| 12 Oct 2026 | Live-run remediation R3–R5, R8 (free-tier overload, withdrawn model, transient NCBI errors) | `docs/REMEDIATION.md`, `evidence/live_runs/` |
| 12 Oct 2026 | Structured four-reviewer review; fixes R9–R17 and design gaps closed | `docs/REMEDIATION.md`, `git log` |

The implementation was built in one concentrated working session after the design phase, not across the
three two-week sprints the proposal planned. The commit history shows the order of construction and the refinements
made, not elapsed effort.

### Presentation

* `presentation/Research_Planning_Agent.pptx`: the 10-slide deck, with the narration in each slide's speaker notes.
* `presentation/transcript.md`: the full narration transcript with references.
* `presentation/build_deck.js`: generates both from one source (`cd presentation && npm install && node build_deck.js`).

## 7. Deviations from the proposal (and why)

| Proposal | Implementation | Reason |
|---|---|---|
| LangChain + LangGraph | LangGraph only, plus a small LLM adapter of my own (`llm.py`) | Only one model operation is needed. Owning the validate-and-reprompt loop makes the bounded-retry behaviour explicit and testable. |
| Gemini 3.6 Flash throughout (Google DeepMind, 2026) | 3.6 Flash first, with automatic failover to other free-tier Gemini models | The free tier returned sustained HTTP 503/429 during development (REMEDIATION R3, R4). The model used is recorded per run. |
| PubMed Central open-access full text | Not implemented; abstracts only | Kept the scope achievable. Records are labelled `abstract`/`title-only`, and the curation prompt forbids outside knowledge. |
| Semantic Scholar as a second source | Implemented, but without a key it returned HTTP 429 on every call in every archived live run | The circuit breaker limits the cost and the run report names the source as unavailable. Setting `S2_API_KEY` gives the agent its own quota (not tested live: no key was available). |
| Planner "decides when to re-plan" | Re-planning is triggered by the reviewer; the LLM reasons only when a search is anomalous | Keeps deliberation bounded and the free-tier quota predictable (see section 2). |
| 50 hand-screened abstracts | 28 stratified real records; retrieval held fixed |
| Three two-week sprints | Built in one session after the design phase | See Development history. |
| Pandas for processing | Used only for UI tables | Data volumes are small; Pydantic models are the working representation. |
| Crossref called by the retrieval agent (Figure 1, 2-b) | Called by the Curation Agent, only for screened, non-excluded records with a DOI | Saves requests. Records without a DOI get status "unknown", never "active". |

## 8. Limitations, ethical, legal, social and professional considerations

* **Coverage.** Two sources, abstracts only, and an English filter on PubMed (Semantic Scholar has no language
  filter): the agent will miss evidence. Coverage is reported per subgoal and per source, never implied to be complete.
  With the default screening cut-off (top 20 by BM25), some relevant records may never reach the LLM (see
  `eval/RESULTS.md`). They are listed for the reviewer as unscreened, not dropped.
* **Variability.** Screening decisions vary between runs and models (see `eval/RESULTS.md`). The human gate is
  essential, not optional.
* **Fidelity.** The validator proves each extract is genuine, not that the claim's paraphrase is faithful. That
  judgement stays with the reviewer, who sees both side by side.
* **Automation bias (social).** Reviewers tend to over-trust automated suggestions (Goddard, Roudsari and Wyatt, 2012).
  The design counters this in four ways:
  * "uncertain" is preferred over a guess;
  * every claim is shown with its source extract;
  * failures are surfaced, not hidden;
  * the default review choice is "skip", never "approve".

  It cannot remove the risk, so the tool is positioned as a first-pass aid.
* **Legal.** Only metadata, abstracts and public status data are retrieved, through sanctioned APIs, within NCBI's
  rate policy and Crossref's etiquette. No publisher content is scraped.
* **Data protection.** No patient-identifiable data is sought, but published records contain author names (personal
  data under UK GDPR) and abstracts may describe patient-level detail. The data flows are:

| Data | Where it goes | Retention | Processor |
|---|---|---|---|
| Question, criteria, every retrieved record (title, abstract, authors) | `runs/<id>/buffer.json`, `curation.json` on local disk | Until deleted by the user | Local |
| Titles and abstracts of screened records, plus prompts | Gemini API (free tier) | Per Google's free-tier terms, which may allow use for service improvement | Google (third party) |
| Queries | NCBI, Semantic Scholar, Crossref | Per each service's policy | Third parties |
| Approved records (title, IDs, claims, extracts, note) | `data/evidence.db` evidence table | Until deleted | Local |
| Every review decision | `review_log` table, `review_log.jsonl` | Until deleted | Local |

  The live-run artefacts committed under `evidence/live_runs/` contain published bibliographic records, including
  author names, as evidence of execution. Do not submit unpublished or confidential material as a question or
  criteria: it would be sent to the free-tier LLM.

## 9. Repository structure

```
research_agent/        the agent package
  planning.py          Planning & Retrieval Agent (LangGraph ReAct loop)
  curation.py          Curation Agent (screening, extraction, re-screening of flagged records)
  validation.py        traceability / fidelity checks
  llm.py               LLM protocol, Gemini adapter with failover, structured generation
  models.py            shared Pydantic schemas (the inter-agent contract)
  dedup.py  store.py  pipeline.py  config.py  __main__.py (CLI)
  sources/             PubMed, Semantic Scholar, Crossref clients; HTTP back-off
app/streamlit_app.py   user interface and human review gate
tests/                 unit/, functional/, fixtures/
eval/                  candidate builder, labelled set, evaluation script and results
docs/REMEDIATION.md    defect and design-gap log
evidence/              screenshots, live-run artefacts, logs, test outputs
presentation/          deck, transcript, deck generator
```

## 10. References

BCS, The Chartered Institute for IT (n.d.) *BCS Code of Conduct*. Available at: https://www.bcs.org/membership-and-registrations/become-a-member/bcs-code-of-conduct/ (Accessed: 12 October 2026).

Bratman, M.E., Israel, D.J. and Pollack, M.E. (1988) 'Plans and resource-bounded practical reasoning', *Computational Intelligence*, 4(3), pp. 349-355.

Finin, T. et al. (1994) 'KQML as an Agent Communication Language', in *Proceedings of the Third International Conference on Information and Knowledge Management (CIKM '94)*. New York: ACM, pp. 456-463. Available at: https://doi.org/10.1145/191246.191322

Goddard, K., Roudsari, A. and Wyatt, J.C. (2012) 'Automation bias: a systematic review of frequency, effect mediators, and mitigators', *Journal of the American Medical Informatics Association*, 19(1), pp. 121-127. Available at: https://doi.org/10.1136/amiajnl-2011-000089

Google DeepMind (2026) *Gemini 3.6 Flash: model card*. Available at: https://deepmind.google/models/model-cards/gemini-3-6-flash/ (Accessed: 27 August 2026).

Group B (2026) *LLM-Powered Academic Research Planning Agent: design proposal*. Unpublished coursework, Intelligent Agents module, University of Essex Online.

Kinney, R. et al. (2023) 'The Semantic Scholar Open Data Platform', *arXiv* [Preprint]. Available at: https://doi.org/10.48550/arXiv.2301.10140

Nygard, M.T. (2018) *Release It! Design and Deploy Production-Ready Software*. 2nd edn. Raleigh, NC: Pragmatic Bookshelf.

Page, M.J. et al. (2021) 'The PRISMA 2020 statement: An updated guideline for reporting systematic reviews', *International Journal of Surgery*, 88, 105906. Available at: https://doi.org/10.1016/j.ijsu.2021.105906

Rao, A.S. and Georgeff, M.P. (1995) 'BDI Agents: From Theory to Practice', in *Proceedings of the First International Conference on Multiagent Systems (ICMAS-95)*. Menlo Park, CA: AAAI Press, pp. 312-319.

Robertson, S. and Zaragoza, H. (2009) 'The Probabilistic Relevance Framework: BM25 and Beyond', *Foundations and Trends in Information Retrieval*, 3(4), pp. 333-389. Available at: https://doi.org/10.1561/1500000019

Wakefield, A.J. et al. (1998) 'Ileal-lymphoid-nodular hyperplasia, non-specific colitis, and pervasive developmental disorder in children', *The Lancet*, 351(9103), pp. 637-641 (Retracted). Available at: https://doi.org/10.1016/S0140-6736(97)11096-0 (used only as a known retraction in a live test).

Wang, G. et al. (2026) 'Human–large language model collaboration in clinical medicine: a systematic review and meta-analysis', *npj Digital Medicine*, 9(1), 195. Available at: https://doi.org/10.1038/s41746-026-02382-2

Wang, Z. et al. (2025) 'A foundation model for human-AI collaboration in medical literature mining', *Nature Communications*, 16(1), 8361. Available at: https://doi.org/10.1038/s41467-025-62058-5

Wooldridge, M. (2009) *An Introduction to MultiAgent Systems*. 2nd edn. Chichester: John Wiley & Sons.

Yao, S. et al. (2023) 'ReAct: Synergizing Reasoning and Acting in Language Models', in *11th International Conference on Learning Representations (ICLR 2023)*. Available at: https://doi.org/10.48550/arXiv.2210.03629

### Software, services and data acknowledged

* LangGraph (LangChain Inc.), Pydantic, RapidFuzz, HTTPX, Streamlit, pandas, python-dotenv, pytest, pytest-cov and
  respx. Exact versions are in `requirements.txt`.
* The deck generator uses pptxgenjs, react-icons and sharp (`presentation/package.json`).
* Google Gemini API (free tier) through the `google-genai` SDK.
* NCBI Entrez Programming Utilities (E-utilities), the Semantic Scholar Graph API, and the Crossref REST API
  (including Retraction Watch data).
* The test fixtures `tests/fixtures/pubmed_*.{json,xml}` are real NCBI responses recorded on 2026-10-12.
