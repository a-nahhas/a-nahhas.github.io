"""Command-line entry point: ``python -m research_agent run "question"``.

The CLI exists alongside Streamlit because a terminal run produces a plain-text log
that is easy to capture as execution evidence and to repeat exactly.
"""

from __future__ import annotations

import argparse
import logging
import sys
import textwrap

from .config import Settings
from .models import ReviewDecision
from .pipeline import ResearchPipeline, RunResult


def _setup_logging(settings: Settings, verbose: bool) -> None:
    settings.runs_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s %(levelname)-7s %(name)s: %(message)s"
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO, format=fmt, handlers=[
        logging.StreamHandler(sys.stderr),
        logging.FileHandler(settings.runs_dir / "agent.log", encoding="utf-8"),
    ])
    # Third-party request logs drown out the agent's own reasoning trace.
    for noisy in ("httpx", "httpcore", "google_genai", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def _print_result(r: RunResult, show: int) -> None:
    w = textwrap.TextWrapper(width=100, initial_indent="    ", subsequent_indent="    ")
    print(f"\n=== Run {r.report.run_id} ===\nQuestion: {r.report.question}\n")
    if r.buffer.plan:
        print("Plan (committed intentions):")
        for sg in r.buffer.plan.subgoals:
            print(f"  [{sg.id}] {sg.description}\n      PubMed: {sg.pubmed_query}\n      S2:     {sg.keyword_query}")
        src = "fixed by the researcher" if r.buffer.criteria_fixed else "proposed by the LLM"
        print(f"  Eligibility criteria ({src}):")
        print(f"  Inclusion: {'; '.join(r.buffer.plan.inclusion_criteria)}")
        print(f"  Exclusion: {'; '.join(r.buffer.plan.exclusion_criteria) or '-'}\n")
    print("ReAct trace:")
    for t in r.buffer.trace:
        sg = f"[sg {t.subgoal_id}] " if t.subgoal_id else ""
        print(w.fill(f"{t.step:>2}. {t.kind.upper():<11} {sg}{t.content}"))
    rep = r.report
    print(f"\nCoverage: {rep.coverage:.0%} of subgoals ({len(rep.completed_subgoals)}/{rep.n_subgoals})")
    for sg, why in rep.failed_subgoals.items():
        print(f"  FAILED subgoal {sg}: {why}")
    print(f"Retrieved {rep.n_retrieved} -> {rep.n_after_dedup} after dedup; {rep.n_screened} screened, "
          f"{rep.n_not_screened} below cut-off, {rep.n_no_abstract} without abstract")
    print(f"Screening: {rep.n_include} include / {rep.n_uncertain} uncertain / {rep.n_exclude} exclude; "
          f"{rep.n_claims_rejected} claim(s) rejected by validation")
    for name, st in rep.source_status.items():
        print(f"Source {name}: {st.ok} ok, {st.error} failed, {st.skipped} skipped, {st.records} records")
    if rep.sources_unavailable:
        print(f"!! Unavailable for the whole run: {', '.join(rep.sources_unavailable)} "
              "- results come from the remaining source(s) only")
    if rep.models_used:
        print(f"LLM calls by model: {rep.models_used}")
    if rep.needs_human:
        print(f"\n!! NEEDS HUMAN: {rep.needs_human}")
    if not r.curation:
        return
    print("\nTop ranked evidence:")
    for i, e in enumerate([e for e in r.curation.evidence if e.screened][:show], 1):
        ids = ", ".join(x for x in [f"PMID {e.record.pmid}" if e.record.pmid else "",
                                    f"doi:{e.record.doi}" if e.record.doi else ""] if x)
        print(f"\n {i}. [{e.decision.upper()} {e.relevance:.2f}] {e.record.title} ({e.record.year}) {ids}")
        print(f"    status: {e.publication_status}; basis: {e.record.evidence_basis}")
        print(w.fill(f"Reason: {e.reason}"))
        for c in e.claims:
            print(w.fill(f"- {c.text}"))
            print(w.fill(f'  extract: "{c.supporting_extract}"'))
        for n in e.validation_notes:
            print(f"    ! {n}")
    print(f"\nArtefacts: {r.run_dir}")


def _review(pipe: ResearchPipeline, r: RunResult, approve_includes: bool) -> None:
    if not r.curation:
        return
    candidates = [e for e in r.curation.evidence if e.screened and e.decision != "exclude"]
    decisions = []
    if approve_includes:
        # Non-interactive mode for repeatable evidence capture only. It deliberately
        # bypasses human judgement, so every decision it makes is attributed to
        # "cli-auto" in the log and the README says it is not for real reviews.
        for e in candidates:
            d = "approve" if e.decision == "include" and e.publication_status != "retracted" else "flag"
            decisions.append(ReviewDecision(record_key=e.record.key, decision=d, note="cli --approve-includes",
                                            reviewer="cli-auto"))
    else:
        decisions = _ask(candidates)
        flagged = [d for d in decisions if d.decision == "flag"]
        if flagged:
            # Figure 2: a flag returns the record to the Curation Agent for revision,
            # then the reviewer decides again on the revised screening.
            pipe.review(r, flagged)
            pipe.revise_flagged(r, flagged)
            keys = {d.record_key for d in flagged}
            print(f"\n{len(keys)} flagged record(s) re-screened by the Curation Agent:")
            decisions = [d for d in decisions if d.decision != "flag"]
            decisions += _ask([e for e in r.curation.evidence if e.record.key in keys], allow_flag=False)
    n = pipe.review(r, decisions)
    rec = pipe.store.reconcile(r.report.run_id)
    print(f"\nPersisted {n} approved record(s). Store reconciles with review log: {rec['ok']} "
          f"(expected {rec['expected']}, stored {rec['stored']})")


def _ask(evidence, allow_flag: bool = True) -> list[ReviewDecision]:
    opts = "[a]pprove / [f]lag (re-screen) / [r]eject / [s]kip" if allow_flag else "[a]pprove / [r]eject / [s]kip"
    print(f"\nHuman review: {opts}")
    mapping = {"a": "approve", "r": "reject", **({"f": "flag"} if allow_flag else {})}
    out = []
    for e in evidence:
        for c in e.claims:
            print(f'      - {c.text}  [extract: "{c.supporting_extract[:120]}"]')
        ans = input(f"  {e.decision.upper():9} {e.record.title[:80]} > ").strip().lower()[:1]
        if ans in mapping:
            note = input("    note for the Curation Agent > ").strip() if ans == "f" else ""
            out.append(ReviewDecision(record_key=e.record.key, decision=mapping[ans], note=note))
    return out


def main(argv: list[str] | None = None) -> int:
    # Windows consoles and redirected output default to cp1252, which cannot print
    # characters common in abstracts ("\u2265", "\u03b2"); failing there would waste a
    # run's LLM quota just before the review step (REMEDIATION R13).
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser(prog="research_agent", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    run = sub.add_parser("run", help="plan, retrieve, curate and review for a research question")
    run.add_argument("question")
    run.add_argument("--show", type=int, default=8, help="number of ranked records to print")
    run.add_argument("--no-review", action="store_true", help="skip the human review gate")
    run.add_argument("--approve-includes", action="store_true",
                     help="NON-HUMAN review for evidence capture only: approve includes, flag uncertain")
    run.add_argument("--include", action="append", metavar="CRITERION",
                     help="fixed inclusion criterion (repeatable); overrides the LLM's criteria")
    run.add_argument("--exclude", action="append", metavar="CRITERION",
                     help="fixed exclusion criterion (repeatable); used with --include")
    run.add_argument("--revise", metavar="FEEDBACK", help="after the run, re-plan once with this reviewer feedback")
    run.add_argument("-v", "--verbose", action="store_true")
    ev = sub.add_parser("evidence", help="list approved evidence in the store")
    ev.add_argument("--run-id")
    args = ap.parse_args(argv)

    settings = Settings()
    _setup_logging(settings, getattr(args, "verbose", False))
    if args.cmd == "evidence":
        from .store import EvidenceStore
        for row in EvidenceStore(settings.db_path).evidence(args.run_id):
            print(f"{row['run_id']}  {row['record_key']:<40} {row['title'][:70]}")
        return 0

    pipe = ResearchPipeline.from_settings(settings)
    criteria = (args.include, args.exclude or []) if args.include else None
    result = pipe.run(args.question, criteria=criteria)
    _print_result(result, args.show)
    if args.revise:
        print(f"\n--- Reviewer requested revision: {args.revise!r} ---")
        result = pipe.run(args.question, feedback=args.revise, previous=result.buffer)
        _print_result(result, args.show)
    if not args.no_review:
        _review(pipe, result, args.approve_includes)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
