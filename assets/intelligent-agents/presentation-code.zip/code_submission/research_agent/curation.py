"""Curation Agent: deduplicate -> filter -> rank -> screen and summarise -> validate.

Only the two steps that need language understanding (screening against criteria and
extractive summarisation) use the LLM. Deduplication, lexical ranking, validation and
status lookup are deterministic, which limits run-to-run variability and keeps the
behaviour testable. This mirrors LEADS's split of literature mining into search,
eligibility assessment and extraction (Wang, Z. et al., 2025), consolidated into one
agent to avoid orchestration overhead for a single-user prototype.
"""

from __future__ import annotations

import logging
import math
import re
from collections import Counter
from typing import Any

from .config import Settings
from .dedup import deduplicate
from .llm import LLM, LLMUnavailable, SchemaEscalation, generate_structured
from .models import CurationReport, EvidenceRecord, LLMScreeningBatch, Record, ResultsBuffer, SubgoalPlan
from .validation import has_persistent_id, validate_claims

log = logging.getLogger(__name__)

SCREEN_SYSTEM = (
    "You are a careful first-pass screener for a health-sciences systematic review. You judge each record "
    "only on its title and abstract against the stated criteria, and you never use outside knowledge. "
    "A human researcher makes the final decision."
)

SCREEN_PROMPT = """Research question: {question}
Inclusion criteria: {inclusion}
Exclusion criteria: {exclusion}

For EACH record below return a screening with:
- record_index: the index shown;
- decision: "include" if it plausibly meets the criteria, "exclude" if it clearly fails one,
  "uncertain" if the abstract does not give enough information (prefer "uncertain" over a guess,
  because a wrongly excluded study is lost to the review);
- relevance: 0.0-1.0 relevance to the research question;
- reason: one sentence naming the criterion that decided it;
- claims: for included or uncertain records, up to 3 key findings relevant to the question. Each claim's
  supporting_extract MUST be copied character-for-character from the abstract (a contiguous span of
  10-300 characters). Do not paraphrase, merge or shorten extracts. Excluded records: claims = [].

{records}"""

_STOP = set("a an and are as at be by for from has in is it of on or that the to with was were what which "
            "does do how among versus vs effect effects".split())


def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9]+", text.lower()) if t not in _STOP and len(t) > 2]


def bm25_scores(query: str, docs: list[str], k1: float = 1.5, b: float = 0.75) -> list[float]:
    """Okapi BM25 (Robertson and Zaragoza, 2009).

    Used as a cheap pre-ranking to decide which records are worth an LLM call. BM25
    rather than embeddings: no model download or extra API quota, fully explainable,
    and adequate when queries and abstracts share clinical vocabulary.
    """
    tokenised = [_tokens(d) for d in docs]
    n = len(tokenised)
    if n == 0:
        return []
    avgdl = sum(map(len, tokenised)) / n or 1.0
    df = Counter(t for doc in tokenised for t in set(doc))
    q = set(_tokens(query))
    scores = []
    for doc in tokenised:
        tf = Counter(doc)
        s = 0.0
        for t in q:
            if t in tf:
                idf = math.log(1 + (n - df[t] + 0.5) / (df[t] + 0.5))
                s += idf * tf[t] * (k1 + 1) / (tf[t] + k1 * (1 - b + b * len(doc) / avgdl))
        scores.append(s)
    return scores


class CurationAgent:
    def __init__(self, llm: LLM, crossref: Any | None = None, settings: Settings | None = None):
        self.llm = llm
        self.crossref = crossref
        self.s = settings or Settings()

    def run(self, buffer: ResultsBuffer) -> CurationReport:
        # Re-validate on read: the buffer is the contract between agents, and a file
        # edited or produced by an older version should fail loudly here, not later.
        buffer = ResultsBuffer.model_validate(buffer.model_dump())
        plan = buffer.plan
        records = deduplicate(buffer.records)
        n_after_dedup = len(records)

        with_abs = [r for r in records if r.abstract]
        no_abs = [r for r in records if not r.abstract]

        query = " ".join([buffer.question, *(plan.inclusion_criteria if plan else [])])
        lexical = bm25_scores(query, [f"{r.title} {r.abstract}" for r in with_abs])
        ranked = sorted(zip(with_abs, lexical), key=lambda x: x[1], reverse=True)
        to_screen = ranked[: self.s.screen_limit]
        not_screened = ranked[self.s.screen_limit:]

        evidence: list[EvidenceRecord] = []
        for i in range(0, len(to_screen), self.s.screen_batch_size):
            evidence.extend(self._screen_batch(buffer.question, plan, to_screen[i:i + self.s.screen_batch_size]))

        # Unscreened records are listed, not dropped, so the reviewer and the run
        # report can account for everything retrieved (Page et al., 2021).
        for rank, (r, score) in enumerate(not_screened, start=len(to_screen) + 1):
            evidence.append(EvidenceRecord(
                record=r, decision="uncertain", lexical_score=score, screened=False,
                reason=f"Not screened: lexical rank {rank} is beyond the screening limit of {self.s.screen_limit}."))
        for r in no_abs:
            evidence.append(EvidenceRecord(record=r, decision="uncertain", screened=False,
                                           reason="Not screened: no abstract available (title only)."))

        if self.crossref:
            for e in evidence:
                # Status is looked up only where it could matter to the reviewer.
                if e.record.doi and e.decision != "exclude" and e.screened:
                    e.publication_status = self.crossref.status(e.record.doi)
                    if e.publication_status == "retracted":
                        e.validation_notes.append("RETRACTED according to Crossref")

        order = {"include": 0, "uncertain": 1, "exclude": 2}
        evidence.sort(key=lambda e: (not e.screened, order[e.decision], -e.relevance, -e.lexical_score))
        return CurationReport(
            run_id=buffer.run_id, evidence=evidence, n_input=len(buffer.records), n_after_dedup=n_after_dedup,
            n_no_abstract=len(no_abs), n_screened=len(to_screen), n_not_screened=len(not_screened),
            n_claims_rejected=sum(len(e.rejected_claims) for e in evidence))

    def revise(self, question: str, plan: SubgoalPlan | None,
               flagged: list[tuple[EvidenceRecord, str]]) -> list[EvidenceRecord]:
        """Re-screen records a reviewer flagged, with the reviewer's note as guidance.

        Implements Figure 2's "Flag -> return to Curation Agent for revision" branch.
        A rejection is final; a flag means "look again", so the record goes back
        through the same screening and validation, never straight into the store.
        """
        out: list[EvidenceRecord] = []
        for i in range(0, len(flagged), self.s.screen_batch_size):
            chunk = flagged[i:i + self.s.screen_batch_size]
            batch = [(e.record, e.lexical_score) for e, _ in chunk]
            notes = {idx: note for idx, (_, note) in enumerate(chunk)}
            for (old, note), new in zip(chunk, self._screen_batch(question, plan, batch, notes)):
                new.publication_status = old.publication_status
                new.validation_notes.append(f"revised after reviewer flag: {note or 'no note given'}")
                out.append(new)
        return out

    def _screen_batch(self, question: str, plan: SubgoalPlan | None,
                      batch: list[tuple[Record, float]],
                      reviewer_notes: dict[int, str] | None = None) -> list[EvidenceRecord]:
        # Batching several records per call cuts free-tier requests ~5x; the batch is
        # small enough that the model does not lose track of which record is which.
        blocks = []
        for idx, (r, _) in enumerate(batch):
            # Abstracts are truncated to bound prompt size; long structured abstracts
            # rarely put decisive information after the first ~3,000 characters.
            block = f"[record_index {idx}]\nTitle: {r.title}\nYear: {r.year}\nAbstract: {r.abstract[:3000]}"
            if reviewer_notes and reviewer_notes.get(idx):
                block += f"\nReviewer note (flagged for re-screening): {reviewer_notes[idx]}"
            blocks.append(block)
        prompt = SCREEN_PROMPT.format(
            question=question,
            inclusion="; ".join(plan.inclusion_criteria) if plan else "relevant to the question",
            exclusion="; ".join(plan.exclusion_criteria) if plan and plan.exclusion_criteria else "none stated",
            records="\n\n".join(blocks))
        try:
            result = generate_structured(self.llm, prompt, LLMScreeningBatch, system=SCREEN_SYSTEM,
                                         max_retries=self.s.max_schema_retries)
            by_idx = {s.record_index: s for s in result.screenings}
        except (SchemaEscalation, LLMUnavailable) as exc:
            # Degrade to "uncertain" (human screens it) rather than dropping or guessing.
            log.warning("screening batch failed (%s); marking records uncertain for human review", exc)
            by_idx = {}

        out = []
        for idx, (r, score) in enumerate(batch):
            s = by_idx.get(idx)
            if s is None:
                out.append(EvidenceRecord(record=r, decision="uncertain", lexical_score=score,
                                          reason="LLM returned no screening for this record; needs human screening.",
                                          validation_notes=["missing LLM screening"]))
                continue
            valid, rejected, notes = validate_claims(r, s.claims)
            decision = s.decision
            if decision == "include" and not valid:
                # An inclusion the reviewer cannot verify against the source is
                # downgraded rather than trusted.
                decision = "uncertain"
                notes.append("downgraded include -> uncertain: no verifiable supporting extract")
            if decision == "include" and not has_persistent_id(r):
                decision = "uncertain"
            out.append(EvidenceRecord(record=r, decision=decision, relevance=s.relevance, lexical_score=score,
                                      reason=s.reason, claims=valid, rejected_claims=rejected,
                                      validation_notes=notes))
        return out
