"""Semantic Scholar Graph API (paper search).

Adds coverage beyond MEDLINE (conference papers, preprints, allied-health venues) from
the Semantic Scholar corpus (Kinney et al., 2023). The Graph API was chosen over
scraping Google Scholar, which has no sanctioned API and whose terms forbid it.
The unauthenticated tier shares one rate-limited pool, so this source is expected to
fail sometimes; the agent treats that as a reportable partial failure, not a crash.
"""

from __future__ import annotations

import httpx

from ..models import Record
from .http import get_with_backoff

URL = "https://api.semanticscholar.org/graph/v1/paper/search"
FIELDS = "title,abstract,authors,year,venue,externalIds"


class SemanticScholarClient:
    def __init__(self, client: httpx.Client, api_key: str | None = None):
        self.client = client
        if api_key:
            self.client.headers["x-api-key"] = api_key

    def search(self, query: str, max_results: int, subgoal_id: int) -> list[Record]:
        data = get_with_backoff(self.client, URL, {"query": query, "limit": max_results, "fields": FIELDS},
                                base_delay=2.0).json()
        return [parse_paper(p, subgoal_id) for p in data.get("data", []) if p.get("title")]


def parse_paper(p: dict, subgoal_id: int) -> Record:
    ext = p.get("externalIds") or {}
    return Record(
        source="semantic_scholar",
        title=p["title"].strip().rstrip("."),
        abstract=(p.get("abstract") or None),
        authors=[a.get("name", "") for a in p.get("authors") or [] if a.get("name")],
        year=p.get("year"),
        journal=p.get("venue") or None,
        pmid=str(ext["PubMed"]) if ext.get("PubMed") else None,
        pmcid=f"PMC{ext['PubMedCentral']}" if ext.get("PubMedCentral") else None,
        doi=ext.get("DOI"),
        s2_id=p.get("paperId"),
        subgoal_ids=[subgoal_id],
    )
