"""PubMed via NCBI E-utilities (esearch + efetch).

E-utilities rather than scraping: it is the sanctioned, free route and returns
structured XML with PMIDs and DOIs, which is what traceability needs. efetch XML is
used instead of esummary JSON because esummary omits abstracts.
"""

from __future__ import annotations

import time
import xml.etree.ElementTree as ET

import httpx

from ..models import Record
from .http import RetrievalError, get_with_backoff

BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
TOOL = "research-planning-agent"


class PubMedClient:
    def __init__(self, client: httpx.Client, email: str | None = None, api_key: str | None = None,
                 min_interval: float | None = None, language: str | None = None):
        self.client = client
        self.language = language
        self.common = {"tool": TOOL}
        if email:
            self.common["email"] = email
        if api_key:
            self.common["api_key"] = api_key
        # NCBI policy: max 3 req/s without a key, 10 with one. Self-throttling keeps
        # us inside the policy instead of relying on 429s and back-off.
        self.min_interval = min_interval if min_interval is not None else (0.11 if api_key else 0.34)
        self._last = 0.0

    def _get(self, endpoint: str, params: dict) -> httpx.Response:
        wait = self.min_interval - (time.monotonic() - self._last)
        if wait > 0:
            time.sleep(wait)
        self._last = time.monotonic()
        # NCBI intermittently answers a valid request with HTTP 400 (seen live on efetch,
        # not reproducible on an identical retry; REMEDIATION R5), so 400 is retried here.
        # A genuinely malformed query still fails after the bounded attempts.
        return get_with_backoff(self.client, f"{BASE}/{endpoint}", {**self.common, **params},
                                extra_retry=frozenset({400}))

    def search(self, query: str, max_results: int, subgoal_id: int) -> list[Record]:
        # The language filter is appended in code, not left to the LLM's query wording,
        # so the proposal's English-only scope holds for every subgoal.
        term = f"({query}) AND {self.language}[lang]" if self.language else query
        ids = self._get("esearch.fcgi", {
            "db": "pubmed", "term": term, "retmax": max_results, "retmode": "json", "sort": "relevance",
        }).json()["esearchresult"].get("idlist", [])
        if not ids:
            return []
        xml = self._get("efetch.fcgi", {"db": "pubmed", "id": ",".join(ids), "retmode": "xml"}).text
        try:
            return parse_efetch(xml, subgoal_id)
        except ET.ParseError as exc:
            # An HTML error page or truncated body can arrive with HTTP 200. ParseError
            # is a SyntaxError, which the planner's per-source handler would not catch,
            # so it is re-raised as a retrieval failure (REMEDIATION R12).
            raise RetrievalError(f"malformed PubMed XML: {exc}") from exc


def _text(el: ET.Element | None) -> str:
    # itertext() keeps text inside inline markup such as <i>gene</i> or <sup>.
    return " ".join("".join(el.itertext()).split()) if el is not None else ""


def parse_efetch(xml: str, subgoal_id: int) -> list[Record]:
    records = []
    for art in ET.fromstring(xml).iter("PubmedArticle"):
        cit = art.find("MedlineCitation")
        a = cit.find("Article")
        # Structured abstracts arrive as labelled sections; keeping the labels
        # ("RESULTS: ...") gives the Curation Agent useful context for extraction.
        parts = []
        for sec in a.findall("Abstract/AbstractText"):
            label, body = sec.get("Label"), _text(sec)
            parts.append(f"{label}: {body}" if label else body)
        authors = []
        for au in a.findall("AuthorList/Author"):
            name = " ".join(filter(None, [_text(au.find("LastName")), _text(au.find("Initials"))]))
            if name or au.find("CollectiveName") is not None:
                authors.append(name or _text(au.find("CollectiveName")))
        year_txt = _text(a.find("Journal/JournalIssue/PubDate/Year")) or _text(
            a.find("Journal/JournalIssue/PubDate/MedlineDate"))[:4]
        ids = {i.get("IdType"): _text(i) for i in art.findall("PubmedData/ArticleIdList/ArticleId")}
        records.append(Record(
            source="pubmed",
            title=_text(a.find("ArticleTitle")).rstrip("."),
            abstract=" ".join(parts) or None,
            authors=authors,
            year=int(year_txt) if year_txt.isdigit() else None,
            journal=_text(a.find("Journal/Title")) or None,
            pmid=_text(cit.find("PMID")),
            pmcid=ids.get("pmc"),
            doi=ids.get("doi"),
            subgoal_ids=[subgoal_id],
        ))
    return records
