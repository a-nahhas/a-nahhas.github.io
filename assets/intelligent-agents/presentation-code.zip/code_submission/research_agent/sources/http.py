"""HTTP with bounded exponential back-off.

Free academic APIs fail transiently and often (Semantic Scholar's unauthenticated
pool regularly returns 429). Retrying with exponential back-off and jitter spreads
retries out instead of hammering a recovering service; the attempt cap keeps a dead
source from stalling the whole run, after which the failure is *reported* rather
than hidden (see ``RetrievalError``).
"""

from __future__ import annotations

import logging
import random
import time
from typing import Any, Callable

import httpx

log = logging.getLogger(__name__)

RETRYABLE_STATUS = {429, 500, 502, 503, 504}
USER_AGENT = "research-planning-agent/1.0 (academic prototype; mailto:{email})"


class RetrievalError(RuntimeError):
    """Raised once retries are exhausted; the agent records it as a failed subgoal."""


def get_with_backoff(
    client: httpx.Client,
    url: str,
    params: dict[str, Any] | None = None,
    *,
    max_attempts: int = 4,
    base_delay: float = 1.0,
    max_delay: float = 20.0,
    extra_retry: frozenset[int] = frozenset(),
    sleep: Callable[[float], None] | None = None,
) -> httpx.Response:
    # ``sleep`` is injectable so tests can verify the back-off schedule instantly. It is
    # resolved at call time, not as a default argument, so patching time.sleep also works.
    sleep = sleep or time.sleep
    last_error = "unknown error"
    for attempt in range(1, max_attempts + 1):
        try:
            resp = client.get(url, params=params)
        except httpx.TransportError as exc:
            last_error = f"{type(exc).__name__}: {exc}"
        else:
            if resp.status_code < 400:
                return resp
            if resp.status_code not in RETRYABLE_STATUS | extra_retry:
                # 4xx other than 429 means our request is wrong; retrying cannot help.
                raise RetrievalError(f"HTTP {resp.status_code} from {url}")
            last_error = f"HTTP {resp.status_code}"
            retry_after = resp.headers.get("Retry-After")
            if retry_after and retry_after.isdigit() and attempt < max_attempts:
                # The server's own hint beats our guess, within our ceiling.
                sleep(min(float(retry_after), max_delay))
                continue
        if attempt < max_attempts:
            delay = min(max_delay, base_delay * 2 ** (attempt - 1)) * random.uniform(0.8, 1.2)
            log.info("retrying %s after %s (attempt %d/%d, %.1fs)", url, last_error, attempt, max_attempts, delay)
            sleep(delay)
    raise RetrievalError(f"{last_error} after {max_attempts} attempts: {url}")


def make_client(email: str | None = None, timeout: float = 20.0) -> httpx.Client:
    return httpx.Client(
        timeout=timeout,
        headers={"User-Agent": USER_AGENT.format(email=email or "unset")},
        follow_redirects=True,
    )
