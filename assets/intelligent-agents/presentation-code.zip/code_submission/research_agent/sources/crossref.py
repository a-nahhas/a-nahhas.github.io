"""Publication status from Crossref.

A retracted trial entering a systematic review is a serious failure, and abstracts
do not announce their own retraction. Crossref's ``updates:`` filter returns notices
(including Retraction Watch data) that point *at* a DOI, which is the free, legal way
to check status.
"""

from __future__ import annotations

import time

import httpx

from .http import RetrievalError, get_with_backoff

URL = "https://api.crossref.org/works"


class CrossrefClient:
    def __init__(self, client: httpx.Client, email: str | None = None, min_interval: float = 1.0):
        self.client = client
        # Back-to-back status checks drew HTTP 429s live (REMEDIATION R5); pacing
        # requests is cheaper than backing off after being refused.
        self.min_interval = min_interval
        self._last = 0.0
        # Crossref routes requests that include a contact to its more reliable "polite" pool.
        self.params = {"mailto": email} if email else {}

    def status(self, doi: str) -> str:
        """Return 'retracted', 'corrected', 'active', or 'unknown' if the lookup failed."""
        wait = self.min_interval - (time.monotonic() - self._last)
        if wait > 0:
            time.sleep(wait)
        self._last = time.monotonic()
        try:
            data = get_with_backoff(self.client, URL, {**self.params, "filter": f"updates:{doi}", "rows": 20},
                                    max_attempts=3).json()
        except (RetrievalError, ValueError):
            # 'unknown' is surfaced to the reviewer; it is never silently treated as active.
            return "unknown"
        types = {
            u.get("type", "").lower()
            for item in data.get("message", {}).get("items", [])
            for u in item.get("update-to", [])
            if u.get("DOI", "").lower() == doi.lower()
        }
        if any("retract" in t or "withdraw" in t for t in types):
            return "retracted"
        if types:
            return "corrected"
        return "active"
