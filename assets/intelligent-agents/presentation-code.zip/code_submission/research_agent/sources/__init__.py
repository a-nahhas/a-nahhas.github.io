"""Literature and publication-status sources."""

from .crossref import CrossrefClient
from .http import RetrievalError, get_with_backoff, make_client
from .pubmed import PubMedClient
from .semantic_scholar import SemanticScholarClient

__all__ = ["CrossrefClient", "PubMedClient", "SemanticScholarClient", "RetrievalError",
           "get_with_backoff", "make_client"]
