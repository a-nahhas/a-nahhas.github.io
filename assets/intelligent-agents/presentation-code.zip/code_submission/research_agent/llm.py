"""LLM access and schema-validated generation.

The agents depend only on the small ``LLM`` protocol below, not on a vendor SDK.
That keeps the model replaceable, as the design requires (a Hugging Face endpoint
would need only another ~30-line adapter), and lets tests substitute a scripted
model so agent behaviour can be verified deterministically and offline.

LangChain's model wrappers were considered and not used: the agents need exactly one
operation (prompt in, text out), and owning the validate-and-reprompt loop makes the
bounded-retry behaviour explicit and testable rather than buried in a framework.
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
from typing import Protocol, TypeVar

from pydantic import BaseModel, ValidationError

log = logging.getLogger(__name__)
T = TypeVar("T", bound=BaseModel)


class LLM(Protocol):
    def complete(self, prompt: str, system: str | None = None) -> str: ...


class SchemaEscalation(RuntimeError):
    """Raised when the model cannot produce valid output within the retry budget.

    The caller escalates to the human rather than guessing, matching the design's
    'flag for human review if retries exhausted' branch (Figure 2).
    """

    def __init__(self, message: str, attempts: list[str]):
        super().__init__(message)
        self.attempts = attempts


def _extract_json(text: str) -> str:
    # Models sometimes wrap JSON in markdown fences even when asked not to; stripping
    # them is cheaper than spending a re-prompt on a purely cosmetic problem.
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    return (m.group(1) if m else text).strip()


def generate_structured(llm: LLM, prompt: str, schema: type[T], *, system: str | None = None,
                        max_retries: int = 3) -> T:
    """Ask for JSON matching ``schema``; on failure re-prompt with the validation error.

    Feeding the concrete error back lets the model repair its own output, which works
    far better than repeating the identical prompt. ``max_retries`` counts re-prompts,
    so the model gets at most ``max_retries + 1`` attempts in total.
    """
    schema_json = json.dumps(schema.model_json_schema(), separators=(",", ":"))
    full_prompt = f"{prompt}\n\nReturn only a JSON object conforming to this JSON Schema:\n{schema_json}"
    attempts: list[str] = []
    current = full_prompt
    for attempt in range(max_retries + 1):
        raw = llm.complete(current, system=system)
        attempts.append(raw)
        try:
            return schema.model_validate_json(_extract_json(raw))
        except ValidationError as exc:
            error = exc.errors(include_url=False, include_input=False)
            log.warning("schema validation failed (attempt %d/%d): %s", attempt + 1, max_retries + 1, error)
            current = (f"{full_prompt}\n\nYour previous reply was invalid.\nReply: {raw[:2000]}\n"
                       f"Validation errors: {json.dumps(error, default=str)[:2000]}\n"
                       "Return a corrected JSON object only.")
    raise SchemaEscalation(f"no valid {schema.__name__} after {max_retries + 1} attempts", attempts)


class LLMUnavailable(RuntimeError):
    """Every configured model is overloaded or out of quota; callers escalate to the human."""


class GeminiLLM:
    """Gemini via the official google-genai SDK (free tier), with model fallback.

    The first live run hit sustained HTTP 503 'high demand' on the free tier for the
    primary model (docs/REMEDIATION.md, R3). Back-off alone cannot fix capacity
    shortages, so after a short back-off the client fails over to the next model in
    ``models``. This is the replaceable-LLM design requirement used operationally.
    Because the agents only see ``complete()``, failover is invisible to them apart
    from the per-call model record kept in ``calls``.
    """

    TRANSIENT = (429, 500, 503, 504)

    def __init__(self, api_key: str, models: list[str] | str, min_interval: float = 4.0,
                 retries_per_model: int = 2, rounds: int = 2, round_pause: float = 30.0):
        from google import genai  # imported lazily so tests never need the SDK configured

        self._client = genai.Client(api_key=api_key)
        self.models = [models] if isinstance(models, str) else list(models)
        self.min_interval = min_interval
        self.retries_per_model = retries_per_model
        # Free-tier capacity flaps minute to minute (R4), so a model that was down a
        # moment ago is worth retrying: cycle the list for ``rounds`` passes rather
        # than failing over strictly forwards and running out of models.
        self.rounds = rounds
        self.round_pause = round_pause
        self._active = 0  # start each call at the last model that worked
        self._retired: set[str] = set()  # 404: model withdrawn, never retried
        self._last = 0.0
        self._lock = threading.Lock()
        self.calls: list[str] = []  # model used per successful call, for the run evidence

    @property
    def model(self) -> str:
        return self.models[self._active]

    def _throttle(self) -> None:
        with self._lock:
            wait = self.min_interval - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()

    def complete(self, prompt: str, system: str | None = None) -> str:
        import httpx
        from google.genai import errors, types

        config = types.GenerateContentConfig(
            system_instruction=system,
            # JSON mode stops prose around the payload; the schema is still checked by
            # Pydantic because JSON mode guarantees syntax, not our domain constraints.
            response_mime_type="application/json",
            # Low thinking: the tasks are decomposition and extraction, not multi-step
            # maths, and lower latency matters more on a rate-limited free tier.
            thinking_config=types.ThinkingConfig(thinking_level=types.ThinkingLevel.LOW),
        )
        n = len(self.models)
        for rnd in range(self.rounds):
            if rnd:
                log.warning("all models busy; pausing %.0fs before round %d", self.round_pause, rnd + 1)
                time.sleep(self.round_pause)
            for offset in range(n):
                idx = (self._active + offset) % n
                name = self.models[idx]
                if name in self._retired:
                    continue
                for attempt in range(self.retries_per_model + 1):
                    self._throttle()
                    try:
                        resp = self._client.models.generate_content(model=name, contents=prompt, config=config)
                    except httpx.TransportError as exc:
                        # A dropped connection is as transient as a 503 (R8); before this
                        # branch existed it escaped the failover logic and crashed the run.
                        if attempt < self.retries_per_model:
                            delay = 5.0 * 2 ** attempt
                            log.warning("Gemini connection error on %s (%s); backing off %.0fs",
                                        name, type(exc).__name__, delay)
                            time.sleep(delay)
                    except errors.APIError as exc:
                        if exc.code == 404:
                            # Free-tier models get withdrawn (R4); skip for the session.
                            log.warning("model %s not available (404); retiring it", name)
                            self._retired.add(name)
                            break
                        if exc.code not in self.TRANSIENT:
                            raise  # a 400/403 is a bug or a bad key; failing over would hide it
                        if attempt < self.retries_per_model:
                            delay = 5.0 * 2 ** attempt
                            log.warning("Gemini %s on %s; backing off %.0fs", exc.code, name, delay)
                            time.sleep(delay)
                    else:
                        if idx != self._active:
                            log.warning("now using model %s", name)
                        self._active = idx
                        self.calls.append(name)
                        return resp.text or ""
                else:
                    log.warning("model %s busy; failing over", name)
        raise LLMUnavailable(f"all models unavailable after {self.rounds} rounds: {self.models}")


class ScriptedLLM:
    """Deterministic stand-in for tests and offline demos.

    Responses are consumed in order; a callable response receives the prompt, which
    lets functional tests answer based on what the agent actually asked.
    """

    def __init__(self, responses: list):
        self.responses = list(responses)
        self.prompts: list[str] = []

    def complete(self, prompt: str, system: str | None = None) -> str:
        self.prompts.append(prompt)
        if not self.responses:
            raise AssertionError("ScriptedLLM ran out of responses")
        r = self.responses.pop(0)
        r = r(prompt) if callable(r) else r
        return r if isinstance(r, str) else json.dumps(r)
