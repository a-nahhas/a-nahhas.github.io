"""SQLite evidence store.

SQLite was chosen over a hosted database because it is free, needs no server, and a
single file is easy to hand to a reviewer or attach to a submission. Only records a
human has approved enter ``evidence``; every decision, including rejections, goes to
``review_log`` so the store can be reconciled against the reviewer's actions
(success criterion: storage reconciles with the decision log).
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .models import EvidenceRecord, QueryLogEntry, ReviewDecision, RunReport

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id      TEXT PRIMARY KEY,
    question    TEXT NOT NULL,
    report_json TEXT,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS query_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id     TEXT NOT NULL REFERENCES runs(run_id),
    subgoal_id INTEGER,
    source     TEXT,
    query      TEXT,
    status     TEXT,
    n_results  INTEGER,
    error      TEXT,
    timestamp  TEXT
);
CREATE TABLE IF NOT EXISTS evidence (
    run_id             TEXT NOT NULL REFERENCES runs(run_id),
    record_key         TEXT NOT NULL,
    title              TEXT NOT NULL,
    pmid               TEXT,
    doi                TEXT,
    year               INTEGER,
    screening_decision TEXT NOT NULL,
    publication_status TEXT NOT NULL,
    evidence_basis     TEXT NOT NULL,
    claims_json        TEXT NOT NULL,
    reviewer_note      TEXT,
    approved_at        TEXT NOT NULL,
    PRIMARY KEY (run_id, record_key)
);
CREATE TABLE IF NOT EXISTS review_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id     TEXT NOT NULL REFERENCES runs(run_id),
    record_key TEXT NOT NULL,
    decision   TEXT NOT NULL,
    note       TEXT,
    reviewer   TEXT,
    timestamp  TEXT NOT NULL
);
"""


class EvidenceStore:
    def __init__(self, path: Path | str):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        # One long-lived connection: required for ":memory:" databases in tests, and
        # harmless for a single-user prototype.
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        # A transaction per logical operation so a crash never leaves an approved
        # record in ``evidence`` without its matching ``review_log`` row.
        try:
            yield self._conn
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    def save_run(self, report: RunReport, query_log: list[QueryLogEntry]) -> None:
        with self._tx() as c:
            c.execute(
                "INSERT OR REPLACE INTO runs (run_id, question, report_json) VALUES (?, ?, ?)",
                (report.run_id, report.question, report.model_dump_json()),
            )
            c.execute("DELETE FROM query_log WHERE run_id = ?", (report.run_id,))
            c.executemany(
                "INSERT INTO query_log (run_id, subgoal_id, source, query, status, n_results, error, timestamp)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    (report.run_id, q.subgoal_id, q.source, q.query, q.status, q.n_results, q.error, q.timestamp)
                    for q in query_log
                ],
            )

    def apply_review(self, run_id: str, evidence: list[EvidenceRecord], decisions: list[ReviewDecision]) -> int:
        """Log every decision; persist only approvals.

        Returns how many records from this batch are approved once the batch is
        applied: a later decision on the same record overrides an earlier one, so
        counting approve rows would over-report.
        """
        by_key = {e.record.key: e for e in evidence}
        final: dict[str, str] = {}
        with self._tx() as c:
            for d in decisions:
                if d.record_key not in by_key:
                    raise KeyError(f"decision for unknown record {d.record_key}")
                c.execute(
                    "INSERT INTO review_log (run_id, record_key, decision, note, reviewer, timestamp)"
                    " VALUES (?, ?, ?, ?, ?, ?)",
                    (run_id, d.record_key, d.decision, d.note, d.reviewer, d.timestamp),
                )
                if d.decision == "approve":
                    e = by_key[d.record_key]
                    c.execute(
                        "INSERT OR REPLACE INTO evidence VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (
                            run_id, d.record_key, e.record.title, e.record.pmid, e.record.doi, e.record.year,
                            e.decision, e.publication_status, e.record.evidence_basis,
                            json.dumps([cl.model_dump() for cl in e.claims]), d.note, d.timestamp,
                        ),
                    )
                else:
                    # A later flag/reject overrides an earlier approval of the same record.
                    c.execute("DELETE FROM evidence WHERE run_id = ? AND record_key = ?", (run_id, d.record_key))
                final[d.record_key] = d.decision
        return sum(v == "approve" for v in final.values())

    def evidence(self, run_id: str | None = None) -> list[dict]:
        sql, args = "SELECT * FROM evidence", ()
        if run_id:
            sql, args = sql + " WHERE run_id = ?", (run_id,)
        return [dict(r) for r in self._conn.execute(sql + " ORDER BY approved_at", args)]

    def query_log(self, run_id: str) -> list[dict]:
        return [dict(r) for r in self._conn.execute("SELECT * FROM query_log WHERE run_id = ?", (run_id,))]

    def reconcile(self, run_id: str) -> dict:
        """Check that ``evidence`` holds exactly the records whose latest decision is approve."""
        latest: dict[str, str] = {}
        for r in self._conn.execute(
            "SELECT record_key, decision FROM review_log WHERE run_id = ? ORDER BY id", (run_id,)
        ):
            latest[r["record_key"]] = r["decision"]
        expected = {k for k, v in latest.items() if v == "approve"}
        stored = {r["record_key"] for r in self._conn.execute(
            "SELECT record_key FROM evidence WHERE run_id = ?", (run_id,))}
        return {
            "ok": expected == stored,
            "expected": len(expected),
            "stored": len(stored),
            "missing": sorted(expected - stored),
            "unexpected": sorted(stored - expected),
        }

    def close(self) -> None:
        self._conn.close()
