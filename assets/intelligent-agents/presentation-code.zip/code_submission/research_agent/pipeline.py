"""Wires the two agents, the human review gate and the evidence store together.

The pipeline is the only place that knows about files and the database; the agents
receive and return plain models. That separation is what lets the same agents run
under the CLI, Streamlit and the test suite.
"""

from __future__ import annotations

import json
import logging
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

from .config import Settings
from .curation import CurationAgent
from .llm import LLM, GeminiLLM
from .models import CurationReport, ResultsBuffer, ReviewDecision, RunReport, SourceStatus
from .planning import PlanningRetrievalAgent
from .sources import CrossrefClient, PubMedClient, SemanticScholarClient, make_client
from .store import EvidenceStore

log = logging.getLogger(__name__)


@dataclass
class RunResult:
    buffer: ResultsBuffer
    curation: CurationReport | None
    report: RunReport
    run_dir: Path


def source_status(buffer: ResultsBuffer) -> dict[str, SourceStatus]:
    """Per-source outcome from the query log (successful, failed, skipped calls)."""
    out: dict[str, SourceStatus] = {}
    for q in buffer.query_log:
        st = out.setdefault(q.source, SourceStatus())
        if q.status == "ok":
            st.ok += 1
            st.records += q.n_results
        elif (q.error or "").startswith("skipped"):
            st.skipped += 1
        else:
            st.error += 1
    return out


def settings_snapshot(s: Settings) -> dict:
    """The settings that shape what is retrieved and screened, minus secrets and paths."""
    keep = ("model", "fallback_models", "max_subgoals", "results_per_subgoal", "min_results_per_subgoal",
            "max_refinements_per_subgoal", "max_react_steps", "source_failure_limit", "screen_limit",
            "screen_batch_size", "pubmed_language")
    snap = {k: v for k, v in asdict(s).items() if k in keep}
    snap["pubmed_sort"] = "relevance"
    snap["semantic_scholar_key"] = bool(s.s2_api_key)
    return snap


def build_report(buffer: ResultsBuffer, cur: CurationReport | None,
                 models_used: dict[str, int] | None = None, settings: dict | None = None,
                 criteria_source: str = "none") -> RunReport:
    n_sg = len(buffer.plan.subgoals) if buffer.plan else 0
    ev = cur.evidence if cur else []
    screened = [e for e in ev if e.screened]
    sources = source_status(buffer)
    return RunReport(
        run_id=buffer.run_id, question=buffer.question, n_subgoals=n_sg,
        completed_subgoals=buffer.completed_subgoals, failed_subgoals=buffer.failed_subgoals,
        # Coverage is reported per subgoal, not per record: it tells the researcher
        # which parts of the question the search did not reach.
        coverage=round(len(buffer.completed_subgoals) / n_sg, 3) if n_sg else 0.0,
        n_retrieved=len(buffer.records), n_after_dedup=cur.n_after_dedup if cur else 0,
        n_no_abstract=cur.n_no_abstract if cur else 0, n_screened=cur.n_screened if cur else 0,
        n_not_screened=cur.n_not_screened if cur else 0,
        n_include=sum(e.decision == "include" for e in screened),
        n_uncertain=sum(e.decision == "uncertain" for e in screened),
        n_exclude=sum(e.decision == "exclude" for e in screened),
        n_claims_rejected=cur.n_claims_rejected if cur else 0,
        needs_human=buffer.needs_human,
        models_used=models_used or {},
        source_status=sources,
        # A source with no successful call contributed nothing; subgoal coverage can
        # still read 100% because the other source answered, so name it explicitly.
        sources_unavailable=sorted(name for name, st in sources.items() if st.ok == 0),
        settings=settings or {},
        criteria_source=criteria_source if buffer.plan else "none",
    )


class ResearchPipeline:
    def __init__(self, llm: LLM, sources: dict, crossref=None, settings: Settings | None = None,
                 store: EvidenceStore | None = None):
        self.s = settings or Settings()
        self.llm = llm
        self.planner = PlanningRetrievalAgent(llm, sources, self.s)
        self.curator = CurationAgent(llm, crossref, self.s)
        self.store = store or EvidenceStore(self.s.db_path)

    @classmethod
    def from_settings(cls, settings: Settings | None = None) -> "ResearchPipeline":
        s = settings or Settings()
        if not s.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not set; copy .env.example to .env and add a key.")
        http = make_client(s.ncbi_email)
        return cls(
            llm=GeminiLLM(s.gemini_api_key, [s.model, *s.fallback_models], s.llm_min_interval),
            sources={"pubmed": PubMedClient(http, s.ncbi_email, s.ncbi_api_key, language=s.pubmed_language),
                     # Separate client: the S2 key is a header, and must not leak to NCBI.
                     "semantic_scholar": SemanticScholarClient(make_client(s.ncbi_email), api_key=s.s2_api_key)},
            crossref=CrossrefClient(http, s.ncbi_email),
            settings=s,
        )

    def run(self, question: str, *, feedback: str | None = None, previous: ResultsBuffer | None = None,
            criteria: tuple[list[str], list[str]] | None = None) -> RunResult:
        calls_before = len(getattr(self.llm, "calls", []))
        # A re-plan keeps the researcher's fixed criteria unless new ones are given.
        if criteria is None and previous is not None and previous.criteria_fixed and previous.plan:
            criteria = (previous.plan.inclusion_criteria, previous.plan.exclusion_criteria)
        buffer = self.planner.run(question, feedback=feedback, previous_plan=previous.plan if previous else None,
                                  criteria=criteria)
        fixed = bool(criteria and criteria[0])
        buffer.criteria_fixed = fixed
        run_dir = self.s.runs_dir / buffer.run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        # The buffer is written to disk before curation reads it: the hand-off is a
        # real, inspectable artefact (Figure 1, steps 4 and 5-a), not just an object.
        buffer_path = run_dir / "buffer.json"
        buffer_path.write_text(buffer.model_dump_json(indent=2), encoding="utf-8")

        curation = None
        if buffer.plan is not None:
            curation = self.curator.run(ResultsBuffer.model_validate_json(buffer_path.read_text(encoding="utf-8")))
            (run_dir / "curation.json").write_text(curation.model_dump_json(indent=2), encoding="utf-8")
        used = Counter(getattr(self.llm, "calls", [])[calls_before:])
        report = build_report(buffer, curation, dict(used), settings_snapshot(self.s),
                              "researcher" if fixed else "llm")
        (run_dir / "report.json").write_text(report.model_dump_json(indent=2), encoding="utf-8")
        self.store.save_run(report, buffer.query_log)
        log.info("run %s: coverage %.0f%%, %d include / %d uncertain / %d exclude; unavailable sources: %s",
                 report.run_id, report.coverage * 100, report.n_include, report.n_uncertain, report.n_exclude,
                 report.sources_unavailable or "none")
        return RunResult(buffer, curation, report, run_dir)

    def review(self, result: RunResult, decisions: list[ReviewDecision]) -> int:
        """Human verification gate: only approved records enter the evidence table.

        Every decision is logged, so the evidence table can be reconciled against the
        reviewer's actions. Retrieved records (including unapproved ones) do persist
        in the run artefacts; see the data-flow table in the README.
        """
        n = self.store.apply_review(result.report.run_id, result.curation.evidence if result.curation else [],
                                    decisions)
        with (result.run_dir / "review_log.jsonl").open("a", encoding="utf-8") as f:
            for d in decisions:
                f.write(json.dumps(d.model_dump()) + "\n")
        return n

    def revise_flagged(self, result: RunResult, decisions: list[ReviewDecision]) -> int:
        """Send flagged records back to the Curation Agent with the reviewer's notes.

        The revised records replace the originals in ``result.curation`` so the
        reviewer sees the new screening and decides again. Returns how many were sent.
        """
        if not result.curation:
            return 0
        notes = {d.record_key: d.note for d in decisions if d.decision == "flag"}
        flagged = [(e, notes[e.record.key]) for e in result.curation.evidence if e.record.key in notes]
        if not flagged:
            return 0
        revised = {e.record.key: e for e in self.curator.revise(result.buffer.question, result.buffer.plan, flagged)}
        result.curation.evidence = [revised.get(e.record.key, e) for e in result.curation.evidence]
        result.curation.n_claims_rejected = sum(len(e.rejected_claims) for e in result.curation.evidence)
        (result.run_dir / "curation.json").write_text(result.curation.model_dump_json(indent=2), encoding="utf-8")
        log.info("run %s: %d flagged record(s) re-screened by the Curation Agent", result.report.run_id, len(revised))
        return len(revised)
