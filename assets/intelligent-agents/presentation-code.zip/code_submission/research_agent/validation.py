"""Deterministic traceability and fidelity checks on LLM output.

The single most damaging failure for a review tool is a fabricated or misattributed
claim entering the evidence base. Summaries are therefore extractive: each claim must
carry a verbatim supporting extract, and this module verifies that the extract really
occurs in the record's abstract. The check is deterministic code rather than another
LLM call, so the check itself cannot hallucinate; it implements the traceable
evidence chain that Wang, G. et al. (2026) recommend for human-LLM collaboration, and
the extract-level verification used in LEADS (Wang, Z. et al., 2025).

Limitation, stated honestly: this proves the *extract* is genuine, not that the
claim's paraphrase is faithful to it. That residual judgement is why the reviewer
sees claim and extract side by side.
"""

from __future__ import annotations

import difflib
import re
import unicodedata

from rapidfuzz import fuzz

from .models import Claim, Record

# The fuzzy path only *locates* the most similar span of the abstract; acceptance is
# then decided word by word (``_tokens_match``). Character similarity alone proved
# unsafe twice: a changed digit ("2.1" -> "3.1", REMEDIATION R6) and a flipped
# negation ("no significant" -> "a significant", R10) each cost only a character or
# two and scored above 97.
LOCATE_THRESHOLD = 90
MIN_EXTRACT_CHARS = 10

# Words whose substitution changes what a finding means. A fuzzy match may never
# alter one of these, however similar the spelling ("significant"/"insignificant").
CRITICAL_WORDS = frozenset("""
no not non without never neither nor none absent absence fail failed failure
nonsignificant insignificant significant significantly
increase increased increases increasing decrease decreased decreases decreasing
higher lower more less greater fewer better worse improved improvement improves
improving reduce reduced reduces reducing reduction superior inferior positive
negative benefit beneficial harm harmful effective ineffective
""".split())

_TRANSLATE = str.maketrans({"‘": "'", "’": "'", "“": '"', "”": '"',
                            "–": "-", "—": "-", "−": "-", " ": " "})
_PUNCT = re.compile(r"[^\w.%-]")


def normalise(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).translate(_TRANSLATE).lower()
    return re.sub(r"\s+", " ", text).strip()


def _tokens(text: str) -> list[str]:
    # Punctuation is dropped (so "nrs," == "nrs"), but decimal points, percent signs
    # and a leading minus are kept because they are part of a number's meaning.
    out = []
    for w in text.split():
        t = _PUNCT.sub("", w).rstrip(".")
        if t:
            out.append(t)
    return out


def _is_critical(token: str) -> bool:
    return any(ch.isdigit() for ch in token) or token in CRITICAL_WORDS


def extract_in_abstract(extract: str, abstract: str) -> bool:
    e, a = normalise(extract), normalise(abstract)
    # A blank or trivially short "extract" is found almost anywhere (R10).
    if len(e) < MIN_EXTRACT_CHARS or len(e) > len(a):
        return False
    if e in a:
        return True
    # Section labels we add ("RESULTS: ") are sometimes dropped or kept by the model;
    # strip a leading label and retry, but only if a substantive extract remains.
    e2 = re.sub(r"^[a-z ]{3,30}: ", "", e)
    if e2 != e and len(e2) >= MIN_EXTRACT_CHARS and e2 in a:
        return True
    if len(e) < 20:
        return False
    align = fuzz.partial_ratio_alignment(e, a, score_cutoff=LOCATE_THRESHOLD)
    if align is None:
        return False
    # Widen the located window to whole words so an edge word is not truncated.
    start = a.rfind(" ", 0, align.dest_start) + 1
    end = a.find(" ", align.dest_end)
    span = a[start:] if end == -1 else a[start:end]
    return _tokens_match(_tokens(span), _tokens(e))


def _tokens_match(span: list[str], extract: list[str]) -> bool:
    """Accept only cosmetic, one-for-one word differences.

    Allowed: a word replaced by a near-identical spelling (e.g. a Unicode or hyphen
    variant). Rejected: any added or dropped word (invented text), and any change to a
    number, negation or direction word, which is where a misquote does real harm.
    """
    ops = difflib.SequenceMatcher(None, span, extract, autojunk=False).get_opcodes()
    # Leading/trailing words present only in the abstract are surrounding context
    # picked up by the widened window, not part of the extract.
    if ops and ops[0][0] == "delete":
        ops = ops[1:]
    if ops and ops[-1][0] == "delete":
        ops = ops[:-1]
    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal":
            continue
        if tag != "replace" or (i2 - i1) != (j2 - j1):
            return False
        for s_tok, e_tok in zip(span[i1:i2], extract[j1:j2]):
            if _is_critical(s_tok) or _is_critical(e_tok) or fuzz.ratio(s_tok, e_tok) < 80:
                return False
    return True


def has_persistent_id(record: Record) -> bool:
    return bool(record.pmid or record.doi or record.s2_id)


def validate_claims(record: Record, claims: list[Claim]) -> tuple[list[Claim], list[Claim], list[str]]:
    """Split claims into (valid, rejected) and return human-readable notes."""
    notes: list[str] = []
    if not has_persistent_id(record):
        # Traceability criterion: a claim that cannot be resolved to an identifier is
        # rejected regardless of its content.
        return [], list(claims), ["record has no PMID/DOI/S2 id; all claims rejected as untraceable"]
    if not record.abstract:
        return [], list(claims), ["record has no abstract; claims cannot be verified"]
    valid, rejected = [], []
    for c in claims:
        (valid if extract_in_abstract(c.supporting_extract, record.abstract) else rejected).append(c)
    if rejected:
        notes.append(f"{len(rejected)} claim(s) rejected: supporting extract not found in abstract")
    return valid, rejected, notes
