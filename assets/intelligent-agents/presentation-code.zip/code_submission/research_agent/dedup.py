"""Deterministic deduplication.

Kept outside the LLM on purpose: deduplication has a right answer, so routing it
through a stochastic model would add variability and cost for no benefit. The same
study commonly arrives twice, from PubMed and from Semantic Scholar, sometimes with
only one side carrying a DOI, so exact identifier matching alone is not enough.
"""

from __future__ import annotations

import re

from rapidfuzz import fuzz

from .models import Record

# Deliberately conservative: a missed merge only costs the reviewer one duplicate
# row, whereas a false merge silently drops a distinct study from the evidence base.
# Casing and punctuation are normalised away first, so true duplicates score ~100.
TITLE_SIMILARITY_THRESHOLD = 93
_NUM = re.compile(r"\d+")


def _norm_title(title: str) -> str:
    # Punctuation becomes a space (not nothing) so "low-back" and "low back" agree;
    # deleting it outright fused words and broke matching (see docs/REMEDIATION.md, R1).
    return " ".join(re.sub(r"[^a-z0-9]+", " ", title.lower()).split())


def _same_study(a: Record, b: Record) -> bool:
    for attr in ("doi", "pmid", "s2_id"):
        va, vb = getattr(a, attr), getattr(b, attr)
        if va and vb:
            # A conflicting strong identifier means different studies even if the
            # titles look alike (e.g. an erratum shares its parent's title).
            return va == vb
    if a.year and b.year and abs(a.year - b.year) > 1:
        return False
    ta, tb = _norm_title(a.title), _norm_title(b.title)
    # Companion papers of one trial differ only in a number ("6-month" vs "12-month
    # follow-up") yet score ~98. A title-only match therefore also needs identical
    # numbers; otherwise the merge would also copy one paper's DOI onto the other
    # (REMEDIATION R15).
    if _NUM.findall(ta) != _NUM.findall(tb):
        return False
    return fuzz.token_sort_ratio(ta, tb) >= TITLE_SIMILARITY_THRESHOLD


def _merge(keep: Record, other: Record) -> Record:
    """Union of what both copies know; PubMed metadata wins when both have it."""
    data = keep.model_dump()
    for field in ("abstract", "doi", "pmid", "pmcid", "s2_id", "journal", "year"):
        if not data.get(field) and getattr(other, field):
            data[field] = getattr(other, field)
    if not data["authors"]:
        data["authors"] = other.authors
    # A longer abstract is usually the structured PubMed one rather than a truncation.
    if other.abstract and data["abstract"] and len(other.abstract) > len(data["abstract"]) * 1.2:
        data["abstract"] = other.abstract
    data["subgoal_ids"] = sorted(set(keep.subgoal_ids) | set(other.subgoal_ids))
    return Record(**data)


def deduplicate(records: list[Record]) -> list[Record]:
    """O(n^2) pairwise merge.

    n is bounded by subgoals x results_per_subgoal x sources x (1 + refinements), at
    most about 160, so the quadratic cost is negligible and buys a simpler, more
    inspectable algorithm than blocking or clustering would.
    """
    # PubMed first so its curated metadata is the base copy that others merge into.
    ordered = sorted(records, key=lambda r: 0 if r.source == "pubmed" else 1)
    unique: list[Record] = []
    for rec in ordered:
        for i, existing in enumerate(unique):
            if _same_study(existing, rec):
                unique[i] = _merge(existing, rec)
                break
        else:
            unique.append(rec)
    return unique
