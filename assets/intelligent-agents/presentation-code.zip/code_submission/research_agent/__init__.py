"""LLM-powered academic research planning agent (two-agent design)."""

__version__ = "1.0.0"
