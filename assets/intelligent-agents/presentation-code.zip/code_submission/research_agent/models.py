"""Shared schemas.

Every message that crosses an agent boundary is one of these Pydantic models. The
design deliberately uses a schema-validated JSON buffer instead of an agent
communication language such as KQML: KQML targets autonomous, heterogeneous agents
negotiating across independently owned knowledge bases (Finin et al., 1994), whereas
here both agents live in one trusted process with fixed roles, so a shared, validated
schema gives the same guarantees with far less machinery.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Planning (intentions)
# ---------------------------------------------------------------------------

class Subgoal(BaseModel):
    """One committed search intention.

    Two query forms are kept because the sources disagree on syntax: PubMed supports
    Boolean/MeSH field tags, Semantic Scholar only plain keywords. Asking the LLM for
    both up front avoids a second translation call per subgoal.
    """

    id: int = Field(ge=1)
    description: str = Field(min_length=5)
    pubmed_query: str = Field(min_length=3)
    keyword_query: str = Field(min_length=3)
    sources: list[Literal["pubmed", "semantic_scholar"]] = Field(min_length=1)
    rationale: str = Field(min_length=5)


class SubgoalPlan(BaseModel):
    subgoals: list[Subgoal] = Field(min_length=1, max_length=8)
    inclusion_criteria: list[str] = Field(min_length=1)
    exclusion_criteria: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _unique_ids(self) -> "SubgoalPlan":
        # Duplicate ids would make the query log and failure report ambiguous.
        ids = [s.id for s in self.subgoals]
        if len(ids) != len(set(ids)):
            raise ValueError("subgoal ids must be unique")
        return self


class ReactDecision(BaseModel):
    """The agent's 'thought + action' after observing a weak retrieval."""

    thought: str
    action: Literal["accept", "refine", "drop"]
    refined_pubmed_query: str | None = None
    refined_keyword_query: str | None = None

    @model_validator(mode="after")
    def _refine_needs_query(self) -> "ReactDecision":
        if self.action == "refine" and not (self.refined_pubmed_query or self.refined_keyword_query):
            raise ValueError("action 'refine' requires at least one refined query")
        return self


# ---------------------------------------------------------------------------
# Retrieval (beliefs)
# ---------------------------------------------------------------------------

class Record(BaseModel):
    source: Literal["pubmed", "semantic_scholar"]
    title: str
    abstract: str | None = None
    authors: list[str] = Field(default_factory=list)
    year: int | None = None
    journal: str | None = None
    pmid: str | None = None
    pmcid: str | None = None
    doi: str | None = None
    s2_id: str | None = None
    subgoal_ids: list[int] = Field(default_factory=list)
    retrieved_at: str = Field(default_factory=utcnow)
    # Never full text in this prototype: the Curation Agent reasons over a partially
    # observable view of each study (Wooldridge, 2009) and says so. Derived, not
    # trusted from input, so a title-only record can never be labelled "abstract".
    evidence_basis: Literal["abstract", "title-only"] = "abstract"

    @model_validator(mode="after")
    def _derive_basis(self) -> "Record":
        self.evidence_basis = "abstract" if self.abstract else "title-only"
        return self

    @field_validator("doi")
    @classmethod
    def _normalise_doi(cls, v: str | None) -> str | None:
        # DOIs are case-insensitive; normalising here makes exact dedup reliable.
        if not v:
            return None
        v = v.strip().lower()
        for prefix in ("https://doi.org/", "http://doi.org/", "doi:"):
            if v.startswith(prefix):
                v = v[len(prefix):]
        return v

    @property
    def key(self) -> str:
        """Stable identifier, preferring the most portable one."""
        if self.doi:
            return f"doi:{self.doi}"
        if self.pmid:
            return f"pmid:{self.pmid}"
        if self.s2_id:
            return f"s2:{self.s2_id}"
        return f"title:{self.title.lower()[:80]}"


class QueryLogEntry(BaseModel):
    """Reproducibility record: what was asked of which source, when, with what result."""

    subgoal_id: int
    source: str
    query: str
    timestamp: str = Field(default_factory=utcnow)
    status: Literal["ok", "error"]
    n_results: int = 0
    error: str | None = None


class TraceStep(BaseModel):
    """One ReAct step, kept so the run can be explained afterwards."""

    step: int
    kind: Literal["plan", "thought", "action", "observation", "replan", "escalation"]
    content: str
    subgoal_id: int | None = None
    timestamp: str = Field(default_factory=utcnow)


class ResultsBuffer(BaseModel):
    """The JSON hand-off between the two agents (Figure 1, step 4/5-a)."""

    run_id: str
    question: str
    plan: SubgoalPlan | None
    records: list[Record] = Field(default_factory=list)
    query_log: list[QueryLogEntry] = Field(default_factory=list)
    trace: list[TraceStep] = Field(default_factory=list)
    completed_subgoals: list[int] = Field(default_factory=list)
    failed_subgoals: dict[int, str] = Field(default_factory=dict)
    needs_human: str | None = None
    # True when the eligibility criteria came from the researcher, not the LLM.
    criteria_fixed: bool = False
    created_at: str = Field(default_factory=utcnow)


# ---------------------------------------------------------------------------
# Curation
# ---------------------------------------------------------------------------

class Claim(BaseModel):
    text: str = Field(min_length=3)
    # Verbatim span from the abstract; this is what makes a fabricated claim visible
    # to the reviewer rather than merely unlikely.
    supporting_extract: str = Field(min_length=10)


class LLMScreening(BaseModel):
    """What the LLM is asked to return for one record."""

    record_index: int
    decision: Literal["include", "exclude", "uncertain"]
    relevance: float = Field(ge=0.0, le=1.0)
    reason: str
    claims: list[Claim] = Field(default_factory=list)


class LLMScreeningBatch(BaseModel):
    screenings: list[LLMScreening]


class EvidenceRecord(BaseModel):
    record: Record
    decision: Literal["include", "exclude", "uncertain"]
    relevance: float = 0.0
    lexical_score: float = 0.0
    # False for records listed only for accounting (no abstract, or below the
    # screening cut-off); they were never shown to the LLM.
    screened: bool = True
    reason: str
    claims: list[Claim] = Field(default_factory=list)
    rejected_claims: list[Claim] = Field(default_factory=list)
    validation_notes: list[str] = Field(default_factory=list)
    publication_status: Literal["active", "retracted", "corrected", "unknown"] = "unknown"


class CurationReport(BaseModel):
    run_id: str
    evidence: list[EvidenceRecord]
    n_input: int
    n_after_dedup: int
    n_no_abstract: int
    n_screened: int
    n_not_screened: int
    n_claims_rejected: int


class ReviewDecision(BaseModel):
    record_key: str
    decision: Literal["approve", "flag", "reject"]
    note: str = ""
    reviewer: str = "researcher"
    timestamp: str = Field(default_factory=utcnow)


class SourceStatus(BaseModel):
    ok: int = 0
    error: int = 0
    skipped: int = 0
    records: int = 0


class RunReport(BaseModel):
    """Per-run coverage account.

    PRISMA 2020 asks reviews to report how automation tools were used (Page et al.,
    2021); recording which subgoals and which sources succeeded is what makes that
    report possible, and stops a partial search passing as a complete one.
    """

    run_id: str
    question: str
    n_subgoals: int
    completed_subgoals: list[int]
    failed_subgoals: dict[int, str]
    coverage: float
    n_retrieved: int
    n_after_dedup: int
    n_no_abstract: int
    n_screened: int
    n_not_screened: int
    n_include: int
    n_uncertain: int
    n_exclude: int
    n_claims_rejected: int
    needs_human: str | None = None
    # Which LLM(s) actually answered; with free-tier failover this can differ from the
    # configured model, and results are not reproducible without knowing it.
    models_used: dict[str, int] = Field(default_factory=dict)
    # Per-source outcome. Subgoal coverage alone hid a source that failed on every
    # call while the other source carried the run (REMEDIATION R11).
    source_status: dict[str, SourceStatus] = Field(default_factory=dict)
    sources_unavailable: list[str] = Field(default_factory=list)
    # Reproducibility record: the search limits, screening limits, model list and
    # where the eligibility criteria came from (proposal FR4: queries, filters, timestamps).
    settings: dict = Field(default_factory=dict)
    criteria_source: Literal["researcher", "llm", "none"] = "none"
