"""Planning and Retrieval Agent.

Architecture: hybrid. Deliberation happens once, at decomposition (the LLM turns the
question into an ordered subgoal list); retrieval is then reactive. A purely reactive
agent could not keep ordered research subgoals, and classical symbolic planning needs
hand-built domain representations that unstructured literature does not offer
(Wooldridge, 2009).

BDI is used as a conceptual model rather than a formal interpreter (Rao and
Georgeff, 1995):
  * beliefs    -> ``records`` retrieved so far plus the query log (search state)
  * desires    -> the research question
  * intentions -> ``queue``, the committed subgoals not yet pursued
Committing to the queue is what bounds further deliberation (Bratman, Israel and
Pollack, 1988): the agent does not re-plan after every search, only when the reviewer
asks it to.

Execution follows ReAct (Yao et al., 2023): thought -> action -> observation per
subgoal. To spend the free-tier LLM budget where it matters, the 'thought' after an
observation is rule-based when retrieval went as expected, and the LLM is consulted
only when the observation is anomalous (too few results). That is the hybrid design
applied inside the loop: react cheaply by default, deliberate on surprise.

LangGraph models the loop as an explicit state machine, so every transition is
inspectable and the step budget is enforced in one place.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Literal, TypedDict

from langgraph.graph import END, START, StateGraph

from .config import Settings
from .llm import LLM, LLMUnavailable, SchemaEscalation, generate_structured
from .models import QueryLogEntry, ReactDecision, Record, ResultsBuffer, Subgoal, SubgoalPlan, TraceStep
from .sources import RetrievalError

log = logging.getLogger(__name__)

PLANNER_SYSTEM = (
    "You are the planning component of a literature-search agent supporting health-sciences systematic "
    "reviews. You decompose a research question into a small number of complementary search subgoals. "
    "You never answer the research question yourself."
)

PLAN_PROMPT = """Research question: {question}

Decompose this into {min_n}-{max_n} ordered search subgoals that together give good recall:
- start with the core concepts (population, intervention/exposure, outcome) combined;
- add subgoals for important synonyms or MeSH terms, key study designs (e.g. randomised trials,
  systematic reviews) and clinically important sub-questions;
- for each subgoal write a PubMed query (Boolean operators and field tags such as [tiab] or [MeSH]
  allowed) and a plain keyword query of 3-8 words for Semantic Scholar (no Boolean syntax);
- sources must be a subset of ["pubmed", "semantic_scholar"]; prefer both unless one is clearly unsuitable;
- give a one-sentence rationale per subgoal.
Also state explicit inclusion and exclusion criteria a screener should apply.{feedback}"""

REPLAN_FEEDBACK = """

This is a REVISION. The previous plan was:
{previous}
The human reviewer's feedback on its results was: "{feedback}"
Revise the subgoals to address the feedback; keep subgoals that were not criticised."""

FIXED_CRITERIA = """

The researcher has fixed the eligibility criteria in advance (review protocol). Design the
subgoals to find studies meeting them, and return these criteria unchanged:
Inclusion: {inclusion}
Exclusion: {exclusion}"""

REACT_PROMPT = """You are executing one subgoal of a literature search for: {question}

Subgoal {sg_id}: {description}
PubMed query used: {pubmed_query}
Keyword query used: {keyword_query}
Observation: {observation}

Decide the next action:
- "refine": the query is probably too narrow or malformed; give a broader corrected query
  (refined_pubmed_query and/or refined_keyword_query);
- "accept": the few results are plausibly all that exist; keep them and move on;
- "drop": this subgoal is not productive for the question; abandon it.
Give a short thought explaining your choice."""


class AgentState(TypedDict, total=False):
    run_id: str
    question: str
    feedback: str | None
    previous_plan: SubgoalPlan | None
    criteria: tuple[list[str], list[str]] | None
    plan: SubgoalPlan | None
    queue: list[int]
    current: dict[str, Any] | None
    records: list[Record]
    query_log: list[QueryLogEntry]
    trace: list[TraceStep]
    completed: list[int]
    failed: dict[int, str]
    last_observation: dict[str, Any]
    source_failures: dict[str, int]
    step: int
    needs_human: str | None


class PlanningRetrievalAgent:
    def __init__(self, llm: LLM, sources: dict[str, Any], settings: Settings | None = None):
        # ``sources`` maps a source name to any object with ``search(query, n, subgoal_id)``;
        # injecting them keeps the agent testable without network access.
        self.llm = llm
        self.sources = sources
        self.s = settings or Settings()
        self.graph = self._build_graph()

    # ------------------------------------------------------------------ graph

    def _build_graph(self):
        g = StateGraph(AgentState)
        g.add_node("plan", self._plan)
        g.add_node("select", self._select)
        g.add_node("act", self._act)
        g.add_node("observe", self._observe)
        g.add_edge(START, "plan")
        g.add_conditional_edges("plan", self._after_plan, {"select": "select", "end": END})
        g.add_edge("select", "act")
        g.add_edge("act", "observe")
        g.add_conditional_edges("observe", self._after_observe, {"act": "act", "select": "select", "end": END})
        return g.compile()

    def run(self, question: str, *, feedback: str | None = None, previous_plan: SubgoalPlan | None = None,
            criteria: tuple[list[str], list[str]] | None = None, run_id: str | None = None) -> ResultsBuffer:
        # ``criteria`` = (inclusion, exclusion) fixed by the researcher. Systematic reviews
        # pre-register eligibility criteria in a protocol, so when they are supplied the
        # LLM must not rewrite them (proposal FR3: "predefined" criteria).
        init: AgentState = {
            "run_id": run_id or uuid.uuid4().hex[:10], "question": question, "feedback": feedback,
            "previous_plan": previous_plan, "criteria": criteria if criteria and criteria[0] else None,
            "plan": None, "queue": [], "current": None, "records": [],
            "query_log": [], "trace": [], "completed": [], "failed": {}, "step": 0, "needs_human": None,
            "source_failures": {},
        }
        # LangGraph's own recursion limit is a backstop; our step budget is the real bound.
        final = self.graph.invoke(init, {"recursion_limit": 4 * self.s.max_react_steps + 10})
        return ResultsBuffer(
            run_id=final["run_id"], question=question, plan=final["plan"], records=final["records"],
            query_log=final["query_log"], trace=final["trace"], completed_subgoals=final["completed"],
            failed_subgoals=final["failed"], needs_human=final["needs_human"],
        )

    # ------------------------------------------------------------------ nodes

    @staticmethod
    def _t(state: AgentState, kind: str, content: str, sg: int | None = None) -> list[TraceStep]:
        return state["trace"] + [TraceStep(step=len(state["trace"]) + 1, kind=kind, content=content, subgoal_id=sg)]

    def _plan(self, state: AgentState) -> AgentState:
        feedback = ""
        if state.get("feedback") and state.get("previous_plan"):
            feedback = REPLAN_FEEDBACK.format(previous=state["previous_plan"].model_dump_json(indent=1),
                                              feedback=state["feedback"])
        fixed = state.get("criteria")
        if fixed:
            feedback += FIXED_CRITERIA.format(inclusion="; ".join(fixed[0]), exclusion="; ".join(fixed[1]) or "none")
        prompt = PLAN_PROMPT.format(question=state["question"], min_n=2, max_n=self.s.max_subgoals,
                                    feedback=feedback)
        try:
            plan = generate_structured(self.llm, prompt, SubgoalPlan, system=PLANNER_SYSTEM,
                                       max_retries=self.s.max_schema_retries)
        except SchemaEscalation as exc:
            msg = f"Planner produced no valid subgoal list after {len(exc.attempts)} attempts; human review needed."
            return {"needs_human": msg, "trace": self._t(state, "escalation", msg)}
        except LLMUnavailable as exc:
            # Without a plan there is nothing safe to do autonomously; hand back to the human.
            msg = f"LLM unavailable during planning ({exc}); try again later."
            return {"needs_human": msg, "trace": self._t(state, "escalation", msg)}
        if len(plan.subgoals) > self.s.max_subgoals:
            # Truncate rather than re-prompt: the list is ordered by importance, and an
            # extra LLM call to shorten it would cost quota for little gain.
            plan = plan.model_copy(update={"subgoals": plan.subgoals[: self.s.max_subgoals]})
        if fixed:
            # Enforced in code, not trusted to the prompt: the model may paraphrase them.
            plan = plan.model_copy(update={"inclusion_criteria": list(fixed[0]), "exclusion_criteria": list(fixed[1])})
        kind = "replan" if state.get("feedback") and state.get("previous_plan") else "plan"
        summary = "; ".join(f"[{s.id}] {s.description}" for s in plan.subgoals)
        if fixed:
            summary += " (eligibility criteria fixed by the researcher)"
        return {"plan": plan, "queue": [s.id for s in plan.subgoals],
                "trace": self._t(state, kind, f"Committed to {len(plan.subgoals)} subgoals: {summary}")}

    def _after_plan(self, state: AgentState) -> Literal["select", "end"]:
        return "select" if state.get("plan") else "end"

    def _select(self, state: AgentState) -> AgentState:
        sg_id, *rest = state["queue"]
        sg: Subgoal = next(s for s in state["plan"].subgoals if s.id == sg_id)
        current = {"id": sg.id, "pubmed_query": sg.pubmed_query, "keyword_query": sg.keyword_query,
                   "sources": sg.sources, "refinements": 0}
        return {"queue": rest, "current": current,
                "trace": self._t(state, "thought", f"Next intention: {sg.description} ({sg.rationale})", sg.id)}

    def _act(self, state: AgentState) -> AgentState:
        cur = state["current"]
        new_records: list[Record] = []
        log_entries: list[QueryLogEntry] = []
        errors: dict[str, str] = {}
        failures = dict(state.get("source_failures", {}))
        notes: list[str] = []
        for name in cur["sources"]:
            client = self.sources.get(name)
            query = cur["pubmed_query"] if name == "pubmed" else cur["keyword_query"]
            if client is None:
                errors[name] = "source not configured"
                continue
            if failures.get(name, 0) >= self.s.source_failure_limit:
                # Circuit breaker (Nygard, 2018): the agent's belief that this source is
                # down is updated by experience, so it stops paying ~15 s of back-off per
                # subgoal for a source that keeps refusing. Still logged for coverage.
                msg = f"skipped: circuit open after {failures[name]} failed calls this run"
                errors[name] = msg
                log_entries.append(QueryLogEntry(subgoal_id=cur["id"], source=name, query=query,
                                                 status="error", error=msg))
                continue
            try:
                found = client.search(query, self.s.results_per_subgoal, cur["id"])
            except (RetrievalError, ValueError, KeyError) as exc:
                # Catch per source: one source failing must not lose the other's results.
                errors[name] = str(exc)
                failures[name] = failures.get(name, 0) + 1
                if failures[name] == self.s.source_failure_limit:
                    notes.append(f"{name} failed {failures[name]} times; skipping it for the rest of this run.")
                log_entries.append(QueryLogEntry(subgoal_id=cur["id"], source=name, query=query,
                                                 status="error", error=str(exc)))
            else:
                new_records.extend(found)
                log_entries.append(QueryLogEntry(subgoal_id=cur["id"], source=name, query=query,
                                                 status="ok", n_results=len(found)))
        obs = {"n": len(new_records), "errors": errors,
               "per_source": {e.source: e.n_results for e in log_entries if e.status == "ok"}}
        text = f"{obs['n']} records ({obs['per_source']})" + (f"; errors: {errors}" if errors else "")
        trace = self._t(state, "action", f"Searched {', '.join(cur['sources'])}", cur["id"])
        trace.append(TraceStep(step=len(trace) + 1, kind="observation", content=text, subgoal_id=cur["id"]))
        for note in notes:
            trace.append(TraceStep(step=len(trace) + 1, kind="thought", content=note, subgoal_id=cur["id"]))
        return {"records": state["records"] + new_records, "query_log": state["query_log"] + log_entries,
                "last_observation": obs, "step": state["step"] + 1, "trace": trace, "source_failures": failures}

    def _observe(self, state: AgentState) -> AgentState:
        update = self._react(state)
        merged = {**state, **update}
        if merged["step"] >= self.s.max_react_steps and (merged.get("current") or merged["queue"]):
            # Step budget spent: anything still pending is reported as failed rather
            # than silently omitted, so the coverage figure stays honest.
            pending = list(merged["queue"]) + ([merged["current"]["id"]] if merged.get("current") else [])
            update["failed"] = {**merged["failed"], **{sg: "step budget exhausted" for sg in pending}}
            update["queue"], update["current"] = [], None
            update["trace"] = self._t(merged, "thought", f"Step budget exhausted; abandoning subgoals {pending}.")
        return update

    def _react(self, state: AgentState) -> AgentState:
        cur, obs = state["current"], state["last_observation"]
        sg_id = cur["id"]
        all_failed = obs["n"] == 0 and len(obs["errors"]) == len(cur["sources"])

        if obs["n"] >= self.s.min_results_per_subgoal:
            # Expected case: reactive accept, no LLM call.
            return {"completed": state["completed"] + [sg_id], "current": None,
                    "trace": self._t(state, "thought", "Enough results; subgoal satisfied.", sg_id)}
        if all_failed:
            # Every source errored: an infrastructure problem, not a query problem, so
            # refining the query would waste budget. Record it for the coverage report.
            reason = "; ".join(f"{k}: {v}" for k, v in obs["errors"].items())
            return {"failed": {**state["failed"], sg_id: f"retrieval failed ({reason})"}, "current": None,
                    "trace": self._t(state, "thought", "All sources failed; reporting subgoal as failed.", sg_id)}
        if cur["refinements"] >= self.s.max_refinements_per_subgoal:
            if obs["n"] > 0:
                return {"completed": state["completed"] + [sg_id], "current": None,
                        "trace": self._t(state, "thought", "Refinement budget spent; keeping partial results.", sg_id)}
            return {"failed": {**state["failed"], sg_id: "no results after refinement"}, "current": None,
                    "trace": self._t(state, "thought", "No results after refinement; giving up on subgoal.", sg_id)}

        # Anomalous observation: deliberate with the LLM.
        sg = next(s for s in state["plan"].subgoals if s.id == sg_id)
        observation = f"only {obs['n']} records returned" + (f"; source errors: {obs['errors']}" if obs["errors"] else "")
        try:
            decision = generate_structured(
                self.llm,
                REACT_PROMPT.format(question=state["question"], sg_id=sg_id, description=sg.description,
                                    pubmed_query=cur["pubmed_query"], keyword_query=cur["keyword_query"],
                                    observation=observation),
                ReactDecision, max_retries=1)
        except (SchemaEscalation, LLMUnavailable):
            # Failing to reason about a weak subgoal should not sink the run; keep what we have.
            decision = ReactDecision(thought="Reasoning step failed; keeping current results.", action="accept")
        trace = self._t(state, "thought", f"{decision.thought} -> {decision.action}", sg_id)
        if decision.action == "accept" and obs["n"] == 0:
            # Accepting an empty result would count the subgoal as covered while it
            # contributed nothing, inflating coverage (REMEDIATION R14).
            return {"failed": {**state["failed"], sg_id: f"no results ({decision.thought})"},
                    "current": None, "trace": trace}
        if decision.action == "refine":
            return {"current": {**cur, "refinements": cur["refinements"] + 1,
                                "pubmed_query": decision.refined_pubmed_query or cur["pubmed_query"],
                                "keyword_query": decision.refined_keyword_query or cur["keyword_query"]},
                    "trace": trace}
        if decision.action == "drop":
            return {"failed": {**state["failed"], sg_id: f"dropped by agent: {decision.thought}"},
                    "current": None, "trace": trace}
        return {"completed": state["completed"] + [sg_id], "current": None, "trace": trace}

    def _after_observe(self, state: AgentState) -> Literal["act", "select", "end"]:
        if state.get("current") is not None:
            return "act"
        return "select" if state["queue"] else "end"
